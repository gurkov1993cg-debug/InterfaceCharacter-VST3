#include "core/ProfileBundle.hpp"

#include <cassert>
#include <cmath>
#include <iostream>

int main()
{
    rt60::ProfileBundle source;
    source.profiles[0].targetMs = 220.0f;
    source.profiles[0].strength = 0.82f;
    source.profiles[0].autoTarget = true;
    source.profiles[0].measuredBandMs[3] = 610.0f;
    source.profiles[0].targetBandMs[3] = 220.0f;
    rt60::CorrectionStageSpec stage;
    stage.frequencyHz = 50.0f;
    stage.measuredT60Ms = 610.0f;
    stage.desiredT60Ms = 220.0f;
    stage.estimatedQ = 7.0f;
    stage.confidence = 0.9f;
    stage.sourceBand = 3;
    source.profiles[0].stages.push_back(stage);
    source.profiles[1] = source.profiles[0];
    source.display.beforeMs[0][3] = 610.0f;
    source.display.beforeValid[0][3] = true;
    source.display.afterMs[0][3] = 330.0f;
    source.display.afterValid[0][3] = true;
    source.display.beforeMs[1][3] = 640.0f;
    source.display.beforeValid[1][3] = true;
    source.display.afterMs[1][3] = 350.0f;
    source.display.afterValid[1][3] = true;
    source.metadata.appMajor = 0;
    source.metadata.appMinor = 10;
    source.metadata.measurementSampleRate = 48000.0;
    source.metadata.targetMs = 220.0f;
    source.metadata.maxCorrectionHz = 300.0f;
    source.metadata.verified = true;
    source.metadata.usedFallback = false;
    source.metadata.createdUtc = "2026-08-31T20:00:00Z";
    source.metadata.profileName = "Studio A";

    const auto encoded = rt60::ProfileBundleCodec::serialize(source);
    rt60::ProfileBundle decoded;
    assert(rt60::ProfileBundleCodec::deserialize(encoded, decoded));
    assert(decoded.hasCorrection());
    assert(decoded.profiles[0].stages.size() == 1);
    assert(std::abs(decoded.profiles[0].stages[0].frequencyHz - 50.0f) < 0.01f);
    assert(decoded.display.beforeValid[0][3] && decoded.display.beforeValid[1][3]);
    assert(decoded.display.afterValid[0][3] && decoded.display.afterValid[1][3]);
    assert(std::abs(decoded.display.afterMs[1][3] - 350.0f) < 0.01f);
    assert(decoded.metadata.appMinor == 10);
    assert(decoded.metadata.verified);
    assert(!decoded.metadata.legacyBundle);
    assert(std::abs(decoded.metadata.measurementSampleRate - 48000.0) < 0.01);
    assert(decoded.metadata.profileName == "Studio A");

    rt60::ProfileBundle sentinel = decoded;
    sentinel.profiles[0].targetMs = 777.0f;
    const auto truncated = encoded.substr(0, encoded.size() / 2);
    assert(!rt60::ProfileBundleCodec::deserialize(truncated, sentinel));
    assert(std::abs(sentinel.profiles[0].targetMs - 777.0f) < 0.01f);

    auto corrupt = encoded;
    const auto marker = corrupt.find("LEFT_PROFILE");
    assert(marker != std::string::npos);
    corrupt.replace(marker, 4, "BAD_");
    assert(!rt60::ProfileBundleCodec::deserialize(corrupt, sentinel));
    assert(std::abs(sentinel.profiles[0].targetMs - 777.0f) < 0.01f);

    std::cout << "Profile bundle v2 metadata tests passed\n";
    return 0;
}
