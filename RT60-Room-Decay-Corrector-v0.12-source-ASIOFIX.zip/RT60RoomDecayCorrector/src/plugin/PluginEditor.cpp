#include "plugin/PluginEditor.hpp"

#include <algorithm>
#include <array>

RT60Editor::RT60Editor(RT60Processor& p) : AudioProcessorEditor(&p), processor_(p)
{
    setSize(1100, 930);
    graph_.setModel(&processor_.model());
    graph_.setDisplaySnapshot(&processor_.displaySnapshot());
    addAndMakeVisible(graph_);
    addAndMakeVisible(waterfallGraph_);

    title_.setText("RT60 ROOM DECAY CORRECTOR v0.10 - PROFILE MANAGER + STEREO INSPECT", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(22.0f, juce::Font::bold));
    addAndMakeVisible(title_);

    graphLabel_.setText("RT60 graph", juce::dontSendNotification);
    waterfallLabel_.setText("Waterfall", juce::dontSendNotification);
    recentLabel_.setText("Recent", juce::dontSendNotification);
    inspectorLabel_.setText("FILTER INSPECTOR - Fc / Q / actual attenuation / measured->desired", juce::dontSendNotification);
    for (auto* label : {&status_, &profileMeta_, &graphLabel_, &waterfallLabel_, &improvementLabel_, &recentLabel_, &inspectorLabel_})
        addAndMakeVisible(*label);

    graphChannelSelector_.addItem("LEFT", 1);
    graphChannelSelector_.addItem("RIGHT", 2);
    graphChannelSelector_.addItem("WORST", 3);
    graphChannelSelector_.setSelectedId(3, juce::dontSendNotification);
    addAndMakeVisible(graphChannelSelector_);

    waterfallChannelSelector_.addItem("LEFT", 1);
    waterfallChannelSelector_.addItem("RIGHT", 2);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    waterfallStateSelector_.addItem("BEFORE", 1);
    waterfallStateSelector_.addItem("AFTER", 2);
    waterfallStateSelector_.setSelectedId(1, juce::dontSendNotification);
    addAndMakeVisible(waterfallChannelSelector_);
    addAndMakeVisible(waterfallStateSelector_);
    addAndMakeVisible(recentProfileSelector_);

    filterInspector_.setMultiLine(true);
    filterInspector_.setReadOnly(true);
    filterInspector_.setScrollbarsShown(true);
    filterInspector_.setCaretVisible(false);
    addAndMakeVisible(filterInspector_);

    addAndMakeVisible(loadProfileButton_);
    addAndMakeVisible(reloadButton_);
    addAndMakeVisible(abButton_);
    addAndMakeVisible(undoButton_);
    addAndMakeVisible(bestVerifiedButton_);
    addAndMakeVisible(bypassButton_);
    bypassA_ = std::make_unique<ButtonAttachment>(processor_.apvts, "bypass", bypassButton_);

    graphChannelSelector_.onChange = [this] { refreshGraphView(); };
    waterfallChannelSelector_.onChange = [this] { refreshWaterfall(); };
    waterfallStateSelector_.onChange = [this] { refreshWaterfall(); };
    loadProfileButton_.onClick = [this] { beginLoadProfile(); };
    reloadButton_.onClick = [this] {
        processor_.reloadActiveProfile();
        refreshAll();
    };
    abButton_.onClick = [this] {
        if (!processor_.swapWithPreviousProfile())
            status_.setText("A/B: no previous profile in this plug-in session yet.", juce::dontSendNotification);
        else
            refreshAll();
    };
    undoButton_.onClick = [this] {
        if (!processor_.swapWithPreviousProfile())
            status_.setText("UNDO: no previous profile load is available in this session.", juce::dontSendNotification);
        else
            refreshAll();
    };
    bestVerifiedButton_.onClick = [this] {
        if (!processor_.loadBestVerifiedProfile())
            status_.setText("No saved VERIFIED profile is available yet.", juce::dontSendNotification);
        else
            refreshAll();
    };
    recentProfileSelector_.onChange = [this] {
        const int index = recentProfileSelector_.getSelectedId() - 1;
        if (index >= 0 && !processor_.loadRecentProfile(index))
            status_.setText("Recent profile could not be loaded; current profile was kept.", juce::dontSendNotification);
        else if (index >= 0)
            refreshAll();
    };

    if (processor_.waterfall(0, true) != nullptr || processor_.waterfall(1, true) != nullptr)
        waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
    refreshAll();
    startTimerHz(10);
}

void RT60Editor::beginLoadProfile()
{
    const auto folder = juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
    loadProfileChooser_ = std::make_unique<juce::FileChooser>(
        "Load RT60 correction profile...", folder, "*.rt60profile", true, false, this);
    loadProfileChooser_->launchAsync(
        juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& chooser) {
            const auto file = chooser.getResult();
            if (file == juce::File{})
                return;
            if (!processor_.loadProfileBundleFromFile(file)) {
                status_.setText("LOAD FAILED: invalid/corrupt profile. Current working correction was left unchanged.",
                                juce::dontSendNotification);
                return;
            }
            if (processor_.waterfall(0, true) != nullptr || processor_.waterfall(1, true) != nullptr)
                waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
            refreshAll();
        });
}

void RT60Editor::refreshGraphView()
{
    rt60::DisplayChannelView view = rt60::DisplayChannelView::Worst;
    if (graphChannelSelector_.getSelectedId() == 1) view = rt60::DisplayChannelView::Left;
    if (graphChannelSelector_.getSelectedId() == 2) view = rt60::DisplayChannelView::Right;
    graph_.setDisplaySnapshot(&processor_.displaySnapshot());
    graph_.setChannelView(view);
    refreshImprovement();
}

void RT60Editor::refreshImprovement()
{
    const auto view = graph_.channelView();
    const char* name = view == rt60::DisplayChannelView::Left ? "LEFT"
        : (view == rt60::DisplayChannelView::Right ? "RIGHT" : "WORST");
    const auto& snapshot = processor_.displaySnapshot();

    struct Entry { float hz, before, after, pct; };
    std::array<Entry, rt60::kBandCount> entries{};
    int count = 0;
    float sum = 0.0f;
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        const float hz = processor_.model().bands()[i].frequencyHz;
        if (hz > 300.0f)
            continue;
        float before = 0.0f, after = 0.0f;
        if (!snapshot.valueBefore(view, i, before) || !snapshot.valueAfter(view, i, after) || before <= 1.0f)
            continue;
        const float pct = 100.0f * (before - after) / before;
        entries[static_cast<std::size_t>(count++)] = {hz, before, after, pct};
        sum += pct;
    }

    if (count == 0) {
        improvementLabel_.setText(juce::String("DECAY CHANGE [") + name + "]: no real BEFORE/AFTER pair in this profile.",
                                  juce::dontSendNotification);
        return;
    }
    std::sort(entries.begin(), entries.begin() + count, [](const Entry& a, const Entry& b) { return a.before > b.before; });
    juce::String text = juce::String("DECAY CHANGE [") + name + "]: avg "
                      + juce::String(sum / static_cast<float>(count), 0) + "%";
    for (int i = 0; i < std::min(count, 3); ++i) {
        const auto& e = entries[static_cast<std::size_t>(i)];
        text += " | " + juce::String(e.hz, e.hz < 100.0f ? 1 : 0) + " Hz "
              + juce::String(e.before, 0) + "->" + juce::String(e.after, 0) + " ms ("
              + juce::String(e.pct, 0) + "%)";
    }
    improvementLabel_.setText(text, juce::dontSendNotification);
}

void RT60Editor::refreshWaterfall()
{
    const int channel = juce::jlimit(0, 1, waterfallChannelSelector_.getSelectedId() - 1);
    const bool after = waterfallStateSelector_.getSelectedId() == 2;
    waterfallGraph_.setData(processor_.waterfall(channel, after));
    waterfallGraph_.setCaption("MEASURED WATERFALL - " + juce::String(channel == 0 ? "LEFT" : "RIGHT")
                               + (after ? " AFTER" : " BEFORE") + " - 20 to 300 Hz");
}

void RT60Editor::refreshInspector()
{
    const double sampleRate = processor_.getSampleRate() > 1000.0 ? processor_.getSampleRate() : 48000.0;
    juce::String text;
    const auto& profiles = processor_.profiles();
    for (int channel = 0; channel < 2; ++channel) {
        const auto& profile = profiles[static_cast<std::size_t>(channel)];
        text += juce::String(channel == 0 ? "LEFT" : "RIGHT") + " - "
              + juce::String(static_cast<int>(profile.stages.size())) + " stages\n";
        int index = 1;
        for (const auto& stage : profile.stages) {
            text += juce::String(index++) + ". " + juce::String(stage.frequencyHz, 1) + " Hz | Q "
                  + juce::String(stage.estimatedQ, 2) + " | "
                  + juce::String(rt60::CorrectionEngine::stageAttenuationDb(stage, sampleRate), 2) + " dB | "
                  + juce::String(stage.measuredT60Ms, 0) + "->" + juce::String(stage.desiredT60Ms, 0)
                  + " ms | conf " + juce::String(stage.confidence, 2) + "\n";
        }
        if (profile.stages.empty())
            text += "(no correction stages)\n";
        text += "\n";
    }
    filterInspector_.setText(text, false);
}

void RT60Editor::refreshRecentProfiles()
{
    const auto old = recentProfileSelector_.getText();
    recentProfileSelector_.clear(juce::dontSendNotification);
    const auto& paths = processor_.recentProfilePaths();
    for (std::size_t i = 0; i < paths.size(); ++i)
        recentProfileSelector_.addItem(juce::File(paths[i]).getFileNameWithoutExtension(), static_cast<int>(i) + 1);
    recentProfileSelector_.setText(old, juce::dontSendNotification);
}

void RT60Editor::updateStatus()
{
    if (processor_.hasActiveProfile()) {
        const auto name = processor_.activeProfileName();
        const auto prefix = name.isNotEmpty() ? (juce::String("ACTIVE PROFILE '") + name + "'")
                                               : juce::String("ACTIVE SHARED PROFILE");
        const auto& meta = processor_.profileMetadata();
        status_.setText(prefix + " | " + juce::String(processor_.activeStageCount()) + " stages"
                        + (meta.verified ? " | VERIFIED" : " | UNVERIFIED"),
                        juce::dontSendNotification);

        juce::String metaText;
        if (!meta.legacyBundle) {
            metaText = "Measured @ " + juce::String(meta.measurementSampleRate, 0) + " Hz | target "
                     + juce::String(meta.targetMs, 0) + " ms | max correction "
                     + juce::String(meta.maxCorrectionHz, 0) + " Hz";
            if (meta.usedFallback)
                metaText += " | conservative fallback used";
        } else {
            metaText = "Legacy profile metadata";
        }
        if (processor_.profileWarning().isNotEmpty())
            metaText += " | WARNING: " + processor_.profileWarning();
        profileMeta_.setText(metaText, juce::dontSendNotification);
    } else {
        status_.setText("No active profile. Press LOAD PROFILE... or save one from the standalone app.",
                        juce::dontSendNotification);
        profileMeta_.setText(juce::String{}, juce::dontSendNotification);
    }
}

void RT60Editor::refreshAll()
{
    graph_.setDisplaySnapshot(&processor_.displaySnapshot());
    updateStatus();
    refreshGraphView();
    refreshWaterfall();
    refreshInspector();
    refreshRecentProfiles();
}

void RT60Editor::timerCallback()
{
    graph_.repaint();
    waterfallGraph_.repaint();
}

void RT60Editor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(14, 16, 20));
}

void RT60Editor::resized()
{
    auto r = getLocalBounds().reduced(16);
    title_.setBounds(r.removeFromTop(36));
    status_.setBounds(r.removeFromTop(26));
    profileMeta_.setBounds(r.removeFromTop(24));

    auto graphRow = r.removeFromTop(28);
    graphLabel_.setBounds(graphRow.removeFromLeft(80));
    graphChannelSelector_.setBounds(graphRow.removeFromLeft(135));
    graph_.setBounds(r.removeFromTop(250));
    improvementLabel_.setBounds(r.removeFromTop(26));

    auto wfRow = r.removeFromTop(28);
    waterfallLabel_.setBounds(wfRow.removeFromLeft(80));
    waterfallChannelSelector_.setBounds(wfRow.removeFromLeft(120));
    wfRow.removeFromLeft(8);
    waterfallStateSelector_.setBounds(wfRow.removeFromLeft(120));
    waterfallGraph_.setBounds(r.removeFromTop(260));

    inspectorLabel_.setBounds(r.removeFromTop(22));
    filterInspector_.setBounds(r.removeFromTop(110));

    auto recent = r.removeFromTop(30);
    recentLabel_.setBounds(recent.removeFromLeft(60));
    recentProfileSelector_.setBounds(recent.removeFromLeft(280));

    auto row = r.removeFromTop(36);
    loadProfileButton_.setBounds(row.removeFromLeft(160));
    row.removeFromLeft(8);
    reloadButton_.setBounds(row.removeFromLeft(155));
    row.removeFromLeft(8);
    abButton_.setBounds(row.removeFromLeft(135));
    row.removeFromLeft(8);
    undoButton_.setBounds(row.removeFromLeft(120));
    row.removeFromLeft(8);
    bestVerifiedButton_.setBounds(row.removeFromLeft(145));
    row.removeFromLeft(8);
    bypassButton_.setBounds(row.removeFromLeft(105));
}
