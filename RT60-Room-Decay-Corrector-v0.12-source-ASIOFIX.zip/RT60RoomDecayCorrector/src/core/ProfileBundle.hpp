#pragma once

#include "core/CorrectionEngine.hpp"
#include "core/DisplaySnapshot.hpp"
#include "core/WaterfallData.hpp"

#include <array>
#include <string>

namespace rt60 {

struct ProfileMetadata {
    int appMajor = 0;
    int appMinor = 0;
    double measurementSampleRate = 0.0;
    float targetMs = 0.0f;
    float maxCorrectionHz = 0.0f;
    bool verified = false;
    bool usedFallback = false;
    bool legacyBundle = false;
    std::string createdUtc;
    std::string profileName;
};

struct ProfileBundle {
    static constexpr int kFormatVersion = 2;
    std::array<CorrectionProfile, 2> profiles{};
    std::array<WaterfallData, 2> beforeWaterfalls{};
    std::array<WaterfallData, 2> afterWaterfalls{};
    DisplaySnapshot display{};
    ProfileMetadata metadata{};

    bool hasCorrection() const noexcept
    {
        return !profiles[0].empty() || !profiles[1].empty();
    }
};

class ProfileBundleCodec {
public:
    static std::string serialize(const ProfileBundle& bundle);
    static bool deserialize(const std::string& text, ProfileBundle& bundle);
};

} // namespace rt60
