#pragma once

#include <juce_gui_extra/juce_gui_extra.h>
#include "plugin/PluginProcessor.hpp"
#include "ui/RT60Graph.hpp"
#include "ui/WaterfallGraph.hpp"

class RT60Editor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit RT60Editor(RT60Processor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    void updateStatus();
    void refreshWaterfall();

    RT60Processor& processor_;
    RT60Graph graph_;
    WaterfallGraph waterfallGraph_;
    juce::Label title_, status_, waterfallLabel_;
    juce::ComboBox waterfallChannelSelector_;
    juce::ComboBox waterfallStateSelector_;
    juce::TextButton reloadButton_{"RELOAD MEASURED PROFILE"};
    juce::ToggleButton bypassButton_{"BYPASS"};
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<ButtonAttachment> bypassA_;
};
