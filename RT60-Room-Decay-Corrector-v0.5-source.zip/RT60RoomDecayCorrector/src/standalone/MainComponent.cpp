#include "standalone/MainComponent.hpp"

#include <algorithm>
#include <cmath>

namespace {

int validBandCount(const rt60::MeasurementResult& result)
{
    int count = 0;
    for (const auto& band : result.bands)
        if (band.valid)
            ++count;
    return count;
}

int totalStages(const std::array<rt60::CorrectionProfile, 2>& profiles)
{
    return static_cast<int>(profiles[0].stages.size() + profiles[1].stages.size());
}

const char* speakerName(int channel) noexcept
{
    return channel == 0 ? "LEFT" : "RIGHT";
}

} // namespace

MainComponent::MainComponent()
    : deviceSelector_(deviceManager_, 1, 2, 2, 2, false, false, true, false)
{
    setSize(1180, 890);
    title_.setText("RT60 ROOM DECAY CORRECTOR v0.5 - SAFE STEREO MEASUREMENT", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(24.0f, juce::Font::bold));
    title_.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(title_);

    graph_.setModel(&model_);
    addAndMakeVisible(graph_);
    addAndMakeVisible(deviceSelector_);

    auto setup = [this](juce::Slider& slider, double min, double max, double step) {
        slider.setRange(min, max, step);
        slider.setSliderStyle(juce::Slider::LinearHorizontal);
        slider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 90, 24);
        addAndMakeVisible(slider);
    };
    setup(targetSlider_, 100.0, 1200.0, 5.0);
    setup(strengthSlider_, 25.0, 100.0, 1.0);
    setup(maxCutSlider_, 100.0, 2000.0, 25.0);
    setup(sweepLevelSlider_, -40.0, -6.0, 1.0);
    targetSlider_.setValue(300.0);
    strengthSlider_.setValue(85.0);
    maxCutSlider_.setValue(300.0); // modal/Schroeder-region safe default
    sweepLevelSlider_.setValue(-18.0);
    targetSlider_.setTextValueSuffix(" ms");
    strengthSlider_.setTextValueSuffix(" %");
    maxCutSlider_.setTextValueSuffix(" Hz");
    sweepLevelSlider_.setTextValueSuffix(" dBFS");

    targetLabel_.setText("Target RT60", juce::dontSendNotification);
    strengthLabel_.setText("Decay correction strength", juce::dontSendNotification);
    maxCutLabel_.setText("Max correction frequency", juce::dontSendNotification);
    sweepLevelLabel_.setText("Measurement sweep", juce::dontSendNotification);
    micInputLabel_.setText("Measurement microphone input", juce::dontSendNotification);
    for (auto* label : {&targetLabel_, &strengthLabel_, &maxCutLabel_, &sweepLevelLabel_, &micInputLabel_})
        addAndMakeVisible(*label);
    addAndMakeVisible(micInputSelector_);

    addAndMakeVisible(demoButton_);
    addAndMakeVisible(measureButton_);
    addAndMakeVisible(autoCorrectButton_);
    addAndMakeVisible(remeasureButton_);
    addAndMakeVisible(correctionToggle_);
    addAndMakeVisible(autoTargetToggle_);
    autoTargetToggle_.setToggleState(true, juce::dontSendNotification);
    autoCorrectButton_.setEnabled(false);
    remeasureButton_.setEnabled(false);
    correctionToggle_.setEnabled(false);

    status_.setText("Select one microphone input and two monitor outputs, then press MEASURE L + R.",
                    juce::dontSendNotification);
    addAndMakeVisible(status_);

    targetSlider_.onValueChange = [this] { refreshModel(); };
    strengthSlider_.onValueChange = [this] { refreshModel(); };
    sweepLevelSlider_.onValueChange = [this] { updateMeasurementConfigFromDevice(); };
    micInputSelector_.onChange = [this] {
        const int selected = std::max(0, micInputSelector_.getSelectedId() - 1);
        selectedMicInput_.store(selected, std::memory_order_release);
    };
    demoButton_.onClick = [this] {
        model_.setDemoRoom();
        refreshModel();
        baselineMeasurements_ = {};
        autoCorrectButton_.setEnabled(false);
        remeasureButton_.setEnabled(hasAnyCorrection());
        status_.setText("Demo curve loaded. Measure LEFT and RIGHT before auto correction.",
                        juce::dontSendNotification);
    };
    measureButton_.onClick = [this] { startMeasurement(false); };
    autoCorrectButton_.onClick = [this] { startAutoCorrection(); };
    remeasureButton_.onClick = [this] { startMeasurement(true); };
    autoTargetToggle_.onClick = [this] {
        targetSlider_.setEnabled(!autoTargetToggle_.getToggleState());
        status_.setText(autoTargetToggle_.getToggleState()
            ? "AUTO TARGET: one conservative common target will be chosen from LEFT + RIGHT."
            : "Manual common target enabled.", juce::dontSendNotification);
    };
    targetSlider_.setEnabled(false);
    correctionToggle_.onClick = [this] {
        const bool enabled = correctionToggle_.getToggleState() && hasAnyCorrection();
        correctionEnabled_.store(enabled, std::memory_order_release);
        status_.setText(enabled ? "Stereo correction profiles ACTIVE." : "Correction BYPASSED.",
                        juce::dontSendNotification);
    };

    const auto error = deviceManager_.initialise(1, 2, nullptr, true);
    if (error.isNotEmpty())
        status_.setText("Audio device error: " + error, juce::dontSendNotification);
    deviceManager_.addAudioCallback(this);
    updateMeasurementConfigFromDevice();
    refreshMicInputSelector();
    loadActiveProfiles();
    refreshModel();
    startTimerHz(20);
}

MainComponent::~MainComponent()
{
    stopTimer();
    deviceManager_.removeAudioCallback(this);
}

juce::File MainComponent::profileDirectory()
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("Room Decay Lab")
        .getChildFile("RT60 Room Decay Corrector");
}

juce::File MainComponent::activeProfileFile(int channel)
{
    return profileDirectory().getChildFile(channel == 0
        ? "active_profile_left.rt60" : "active_profile_right.rt60");
}

juce::File MainComponent::legacyProfileFile()
{
    return profileDirectory().getChildFile("active_profile.rt60");
}

bool MainComponent::hasAnyCorrection() const noexcept
{
    return !correctionProfiles_[0].empty() || !correctionProfiles_[1].empty();
}

bool MainComponent::baselinesValid() const noexcept
{
    return baselineMeasurements_[0].valid && baselineMeasurements_[1].valid;
}

void MainComponent::saveActiveProfiles()
{
    if (!hasAnyCorrection())
        return;

    profileDirectory().createDirectory();
    for (int channel = 0; channel < 2; ++channel) {
        const auto encoded = rt60::CorrectionEngine::serialize(correctionProfiles_[channel]);
        activeProfileFile(channel).replaceWithText(juce::String::fromUTF8(encoded.c_str()));
    }
}

void MainComponent::loadActiveProfiles()
{
    std::array<rt60::CorrectionProfile, 2> loaded{};
    bool gotAnyStereoFile = false;
    bool ok = true;

    for (int channel = 0; channel < 2; ++channel) {
        const auto file = activeProfileFile(channel);
        if (!file.existsAsFile())
            continue;
        gotAnyStereoFile = true;
        if (!rt60::CorrectionEngine::deserialize(file.loadFileAsString().toStdString(), loaded[channel]))
            ok = false;
    }

    // Backwards compatibility with v0.4 mono profile: use it on both channels
    // only when no new stereo profile files exist.
    if (!gotAnyStereoFile) {
        const auto legacy = legacyProfileFile();
        if (!legacy.existsAsFile())
            return;
        rt60::CorrectionProfile mono;
        if (!rt60::CorrectionEngine::deserialize(legacy.loadFileAsString().toStdString(), mono))
            return;
        loaded[0] = mono;
        loaded[1] = mono;
    } else if (!ok) {
        status_.setText("Stored stereo profile is corrupt/truncated; it was NOT partially loaded.",
                        juce::dontSendNotification);
        return;
    }

    correctionProfiles_ = std::move(loaded);
    const auto& reference = !correctionProfiles_[0].empty() ? correctionProfiles_[0] : correctionProfiles_[1];
    targetSlider_.setValue(reference.targetMs, juce::dontSendNotification);
    strengthSlider_.setValue(reference.strength * 100.0f, juce::dontSendNotification);
    autoTargetToggle_.setToggleState(reference.autoTarget, juce::dontSendNotification);
    targetSlider_.setEnabled(!reference.autoTarget);

    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float measured = 0.0f;
        float target = 0.0f;
        for (int channel = 0; channel < 2; ++channel) {
            measured = std::max(measured, correctionProfiles_[channel].measuredBandMs[i]);
            target = std::max(target, correctionProfiles_[channel].targetBandMs[i]);
        }
        if (measured > 0.0f)
            model_.setMeasured(i, measured);
        if (target > 0.0f)
            model_.setTarget(i, target);
    }

    publishCorrectionBanks();
    const bool enabled = hasAnyCorrection();
    correctionEnabled_.store(enabled, std::memory_order_release);
    correctionToggle_.setEnabled(enabled);
    correctionToggle_.setToggleState(enabled, juce::dontSendNotification);
    remeasureButton_.setEnabled(enabled);
    status_.setText("Loaded stereo correction: " + juce::String(totalStages(correctionProfiles_))
                    + " total decay stages.", juce::dontSendNotification);
}

void MainComponent::refreshModel()
{
    model_.setUniformTarget(static_cast<float>(targetSlider_.getValue()));
    model_.setStrength(static_cast<float>(strengthSlider_.getValue()) / 100.0f);
    model_.setMaxCutDb(18.0f);
    graph_.repaint();
}

void MainComponent::refreshMicInputSelector()
{
    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr)
        return;

    const auto names = device->getInputChannelNames();
    const auto active = device->getActiveInputChannels();
    juce::String signature;
    for (int i = 0; i < names.size(); ++i)
        signature += names[i] + (active[i] ? "*|" : "-|" );
    if (signature == micInputSignature_)
        return;
    micInputSignature_ = signature;

    int selected = selectedMicInput_.load(std::memory_order_acquire);
    int firstActive = -1;
    micInputSelector_.clear(juce::dontSendNotification);
    for (int i = 0; i < names.size(); ++i) {
        if (active[i] && firstActive < 0)
            firstActive = i;
        auto label = names[i].isNotEmpty() ? names[i] : ("Input " + juce::String(i + 1));
        if (!active[i])
            label += " (disabled)";
        micInputSelector_.addItem(label, i + 1);
    }
    if (selected < 0 || selected >= names.size() || !active[selected])
        selected = std::max(0, firstActive);
    selectedMicInput_.store(selected, std::memory_order_release);
    if (names.size() > 0)
        micInputSelector_.setSelectedId(selected + 1, juce::dontSendNotification);
}

void MainComponent::updateMeasurementConfigFromDevice()
{
    auto cfg = measurement_.config();
    if (auto* device = deviceManager_.getCurrentAudioDevice())
        cfg.sampleRate = device->getCurrentSampleRate();
    cfg.level = std::pow(10.0f, static_cast<float>(sweepLevelSlider_.getValue()) / 20.0f);
    measurement_.setConfig(cfg);
}

void MainComponent::publishCorrectionBanks()
{
    double sampleRate = measurement_.config().sampleRate;
    if (auto* device = deviceManager_.getCurrentAudioDevice())
        sampleRate = device->getCurrentSampleRate();

    const int active = activeBankIndex_.load(std::memory_order_acquire);
    const int pending = pendingBankIndex_.load(std::memory_order_acquire);
    int slot = 0;
    while (slot == active || slot == pending)
        ++slot;
    if (slot >= static_cast<int>(correctionBankSlots_.size())) {
        // This can only happen if active/pending changed while selecting. One
        // fresh read always leaves at least one slot free in the 3-slot bank.
        const int activeNow = activeBankIndex_.load(std::memory_order_acquire);
        const int pendingNow = pendingBankIndex_.load(std::memory_order_acquire);
        slot = 0;
        while (slot == activeNow || slot == pendingNow)
            ++slot;
    }

    auto& banks = correctionBankSlots_[static_cast<std::size_t>(slot)];
    banks.left.configure(correctionProfiles_[0], sampleRate);
    banks.right.configure(correctionProfiles_[1], sampleRate);
    pendingBankIndex_.store(slot, std::memory_order_release);
}

void MainComponent::startMeasurement(bool afterCorrection)
{
    if (measuring_.load(std::memory_order_acquire))
        return;

    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr) {
        status_.setText("No active audio device.", juce::dontSendNotification);
        return;
    }

    const auto activeInputs = device->getActiveInputChannels();
    const int mic = selectedMicInput_.load(std::memory_order_acquire);
    if (mic < 0 || mic >= device->getInputChannelNames().size() || !activeInputs[mic]) {
        status_.setText("Selected microphone input is disabled. Enable that input in Audio Device Setup.",
                        juce::dontSendNotification);
        return;
    }

    const auto activeOutputs = device->getActiveOutputChannels();
    int activeOutputCount = 0;
    const int outputNameCount = device->getOutputChannelNames().size();
    for (int i = 0; i < outputNameCount; ++i)
        if (activeOutputs[i])
            ++activeOutputCount;
    if (activeOutputCount < 2) {
        status_.setText("Enable two monitor outputs. v0.5 measures LEFT and RIGHT separately.",
                        juce::dontSendNotification);
        return;
    }

    if (afterCorrection && (!hasAnyCorrection() || !correctionEnabled_.load(std::memory_order_acquire))) {
        status_.setText("No active stereo correction. Measure the room and run AUTO CORRECT first.",
                        juce::dontSendNotification);
        return;
    }

    updateMeasurementConfigFromDevice();
    measurementIsAfter_.store(afterCorrection, std::memory_order_release);
    measurementLogicalChannel_.store(0, std::memory_order_release);
    model_.clearMeasuredAfter();

    measureButton_.setEnabled(false);
    autoCorrectButton_.setEnabled(false);
    remeasureButton_.setEnabled(false);
    demoButton_.setEnabled(false);
    correctionToggle_.setEnabled(false);
    autoTargetToggle_.setEnabled(false);
    micInputSelector_.setEnabled(false);

    startMeasurementChannel(0);
}

void MainComponent::startMeasurementChannel(int logicalChannel)
{
    if (measuring_.load(std::memory_order_acquire))
        return;

    if (measurementIsAfter_.load(std::memory_order_acquire))
        publishCorrectionBanks(); // fresh zero-state filters for each speaker sweep

    const int oldSlot = activeMeasurementBuffer_.load(std::memory_order_acquire);
    const int newSlot = oldSlot == 0 ? 1 : 0;
    auto& buffers = measurementBuffers_[static_cast<std::size_t>(newSlot)];
    buffers.excitation = measurement_.makeExcitation();
    buffers.capture.assign(buffers.excitation.size(), 0.0f);

    measurementPosition_.store(0, std::memory_order_relaxed);
    measurementFinished_.store(false, std::memory_order_relaxed);
    measurementClipped_.store(false, std::memory_order_relaxed);
    measurementLogicalChannel_.store(logicalChannel, std::memory_order_release);
    activeMeasurementBuffer_.store(newSlot, std::memory_order_release);
    measuring_.store(true, std::memory_order_release);

    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    status_.setText(juce::String(after ? "Corrected " : "Uncorrected ") + speakerName(logicalChannel)
                    + " sweep in progress... keep the room quiet.", juce::dontSendNotification);
}

void MainComponent::startAutoCorrection()
{
    if (!baselinesValid() || measuring_.load(std::memory_order_acquire)) {
        status_.setText("Run a valid MEASURE L + R measurement first.", juce::dontSendNotification);
        return;
    }

    profilesBeforeAuto_ = correctionProfiles_;
    correctionWasEnabledBeforeAuto_ = correctionEnabled_.load(std::memory_order_acquire);
    bestCorrectionProfiles_ = {};
    bestVerifiedMeasurements_ = {};
    bestVerifiedReports_ = {};
    haveBestVerifiedPass_ = false;
    bestVerifiedPass_ = 0;

    std::array<rt60::DecayUniformityReport, 2> baselineReports{
        evaluateUniformity(0, baselineMeasurements_[0]),
        evaluateUniformity(1, baselineMeasurements_[1])
    };
    baselineObjectiveMs_ = combinedObjective(baselineReports);
    bestObjectiveMs_ = baselineObjectiveMs_;

    rt60::CorrectionDesignConfig cfg;
    cfg.targetMs = static_cast<float>(targetSlider_.getValue());
    cfg.autoTarget = false; // v0.5 freezes one common stereo target
    cfg.strength = static_cast<float>(strengthSlider_.getValue()) / 100.0f;
    cfg.maxCorrectionHz = static_cast<float>(maxCutSlider_.getValue());
    cfg.minConfidence = 0.45f;
    cfg.maxT60ReductionPerPass = 0.55f;
    cfg.maxNewStages = 18;

    digitalTwinScore_ = 0.0f;
    int scoredChannels = 0;
    for (int channel = 0; channel < 2; ++channel) {
        correctionProfiles_[channel] = correctionEngine_.design(baselineMeasurements_[channel], cfg);
        correctionProfiles_[channel].autoTarget = autoTargetToggle_.getToggleState();
        if (!correctionProfiles_[channel].empty()) {
            rt60::CorrectionOptimizationConfig optCfg;
            optCfg.rounds = 2;
            optCfg.zeroGridPoints = 7;
            optCfg.desiredGridPoints = 7;
            digitalTwinScore_ += rt60::CorrectionEngine::optimizeAgainstMeasurement(
                correctionProfiles_[channel], baselineMeasurements_[channel], measurement_, optCfg);
            ++scoredChannels;
        }
    }
    if (scoredChannels > 0)
        digitalTwinScore_ /= static_cast<float>(scoredChannels);

    if (!hasAnyCorrection()) {
        status_.setText("Neither speaker has trusted long-decay modes needing active correction below the limit.",
                        juce::dontSendNotification);
        return;
    }

    publishCorrectionBanks();
    correctionEnabled_.store(true, std::memory_order_release);
    correctionToggle_.setToggleState(true, juce::dontSendNotification);
    correctionToggle_.setEnabled(true);
    autoCorrecting_ = true;
    autoIteration_ = 1;
    status_.setText("Independent LEFT/RIGHT correction optimized. Starting real stereo verification...",
                    juce::dontSendNotification);
    startMeasurement(true);
}

rt60::DecayUniformityReport MainComponent::evaluateUniformity(
    int channel, const rt60::MeasurementResult& result) const
{
    rt60::DecayUniformityConfig cfg;
    cfg.maxHz = static_cast<float>(maxCutSlider_.getValue());
    cfg.minConfidence = 0.45f;
    cfg.toleranceFraction = 0.10f;
    cfg.requiredWithinFraction = 0.90f;
    return rt60::DecayUniformity::evaluate(baselineMeasurements_[static_cast<std::size_t>(channel)], result,
                                           static_cast<float>(targetSlider_.getValue()), cfg);
}

float MainComponent::combinedObjective(const std::array<rt60::DecayUniformityReport, 2>& reports) const
{
    float sum = 0.0f;
    int count = 0;
    for (const auto& report : reports) {
        if (report.correctableBands > 0) {
            sum += report.correctionObjectiveMs;
            ++count;
        }
    }
    return count > 0 ? sum / static_cast<float>(count) : 0.0f;
}

void MainComponent::applyRecommendedStereoTarget()
{
    if (!autoTargetToggle_.getToggleState() || !baselinesValid())
        return;

    rt60::DecayUniformityConfig cfg;
    cfg.maxHz = static_cast<float>(maxCutSlider_.getValue());
    cfg.minConfidence = 0.45f;
    const float left = rt60::DecayUniformity::chooseCommonTarget(baselineMeasurements_[0], cfg);
    const float right = rt60::DecayUniformity::chooseCommonTarget(baselineMeasurements_[1], cfg);
    // Use the less aggressive of the two recommended targets. This avoids
    // forcing one loudspeaker below the natural decay supported by the other.
    const float target = std::max(left, right);
    targetSlider_.setValue(target, juce::dontSendNotification);
    refreshModel();
}

void MainComponent::updateGraphFromStereo(bool afterCorrection)
{
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float worst = 0.0f;
        bool valid = false;
        for (int channel = 0; channel < 2; ++channel) {
            const auto& band = latestMeasurements_[static_cast<std::size_t>(channel)].bands[i];
            if (band.valid) {
                worst = std::max(worst, band.rt60Ms);
                valid = true;
            }
        }
        if (!valid)
            continue;
        if (afterCorrection)
            model_.setMeasuredAfter(i, worst);
        else
            model_.setMeasured(i, worst);
    }
    refreshModel();
}

void MainComponent::restoreBestVerifiedPass()
{
    if (!haveBestVerifiedPass_)
        return;

    correctionProfiles_ = bestCorrectionProfiles_;
    latestMeasurements_ = bestVerifiedMeasurements_;
    publishCorrectionBanks();
    correctionEnabled_.store(true, std::memory_order_release);
    correctionToggle_.setToggleState(true, juce::dontSendNotification);
    correctionToggle_.setEnabled(true);
    updateGraphFromStereo(true);
}

void MainComponent::abortUnhelpfulAutoCorrection(const juce::String& reason)
{
    autoCorrecting_ = false;
    correctionProfiles_ = profilesBeforeAuto_;
    const bool enabled = correctionWasEnabledBeforeAuto_ && hasAnyCorrection();
    correctionEnabled_.store(enabled, std::memory_order_release);
    publishCorrectionBanks();
    correctionToggle_.setToggleState(enabled, juce::dontSendNotification);
    correctionToggle_.setEnabled(hasAnyCorrection());
    model_.clearMeasuredAfter();
    refreshModel();
    enableIdleControls();
    status_.setText("AUTO stopped safely: " + reason + " | rejected pass was NOT saved.",
                    juce::dontSendNotification);
}

void MainComponent::finishAutoCorrection(bool hitIterationLimit, const juce::String& stopReason)
{
    std::array<rt60::DecayUniformityReport, 2> reports{
        evaluateUniformity(0, latestMeasurements_[0]),
        evaluateUniformity(1, latestMeasurements_[1])
    };
    autoCorrecting_ = false;
    if (hasAnyCorrection())
        saveActiveProfiles();
    correctionEnabled_.store(hasAnyCorrection(), std::memory_order_release);
    correctionToggle_.setEnabled(hasAnyCorrection());
    correctionToggle_.setToggleState(hasAnyCorrection(), juce::dontSendNotification);
    enableIdleControls();

    const float objective = combinedObjective(reports);
    juce::String msg = "AUTO stereo decay match complete | target "
                     + juce::String(static_cast<int>(targetSlider_.getValue())) + " ms | L "
                     + juce::String(reports[0].withinCorrectableBands) + "/"
                     + juce::String(reports[0].correctableBands) + " | R "
                     + juce::String(reports[1].withinCorrectableBands) + "/"
                     + juce::String(reports[1].correctableBands) + " | objective "
                     + juce::String(objective, 1) + " ms | model "
                     + juce::String(digitalTwinScore_, 0) + "% | "
                     + juce::String(totalStages(correctionProfiles_)) + " stages";
    if (bestVerifiedPass_ > 0)
        msg += " | best measured pass " + juce::String(bestVerifiedPass_);
    if (hitIterationLimit)
        msg += " | max verification passes reached";
    if (stopReason.isNotEmpty())
        msg += " | " + stopReason;
    status_.setText(msg, juce::dontSendNotification);
}

void MainComponent::audioDeviceIOCallbackWithContext(const float* const* inputChannelData,
                                                      int numInputChannels,
                                                      float* const* outputChannelData,
                                                      int numOutputChannels,
                                                      int numSamples,
                                                      const juce::AudioIODeviceCallbackContext&)
{
    for (int channel = 0; channel < numOutputChannels; ++channel)
        if (outputChannelData[channel] != nullptr)
            juce::FloatVectorOperations::clear(outputChannelData[channel], numSamples);

    if (const int pending = pendingBankIndex_.exchange(-1, std::memory_order_acq_rel); pending >= 0)
        activeBankIndex_.store(pending, std::memory_order_release);

    if (!measuring_.load(std::memory_order_acquire))
        return;

    int physicalOutputs[2] = {-1, -1};
    int foundOutputs = 0;
    for (int channel = 0; channel < numOutputChannels && foundOutputs < 2; ++channel) {
        if (outputChannelData[channel] != nullptr)
            physicalOutputs[foundOutputs++] = channel;
    }

    const int logicalChannel = measurementLogicalChannel_.load(std::memory_order_acquire);
    if (logicalChannel < 0 || logicalChannel > 1 || physicalOutputs[logicalChannel] < 0) {
        measuring_.store(false, std::memory_order_release);
        measurementFinished_.store(true, std::memory_order_release);
        return;
    }

    const int mic = selectedMicInput_.load(std::memory_order_acquire);
    if (mic < 0 || mic >= numInputChannels || inputChannelData[mic] == nullptr) {
        measuring_.store(false, std::memory_order_release);
        measurementFinished_.store(true, std::memory_order_release);
        return;
    }

    const int bufferSlot = activeMeasurementBuffer_.load(std::memory_order_acquire);
    auto& buffers = measurementBuffers_[static_cast<std::size_t>(bufferSlot)];
    auto& banks = correctionBankSlots_[static_cast<std::size_t>(activeBankIndex_.load(std::memory_order_acquire))];
    std::size_t pos = measurementPosition_.load(std::memory_order_relaxed);
    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    const bool correction = correctionEnabled_.load(std::memory_order_acquire);
    float* const outData = outputChannelData[physicalOutputs[logicalChannel]];
    const float* const inData = inputChannelData[mic];

    for (int i = 0; i < numSamples; ++i) {
        if (pos >= buffers.excitation.size())
            break;

        float out = buffers.excitation[pos];
        if (after && correction)
            out = (logicalChannel == 0 ? banks.left : banks.right).processSample(out);
        outData[i] = out;

        const float input = inData[i];
        buffers.capture[pos] = input;
        ++pos;

        if (std::abs(input) >= 0.999f) {
            measurementClipped_.store(true, std::memory_order_release);
            measuring_.store(false, std::memory_order_release);
            measurementFinished_.store(true, std::memory_order_release);
            break;
        }
    }

    measurementPosition_.store(pos, std::memory_order_release);
    if (pos >= buffers.excitation.size() && measuring_.exchange(false, std::memory_order_acq_rel))
        measurementFinished_.store(true, std::memory_order_release);
}

void MainComponent::audioDeviceAboutToStart(juce::AudioIODevice* device)
{
    if (device == nullptr)
        return;
    auto cfg = measurement_.config();
    cfg.sampleRate = device->getCurrentSampleRate();
    measurement_.setConfig(cfg);
    publishCorrectionBanks();
}

void MainComponent::audioDeviceStopped()
{
    measuring_.store(false, std::memory_order_release);
}

void MainComponent::timerCallback()
{
    refreshMicInputSelector();
    if (measuring_.load(std::memory_order_acquire)) {
        const int slot = activeMeasurementBuffer_.load(std::memory_order_acquire);
        const auto total = std::max<std::size_t>(1, measurementBuffers_[static_cast<std::size_t>(slot)].excitation.size());
        const auto current = measurementPosition_.load(std::memory_order_acquire);
        const int percent = static_cast<int>(100.0 * static_cast<double>(current) / static_cast<double>(total));
        const int channel = measurementLogicalChannel_.load(std::memory_order_acquire);
        status_.setText(juce::String(measurementIsAfter_.load(std::memory_order_acquire)
                            ? "Corrected " : "Room ")
                        + speakerName(channel) + " measurement: " + juce::String(percent) + "%",
                        juce::dontSendNotification);
    }
    if (measurementFinished_.exchange(false, std::memory_order_acq_rel))
        finishMeasurementOnMessageThread();
}

void MainComponent::finishMeasurementOnMessageThread()
{
    const int channel = measurementLogicalChannel_.load(std::memory_order_acquire);
    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    const int slot = activeMeasurementBuffer_.load(std::memory_order_acquire);
    auto& buffers = measurementBuffers_[static_cast<std::size_t>(slot)];

    if (measurementClipped_.load(std::memory_order_acquire)) {
        if (after && autoCorrecting_)
            abortUnhelpfulAutoCorrection(juce::String(speakerName(channel))
                + " microphone input clipped; lower mic/preamp gain and measure again");
        else {
            enableIdleControls();
            status_.setText("MEASUREMENT CLIPPED on " + juce::String(speakerName(channel))
                            + " - sweep stopped. Lower mic/preamp gain and repeat; no profile was built.",
                            juce::dontSendNotification);
        }
        return;
    }

    status_.setText("Analysing " + juce::String(speakerName(channel)) + " impulse response and RT60...",
                    juce::dontSendNotification);
    const auto result = measurement_.analyseCapture(buffers.capture);
    if (result.clipped) {
        if (after && autoCorrecting_)
            abortUnhelpfulAutoCorrection(juce::String(speakerName(channel))
                + " analysis detected clipping; rejected the verification pass");
        else {
            enableIdleControls();
            status_.setText("MEASUREMENT CLIPPED - result rejected. Lower gain and repeat.",
                            juce::dontSendNotification);
        }
        return;
    }

    latestMeasurements_[static_cast<std::size_t>(channel)] = result;
    if (!after)
        baselineMeasurements_[static_cast<std::size_t>(channel)] = result;
    updateGraphFromStereo(after);

    // Always measure the speakers independently: never excite L+R together.
    if (channel == 0) {
        startMeasurementChannel(1);
        return;
    }

    finishStereoMeasurementPass();
}

void MainComponent::finishStereoMeasurementPass()
{
    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    updateGraphFromStereo(after);

    if (!after) {
        model_.clearMeasuredAfter();
        if (baselinesValid())
            applyRecommendedStereoTarget();
        enableIdleControls();

        const int leftBands = validBandCount(baselineMeasurements_[0]);
        const int rightBands = validBandCount(baselineMeasurements_[1]);
        if (!baselinesValid()) {
            status_.setText("Stereo measurement incomplete | L " + juce::String(leftBands)
                            + " bands | R " + juce::String(rightBands)
                            + " bands. Improve mic SNR and repeat.", juce::dontSendNotification);
        } else {
            status_.setText("Independent stereo measurement complete | L " + juce::String(leftBands)
                            + " bands @ " + juce::String(baselineMeasurements_[0].peakDbFs, 1)
                            + " dBFS | R " + juce::String(rightBands) + " bands @ "
                            + juce::String(baselineMeasurements_[1].peakDbFs, 1)
                            + " dBFS | common target " + juce::String(static_cast<int>(targetSlider_.getValue()))
                            + " ms | ready for AUTO.", juce::dontSendNotification);
        }
        return;
    }

    if (autoCorrecting_) {
        std::array<rt60::DecayUniformityReport, 2> reports{
            evaluateUniformity(0, latestMeasurements_[0]),
            evaluateUniformity(1, latestMeasurements_[1])
        };
        const float referenceObjective = haveBestVerifiedPass_ ? bestObjectiveMs_ : baselineObjectiveMs_;
        const float currentObjective = combinedObjective(reports);
        const float meaningfulDelta = std::max(6.0f, referenceObjective * 0.03f);
        const float regressionDelta = std::max(10.0f, referenceObjective * 0.06f);
        const float improvement = referenceObjective - currentObjective;
        bool verificationReliable = true;
        bool converged = true;
        int overshot = 0;
        int bestOvershot = 0;
        for (int channel = 0; channel < 2; ++channel) {
            verificationReliable = verificationReliable
                && (reports[channel].correctableBands == 0 || reports[channel].unreliableCorrectableBands == 0);
            converged = converged && reports[channel].converged;
            overshot += reports[channel].overshotCorrectableBands;
            bestOvershot += bestVerifiedReports_[channel].overshotCorrectableBands;
        }
        const bool materiallyBetter = verificationReliable && improvement >= meaningfulDelta;
        const bool regressed = currentObjective > referenceObjective + regressionDelta
            || (haveBestVerifiedPass_ && overshot > bestOvershot);

        if (!haveBestVerifiedPass_) {
            if (!verificationReliable) {
                abortUnhelpfulAutoCorrection("stereo verification lost trusted decay bands; improve measurement SNR");
                return;
            }
            if (!converged && !materiallyBetter) {
                abortUnhelpfulAutoCorrection("first corrected L/R pass did not produce meaningful measured improvement");
                return;
            }
            bestCorrectionProfiles_ = correctionProfiles_;
            bestVerifiedMeasurements_ = latestMeasurements_;
            bestVerifiedReports_ = reports;
            bestObjectiveMs_ = currentObjective;
            bestVerifiedPass_ = autoIteration_;
            haveBestVerifiedPass_ = true;
            saveActiveProfiles();
        } else if (regressed) {
            restoreBestVerifiedPass();
            finishAutoCorrection(false, "rollback: latest stereo pass regressed; restored best verified pair");
            return;
        } else if (materiallyBetter || converged) {
            bestCorrectionProfiles_ = correctionProfiles_;
            bestVerifiedMeasurements_ = latestMeasurements_;
            bestVerifiedReports_ = reports;
            bestObjectiveMs_ = currentObjective;
            bestVerifiedPass_ = autoIteration_;
            saveActiveProfiles();
        } else {
            restoreBestVerifiedPass();
            finishAutoCorrection(false, "stopped: further stereo pass gave no meaningful measured improvement");
            return;
        }

        if (converged) {
            finishAutoCorrection(false, "target tolerance reached on LEFT and RIGHT");
            return;
        }
        if (autoIteration_ >= kMaxAutoIterations) {
            restoreBestVerifiedPass();
            finishAutoCorrection(true, "kept best verified stereo result");
            return;
        }

        bool changedAny = false;
        for (int channel = 0; channel < 2; ++channel) {
            bool changed = rt60::CorrectionEngine::refineProfile(
                correctionProfiles_[channel], latestMeasurements_[channel], 0.28f, 0.08f);

            rt60::CorrectionDesignConfig cfg;
            cfg.targetMs = static_cast<float>(targetSlider_.getValue());
            cfg.autoTarget = false;
            cfg.strength = std::min(0.65f, static_cast<float>(strengthSlider_.getValue()) / 100.0f);
            cfg.maxCorrectionHz = static_cast<float>(maxCutSlider_.getValue());
            cfg.minConfidence = 0.50f;
            cfg.maxT60ReductionPerPass = 0.30f;
            cfg.maxNewStages = 6;
            auto incremental = correctionEngine_.design(latestMeasurements_[channel], cfg);
            const auto before = correctionProfiles_[channel].stages.size();
            rt60::CorrectionEngine::appendIncremental(correctionProfiles_[channel], incremental, 36, 1);
            changed = changed || correctionProfiles_[channel].stages.size() != before;
            changedAny = changedAny || changed;
        }

        if (!changedAny) {
            restoreBestVerifiedPass();
            finishAutoCorrection(false, "stopped: no safe high-confidence stereo correction change remained");
            return;
        }

        publishCorrectionBanks();
        ++autoIteration_;
        status_.setText("Stereo feedback pass " + juce::String(autoIteration_)
                        + ": retuning only measured modal decay below "
                        + juce::String(static_cast<int>(maxCutSlider_.getValue())) + " Hz...",
                        juce::dontSendNotification);
        startMeasurement(true);
        return;
    }

    enableIdleControls();
    status_.setText("Corrected LEFT + RIGHT Measured After updated independently | L peak "
                    + juce::String(latestMeasurements_[0].peakDbFs, 1) + " dBFS | R peak "
                    + juce::String(latestMeasurements_[1].peakDbFs, 1) + " dBFS.",
                    juce::dontSendNotification);
}

void MainComponent::enableIdleControls()
{
    measureButton_.setEnabled(true);
    demoButton_.setEnabled(true);
    autoCorrectButton_.setEnabled(baselinesValid() && !autoCorrecting_);
    remeasureButton_.setEnabled(hasAnyCorrection()
        && correctionEnabled_.load(std::memory_order_acquire) && !autoCorrecting_);
    correctionToggle_.setEnabled(hasAnyCorrection() && !autoCorrecting_);
    autoTargetToggle_.setEnabled(!autoCorrecting_);
    micInputSelector_.setEnabled(!autoCorrecting_);
}

void MainComponent::paint(juce::Graphics& graphics)
{
    graphics.fillAll(juce::Colour::fromRGB(14, 16, 20));
}

void MainComponent::resized()
{
    auto r = getLocalBounds().reduced(20);
    title_.setBounds(r.removeFromTop(42));

    auto top = r.removeFromTop(500);
    auto graphArea = top.removeFromLeft(static_cast<int>(top.getWidth() * 0.75f));
    graph_.setBounds(graphArea);
    top.removeFromLeft(12);
    deviceSelector_.setBounds(top);

    r.removeFromTop(10);
    auto setSliderRow = [](juce::Rectangle<int> row, juce::Label& label, juce::Slider& slider) {
        label.setBounds(row.removeFromLeft(210));
        slider.setBounds(row);
    };
    setSliderRow(r.removeFromTop(36), targetLabel_, targetSlider_);
    setSliderRow(r.removeFromTop(36), strengthLabel_, strengthSlider_);
    setSliderRow(r.removeFromTop(36), maxCutLabel_, maxCutSlider_);
    setSliderRow(r.removeFromTop(36), sweepLevelLabel_, sweepLevelSlider_);

    auto micRow = r.removeFromTop(36);
    micInputLabel_.setBounds(micRow.removeFromLeft(210));
    micInputSelector_.setBounds(micRow.removeFromLeft(380));

    auto buttons = r.removeFromTop(40);
    demoButton_.setBounds(buttons.removeFromLeft(140));
    buttons.removeFromLeft(8);
    measureButton_.setBounds(buttons.removeFromLeft(180));
    buttons.removeFromLeft(8);
    autoCorrectButton_.setBounds(buttons.removeFromLeft(200));
    buttons.removeFromLeft(8);
    remeasureButton_.setBounds(buttons.removeFromLeft(190));
    buttons.removeFromLeft(8);
    autoTargetToggle_.setBounds(buttons.removeFromLeft(140));
    buttons.removeFromLeft(8);
    correctionToggle_.setBounds(buttons.removeFromLeft(180));
    status_.setBounds(r.removeFromTop(42));
}
