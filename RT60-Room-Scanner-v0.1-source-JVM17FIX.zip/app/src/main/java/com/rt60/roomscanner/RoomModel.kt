package com.rt60.roomscanner

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class WallScan(
    val id: String = UUID.randomUUID().toString(),
    var center: FloatArray,
    var normal: FloatArray,
    var polygon: FloatArray,
    var widthMeters: Float,
    var heightMeters: Float,
    var userDescription: String = "",
    var materialConfidence: String = "USER_OR_UNKNOWN"
)

class RoomModel {
    private val walls = linkedMapOf<String, WallScan>()

    @Synchronized
    fun upsertWall(key: String, wall: WallScan) {
        val previous = walls[key]
        if (previous != null && previous.userDescription.isNotBlank()) {
            wall.userDescription = previous.userDescription
        }
        walls[key] = wall
    }

    @Synchronized
    fun wallCount(): Int = walls.size

    @Synchronized
    fun nearestWall(camera: FloatArray): WallScan? {
        return walls.values.minByOrNull {
            val dx = it.center[0] - camera[0]
            val dy = it.center[1] - camera[1]
            val dz = it.center[2] - camera[2]
            dx * dx + dy * dy + dz * dz
        }
    }

    @Synchronized
    fun toJson(): JSONObject {
        val root = JSONObject()
        root.put("format", "RTROOM")
        root.put("version", 1)
        root.put("units", "meters")
        root.put("coordinate_system", "ARCore world")

        val arr = JSONArray()
        walls.values.forEach { w ->
            arr.put(JSONObject().apply {
                put("id", w.id)
                put("center", JSONArray(w.center.toList()))
                put("normal", JSONArray(w.normal.toList()))
                put("polygonXZ", JSONArray(w.polygon.toList()))
                put("width_m", w.widthMeters)
                put("height_m", w.heightMeters)
                put("user_description", w.userDescription)
                put("material_confidence", w.materialConfidence)
            })
        }
        root.put("walls", arr)
        return root
    }
}
