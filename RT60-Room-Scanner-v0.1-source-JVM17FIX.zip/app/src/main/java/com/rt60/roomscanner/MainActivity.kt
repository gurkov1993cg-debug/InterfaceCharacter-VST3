package com.rt60.roomscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Plane
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.nio.FloatBuffer
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), GLSurfaceView.Renderer {
    private lateinit var glView: GLSurfaceView
    private lateinit var status: TextView
    private lateinit var count: TextView
    private val room = RoomModel()
    private var session: Session? = null
    private var installRequested = false
    private val background = BackgroundRenderer()
    private var cameraPosition = floatArrayOf(0f,0f,0f)
    private var voiceTarget: WallScan? = null
    private var recognizer: SpeechRecognizer? = null

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startArIfPossible() }

    private val saveLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            RtRoomWriter.write(this, uri, room)
            status.text = "Записано: .rtroom"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        glView = findViewById(R.id.glView)
        status = findViewById(R.id.statusText)
        count = findViewById(R.id.countText)

        glView.setEGLContextClientVersion(2)
        glView.setRenderer(this)
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        findViewById<Button>(R.id.voiceButton).setOnClickListener { describeNearestWall() }
        findViewById<Button>(R.id.exportButton).setOnClickListener {
            saveLauncher.launch("MyStudio.rtroom")
        }

        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) startArIfPossible() else permissions.launch(need.toTypedArray())
    }

    private fun startArIfPossible() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Нужно е разрешение за камера."
            return
        }
        try {
            when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                    installRequested = true
                    status.text = "Инсталиране/обновяване на Google Play Services for AR…"
                    return
                }
                ArCoreApk.InstallStatus.INSTALLED -> Unit
            }
            if (session == null) {
                session = Session(this).apply {
                    val c = config
                    c.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                    if (isDepthModeSupported(Config.DepthMode.AUTOMATIC)) {
                        c.depthMode = Config.DepthMode.AUTOMATIC
                    }
                    configure(c)
                }
                status.text = "Сканирай бавно стените, ъглите, пода и тавана."
            }
        } catch (e: Exception) {
            status.text = "ARCore не може да стартира: ${e.javaClass.simpleName}"
        }
    }

    override fun onResume() {
        super.onResume()
        if (::glView.isInitialized) glView.onResume()
        try { session?.resume() } catch (_: Exception) {}
    }

    override fun onPause() {
        session?.pause()
        if (::glView.isInitialized) glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        session?.close()
        super.onDestroy()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        background.create()
        session?.setCameraTextureName(background.textureId)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        session?.setDisplayGeometry(windowManager.defaultDisplay.rotation, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val s = session ?: return
        if (background.textureId < 0) return
        try {
            s.setCameraTextureName(background.textureId)
            val frame = s.update()
            background.draw(frame)

            val pose = frame.camera.pose
            cameraPosition = floatArrayOf(pose.tx(), pose.ty(), pose.tz())

            s.getAllTrackables(Plane::class.java)
                .filter { it.trackingState == TrackingState.TRACKING && it.type == Plane.Type.VERTICAL && it.subsumedBy == null }
                .forEach { plane -> updateWall(plane) }

            runOnUiThread { count.text = "Открити вертикални повърхности: ${room.wallCount()}" }
        } catch (_: Exception) {
        }
    }

    private fun updateWall(plane: Plane) {
        val pose = plane.centerPose
        val n = pose.rotateVector(floatArrayOf(0f, 1f, 0f))
        val polygon = plane.polygon.toArray()
        var minX = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY
        var i = 0
        while (i + 1 < polygon.size) {
            minX = min(minX, polygon[i]); maxX = max(maxX, polygon[i])
            minZ = min(minZ, polygon[i+1]); maxZ = max(maxZ, polygon[i+1])
            i += 2
        }
        val width = if (polygon.isEmpty()) plane.extentX else max(0f, maxX - minX)
        val height = if (polygon.isEmpty()) plane.extentZ else max(0f, maxZ - minZ)

        val key = "${(pose.tx()*10).toInt()}:${(pose.ty()*10).toInt()}:${(pose.tz()*10).toInt()}"
        room.upsertWall(
            key,
            WallScan(
                center = floatArrayOf(pose.tx(), pose.ty(), pose.tz()),
                normal = n,
                polygon = polygon,
                widthMeters = width,
                heightMeters = height
            )
        )
    }

    private fun FloatBuffer.toArray(): FloatArray {
        val dup = duplicate()
        dup.rewind()
        val arr = FloatArray(dup.remaining())
        dup.get(arr)
        return arr
    }

    private fun describeNearestWall() {
        val target = room.nearestWall(cameraPosition)
        if (target == null) {
            status.text = "Още няма надеждно открита стена."
            return
        }
        voiceTarget = target
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "На телефона няма SpeechRecognizer."
            return
        }
        recognizer?.destroy()
        recognizer = if (android.os.Build.VERSION.SDK_INT >= 31 &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Говори – описвай тази стена…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Разпознавам…" }
            override fun onError(error: Int) { status.text = "Гласово разпознаване: грешка $error" }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                voiceTarget?.userDescription = text
                status.text = if (text.isBlank()) "Няма разпознат текст." else "Записано към стената: $text"
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bg-BG")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Опиши стената и слоевете зад нея")
        }
        recognizer?.startListening(intent)
    }
}
