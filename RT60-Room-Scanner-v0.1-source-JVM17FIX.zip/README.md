# RT60 Room Scanner v0.1

Android companion app for RT60 Room Decay Corrector.

## v0.1 scope

- ARCore camera tracking.
- Vertical plane discovery for walls.
- ARCore Depth enabled automatically when supported.
- Bulgarian speech description attached to the nearest scanned wall.
- One-file export: `.rtroom`.
- `.rtroom` is a ZIP container with `room.json` + manifest.

Example spoken description:

`Тази стена е гипсокартон 12.5 милиметра, зад него има 10 сантиметра каменна вата, след това тухла.`

The app intentionally does not guess hidden construction. Unknown construction remains unknown until the user describes it.

## Important v0.1 limitation

ARCore plane polygons are an MVP geometry source, not yet a final architectural mesh. v0.2 should add scan coverage, wall merging/corner reconstruction and stronger room closure validation before the `.rtroom` file is used for acoustic prediction.


## v0.1-JVM17 fix
Java and Kotlin compile targets are both set to JVM 17 for GitHub Actions/Gradle 8.10.2 compatibility.
