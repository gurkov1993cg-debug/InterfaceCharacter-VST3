# RT60 Room Decay Corrector v0.2

Frequency-dependent room-decay measurement and correction prototype with shared core for a Windows standalone app and VST3.

## v0.2 measurement path

The standalone application now contains a real measurement path:

1. Select measurement microphone input and monitor output.
2. `MEASURE ROOM` plays a logarithmic exponential sweep with pre-silence and a decay tail.
3. The microphone is captured synchronously while the sweep is played.
4. FFT-domain regularized deconvolution recovers the room impulse response.
5. The impulse response is split into 29 one-third-octave analysis bands (25 Hz to 16 kHz).
6. Schroeder reverse integration creates the energy-decay curve for every usable band.
7. EDT, T20 and T30 are estimated by linear regression. T30 is preferred, then T20, then EDT when the available dynamic range is smaller.
8. The orange `Measured` RT60 line is replaced by the real measurement.
9. Change Target RT60 / Strength / Max Cut and the green `Predicted After` line updates immediately.
10. Press `RE-MEASURE AFTER` to obtain the real purple `Measured After` curve.

The app warns about clipped captures and too few usable decay bands.

## Graph

- Orange: Measured
- Blue: Target
- Green: Predicted After
- Purple: Measured After (real second measurement)

`Predicted After` is intentionally labelled as a prediction. Software cannot remove acoustic energy already stored in the room; the correction stage reduces excitation of long-decay bands. `Measured After` is the verification.

## Core tests

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

The test suite checks both the decay-correction model and the measurement engine, including sweep deconvolution and RT60 recovery from a synthetic broadband decay.

## Windows standalone + VST3

```powershell
cmake -S . -B build-juce -A x64 -DRT60_BUILD_JUCE=ON
cmake --build build-juce --config Release
```

JUCE is fetched automatically by CMake.

## Measurement note

The current 1/3-octave filters are stable cascaded Butterworth analysis filters rather than a claim of IEC 61260 certification. The architecture is prepared for standards-certified filters and calibration files in a later measurement-validation stage.
