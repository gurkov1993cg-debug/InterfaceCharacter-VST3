#pragma once

#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>

#include "core/DecayModel.hpp"
#include "core/MeasurementEngine.hpp"
#include "ui/RT60Graph.hpp"

#include <atomic>
#include <vector>

class MainComponent final : public juce::Component,
                            private juce::AudioIODeviceCallback,
                            private juce::Timer {
public:
    MainComponent();
    ~MainComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void refreshModel();
    void startMeasurement(bool afterCorrection);
    void finishMeasurementOnMessageThread();
    void updateMeasurementConfigFromDevice();

    void audioDeviceIOCallbackWithContext(const float* const* inputChannelData,
                                          int numInputChannels,
                                          float* const* outputChannelData,
                                          int numOutputChannels,
                                          int numSamples,
                                          const juce::AudioIODeviceCallbackContext&) override;
    void audioDeviceAboutToStart(juce::AudioIODevice* device) override;
    void audioDeviceStopped() override;
    void timerCallback() override;

    rt60::DecayModel model_;
    rt60::MeasurementEngine measurement_;
    RT60Graph graph_;

    juce::AudioDeviceManager deviceManager_;
    juce::AudioDeviceSelectorComponent deviceSelector_;

    juce::Slider targetSlider_;
    juce::Slider strengthSlider_;
    juce::Slider maxCutSlider_;
    juce::Slider sweepLevelSlider_;
    juce::Label title_;
    juce::Label targetLabel_, strengthLabel_, maxCutLabel_, sweepLevelLabel_, status_;
    juce::TextButton demoButton_{"LOAD DEMO"};
    juce::TextButton measureButton_{"MEASURE ROOM"};
    juce::TextButton remeasureButton_{"RE-MEASURE AFTER"};

    std::vector<float> excitation_;
    std::vector<float> capture_;
    std::atomic<std::size_t> measurementPosition_{0};
    std::atomic<bool> measuring_{false};
    std::atomic<bool> measurementFinished_{false};
    bool measurementIsAfter_ = false;
};
