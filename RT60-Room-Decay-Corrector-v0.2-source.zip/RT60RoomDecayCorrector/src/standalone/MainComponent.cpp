#include "standalone/MainComponent.hpp"

#include <algorithm>
#include <cmath>

MainComponent::MainComponent()
    : deviceSelector_(deviceManager_, 1, 2, 1, 2, false, false, true, false)
{
    setSize(1160, 820);
    title_.setText("RT60 ROOM DECAY CORRECTOR", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(24.0f, juce::Font::bold));
    title_.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(title_);

    graph_.setModel(&model_);
    addAndMakeVisible(graph_);
    addAndMakeVisible(deviceSelector_);

    auto setup = [this](juce::Slider& s, double min, double max, double step) {
        s.setRange(min, max, step);
        s.setSliderStyle(juce::Slider::LinearHorizontal);
        s.setTextBoxStyle(juce::Slider::TextBoxRight, false, 90, 24);
        addAndMakeVisible(s);
    };
    setup(targetSlider_, 100.0, 1200.0, 5.0);
    setup(strengthSlider_, 0.0, 100.0, 1.0);
    setup(maxCutSlider_, 0.0, 18.0, 0.5);
    setup(sweepLevelSlider_, -40.0, -6.0, 1.0);
    targetSlider_.setValue(300.0);
    strengthSlider_.setValue(75.0);
    maxCutSlider_.setValue(9.0);
    sweepLevelSlider_.setValue(-18.0);
    targetSlider_.setTextValueSuffix(" ms");
    strengthSlider_.setTextValueSuffix(" %");
    maxCutSlider_.setTextValueSuffix(" dB");
    sweepLevelSlider_.setTextValueSuffix(" dBFS");

    targetLabel_.setText("Target RT60", juce::dontSendNotification);
    strengthLabel_.setText("Correction strength", juce::dontSendNotification);
    maxCutLabel_.setText("Maximum band cut", juce::dontSendNotification);
    sweepLevelLabel_.setText("Measurement sweep", juce::dontSendNotification);
    for (auto* l : {&targetLabel_, &strengthLabel_, &maxCutLabel_, &sweepLevelLabel_})
        addAndMakeVisible(*l);

    addAndMakeVisible(demoButton_);
    addAndMakeVisible(measureButton_);
    addAndMakeVisible(remeasureButton_);
    remeasureButton_.setEnabled(false);
    status_.setText("Select microphone input and monitor output, then press MEASURE ROOM.", juce::dontSendNotification);
    addAndMakeVisible(status_);

    targetSlider_.onValueChange = [this] { refreshModel(); };
    strengthSlider_.onValueChange = [this] { refreshModel(); };
    maxCutSlider_.onValueChange = [this] { refreshModel(); };
    sweepLevelSlider_.onValueChange = [this] { updateMeasurementConfigFromDevice(); };
    demoButton_.onClick = [this] {
        model_.setDemoRoom();
        refreshModel();
        remeasureButton_.setEnabled(false);
        status_.setText("Demo curve loaded. Real measurement replaces the orange line.", juce::dontSendNotification);
    };
    measureButton_.onClick = [this] { startMeasurement(false); };
    remeasureButton_.onClick = [this] { startMeasurement(true); };

    const auto error = deviceManager_.initialise(1, 2, nullptr, true);
    if (error.isNotEmpty())
        status_.setText("Audio device error: " + error, juce::dontSendNotification);
    deviceManager_.addAudioCallback(this);
    updateMeasurementConfigFromDevice();
    refreshModel();
    startTimerHz(20);
}

MainComponent::~MainComponent()
{
    stopTimer();
    deviceManager_.removeAudioCallback(this);
}

void MainComponent::refreshModel()
{
    model_.setUniformTarget(static_cast<float>(targetSlider_.getValue()));
    model_.setStrength(static_cast<float>(strengthSlider_.getValue()) / 100.0f);
    model_.setMaxCutDb(static_cast<float>(maxCutSlider_.getValue()));
    graph_.repaint();
}

void MainComponent::updateMeasurementConfigFromDevice()
{
    auto cfg = measurement_.config();
    if (auto* device = deviceManager_.getCurrentAudioDevice())
        cfg.sampleRate = device->getCurrentSampleRate();
    cfg.level = std::pow(10.0f, static_cast<float>(sweepLevelSlider_.getValue()) / 20.0f);
    measurement_.setConfig(cfg);
}

void MainComponent::startMeasurement(bool afterCorrection)
{
    if (measuring_.load())
        return;
    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr) {
        status_.setText("No active audio device.", juce::dontSendNotification);
        return;
    }

    updateMeasurementConfigFromDevice();
    excitation_ = measurement_.makeExcitation();
    capture_.assign(excitation_.size(), 0.0f);
    measurementPosition_.store(0);
    measurementFinished_.store(false);
    measurementIsAfter_ = afterCorrection;
    measuring_.store(true);
    measureButton_.setEnabled(false);
    remeasureButton_.setEnabled(false);
    demoButton_.setEnabled(false);
    status_.setText(afterCorrection
        ? "Measuring AFTER correction... keep the room quiet."
        : "Measuring room... keep the room quiet.", juce::dontSendNotification);
}

void MainComponent::audioDeviceIOCallbackWithContext(const float* const* inputChannelData,
                                                      int numInputChannels,
                                                      float* const* outputChannelData,
                                                      int numOutputChannels,
                                                      int numSamples,
                                                      const juce::AudioIODeviceCallbackContext&)
{
    for (int ch = 0; ch < numOutputChannels; ++ch)
        if (outputChannelData[ch] != nullptr)
            juce::FloatVectorOperations::clear(outputChannelData[ch], numSamples);

    if (!measuring_.load(std::memory_order_acquire))
        return;

    std::size_t pos = measurementPosition_.load(std::memory_order_relaxed);
    for (int i = 0; i < numSamples; ++i) {
        if (pos >= excitation_.size()) {
            measuring_.store(false, std::memory_order_release);
            measurementFinished_.store(true, std::memory_order_release);
            break;
        }

        const float out = excitation_[pos];
        for (int ch = 0; ch < numOutputChannels; ++ch)
            if (outputChannelData[ch] != nullptr)
                outputChannelData[ch][i] = out;

        float in = 0.0f;
        int validInputs = 0;
        for (int ch = 0; ch < numInputChannels; ++ch) {
            if (inputChannelData[ch] != nullptr) {
                in += inputChannelData[ch][i];
                ++validInputs;
            }
        }
        if (validInputs > 0)
            in /= static_cast<float>(validInputs);
        capture_[pos] = in;
        ++pos;
    }
    measurementPosition_.store(pos, std::memory_order_release);
}

void MainComponent::audioDeviceAboutToStart(juce::AudioIODevice* device)
{
    if (device != nullptr) {
        auto cfg = measurement_.config();
        cfg.sampleRate = device->getCurrentSampleRate();
        measurement_.setConfig(cfg);
    }
}

void MainComponent::audioDeviceStopped()
{
    measuring_.store(false);
}

void MainComponent::timerCallback()
{
    if (measuring_.load()) {
        const auto total = std::max<std::size_t>(1, excitation_.size());
        const auto current = measurementPosition_.load();
        const int percent = static_cast<int>(100.0 * static_cast<double>(current) / static_cast<double>(total));
        status_.setText("Measurement in progress: " + juce::String(percent) + "%", juce::dontSendNotification);
    }
    if (measurementFinished_.exchange(false))
        finishMeasurementOnMessageThread();
}

void MainComponent::finishMeasurementOnMessageThread()
{
    status_.setText("Analysing impulse response and RT60 bands...", juce::dontSendNotification);
    const auto result = measurement_.analyseCapture(capture_);

    int validBands = 0;
    for (std::size_t i = 0; i < result.bands.size(); ++i) {
        if (!result.bands[i].valid)
            continue;
        ++validBands;
        if (measurementIsAfter_)
            model_.setMeasuredAfter(i, result.bands[i].rt60Ms);
        else
            model_.setMeasured(i, result.bands[i].rt60Ms);
    }
    refreshModel();

    measureButton_.setEnabled(true);
    demoButton_.setEnabled(true);
    remeasureButton_.setEnabled(validBands >= 8);

    juce::String message = "Measured " + juce::String(validBands) + " RT60 bands | peak "
                         + juce::String(result.peakDbFs, 1) + " dBFS";
    if (result.clipped)
        message += " | WARNING: input clipped - lower sweep or mic gain";
    else if (validBands < 8)
        message += " | too little usable decay data; raise SNR or extend tail";
    else
        message += measurementIsAfter_ ? " | Measured After updated" : " | orange Measured curve updated";
    status_.setText(message, juce::dontSendNotification);
}

void MainComponent::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(14, 16, 20));
}

void MainComponent::resized()
{
    auto r = getLocalBounds().reduced(20);
    title_.setBounds(r.removeFromTop(42));

    auto top = r.removeFromTop(500);
    auto graphArea = top.removeFromLeft(static_cast<int>(top.getWidth() * 0.75f));
    graph_.setBounds(graphArea);
    top.removeFromLeft(12);
    deviceSelector_.setBounds(top);

    r.removeFromTop(10);
    auto setRow = [](juce::Rectangle<int> row, juce::Label& label, juce::Slider& slider) {
        label.setBounds(row.removeFromLeft(190));
        slider.setBounds(row);
    };
    setRow(r.removeFromTop(36), targetLabel_, targetSlider_);
    setRow(r.removeFromTop(36), strengthLabel_, strengthSlider_);
    setRow(r.removeFromTop(36), maxCutLabel_, maxCutSlider_);
    setRow(r.removeFromTop(36), sweepLevelLabel_, sweepLevelSlider_);

    auto buttons = r.removeFromTop(38);
    demoButton_.setBounds(buttons.removeFromLeft(180));
    buttons.removeFromLeft(10);
    measureButton_.setBounds(buttons.removeFromLeft(200));
    buttons.removeFromLeft(10);
    remeasureButton_.setBounds(buttons.removeFromLeft(220));
    status_.setBounds(r.removeFromTop(32));
}
