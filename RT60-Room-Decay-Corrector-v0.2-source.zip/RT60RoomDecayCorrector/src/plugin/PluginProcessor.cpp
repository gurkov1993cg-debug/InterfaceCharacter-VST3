#include "plugin/PluginProcessor.hpp"
#include "plugin/PluginEditor.hpp"

namespace {
constexpr std::array<float, 10> kFreqs{{40, 63, 100, 160, 250, 400, 630, 1000, 2500, 6300}};
}

juce::AudioProcessorValueTreeState::ParameterLayout RT60Processor::createParameters()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back(std::make_unique<juce::AudioParameterFloat>("target", "Target RT60", juce::NormalisableRange<float>(100, 1000, 5), 300));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("strength", "Strength", juce::NormalisableRange<float>(0, 100, 1), 75));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("maxcut", "Max Cut", juce::NormalisableRange<float>(0, 18, 0.5f), 9));
    p.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));
    return {p.begin(), p.end()};
}

RT60Processor::RT60Processor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", createParameters())
{
    model_.setDemoRoom();
}

bool RT60Processor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainInputChannelSet() == layouts.getMainOutputChannelSet()
        && (layouts.getMainOutputChannelSet() == juce::AudioChannelSet::mono()
            || layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo());
}

void RT60Processor::prepareToPlay(double sampleRate, int)
{
    sampleRate_ = sampleRate;
    rebuildFilters();
}

void RT60Processor::updateModelFromParameters()
{
    model_.setUniformTarget(apvts.getRawParameterValue("target")->load());
    model_.setStrength(apvts.getRawParameterValue("strength")->load() / 100.0f);
    model_.setMaxCutDb(apvts.getRawParameterValue("maxcut")->load());
}

void RT60Processor::rebuildFilters()
{
    updateModelFromParameters();
    const auto& bands = model_.bands();
    for (int i = 0; i < kFilterBands; ++i) {
        std::size_t nearest = 0;
        float best = 1.0e9f;
        for (std::size_t b = 0; b < bands.size(); ++b) {
            const float d = std::abs(std::log(bands[b].frequencyHz / kFreqs[(std::size_t)i]));
            if (d < best) { best = d; nearest = b; }
        }
        const float gain = juce::Decibels::decibelsToGain(bands[nearest].correctionDb);
        auto coeff = juce::dsp::IIR::Coefficients<float>::makePeakFilter(sampleRate_, kFreqs[(std::size_t)i], 4.0f, gain);
        leftFilters_[(std::size_t)i].coefficients = coeff;
        rightFilters_[(std::size_t)i].coefficients = coeff;
        leftFilters_[(std::size_t)i].reset(); rightFilters_[(std::size_t)i].reset();
    }
}

void RT60Processor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    if (apvts.getRawParameterValue("bypass")->load() > 0.5f) return;
    rebuildFilters(); // prototype: simple and deterministic; next version will smooth/rebuild off audio thread

    for (int ch = 0; ch < buffer.getNumChannels(); ++ch) {
        auto* data = buffer.getWritePointer(ch);
        auto& bank = ch == 0 ? leftFilters_ : rightFilters_;
        for (int n = 0; n < buffer.getNumSamples(); ++n) {
            float x = data[n];
            for (auto& f : bank) x = f.processSample(x);
            data[n] = x;
        }
    }
}

juce::AudioProcessorEditor* RT60Processor::createEditor() { return new RT60Editor(*this); }

void RT60Processor::getStateInformation(juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, dest);
}

void RT60Processor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size)) apvts.replaceState(juce::ValueTree::fromXml(*xml));
    rebuildFilters();
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new RT60Processor(); }
