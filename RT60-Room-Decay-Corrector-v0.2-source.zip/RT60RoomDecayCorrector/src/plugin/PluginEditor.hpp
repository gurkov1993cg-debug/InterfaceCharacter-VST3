#pragma once

#include <juce_gui_extra/juce_gui_extra.h>
#include "plugin/PluginProcessor.hpp"
#include "ui/RT60Graph.hpp"

class RT60Editor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit RT60Editor(RT60Processor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    RT60Processor& processor_;
    RT60Graph graph_;
    juce::Slider target_, strength_, maxCut_;
    juce::Label title_;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<SliderAttachment> targetA_, strengthA_, maxCutA_;
};
