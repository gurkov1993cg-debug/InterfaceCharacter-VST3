#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "core/DecayModel.hpp"

class RT60Processor final : public juce::AudioProcessor {
public:
    RT60Processor();
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "RT60 Room Decay Corrector"; }
    double getTailLengthSeconds() const override { return 0.0; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;
    rt60::DecayModel& model() noexcept { return model_; }
    void updateModelFromParameters();

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameters();
    void rebuildFilters();

    rt60::DecayModel model_;
    double sampleRate_ = 48000.0;
    static constexpr int kFilterBands = 10;
    std::array<juce::dsp::IIR::Filter<float>, kFilterBands> leftFilters_;
    std::array<juce::dsp::IIR::Filter<float>, kFilterBands> rightFilters_;
};
