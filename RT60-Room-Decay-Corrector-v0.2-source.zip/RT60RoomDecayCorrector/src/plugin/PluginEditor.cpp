#include "plugin/PluginEditor.hpp"

RT60Editor::RT60Editor(RT60Processor& p) : AudioProcessorEditor(&p), processor_(p)
{
    setSize(900, 600);
    graph_.setModel(&processor_.model()); addAndMakeVisible(graph_);
    title_.setText("RT60 ROOM DECAY CORRECTOR", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(22.0f, juce::Font::bold)); addAndMakeVisible(title_);
    for (auto* s : {&target_, &strength_, &maxCut_}) {
        s->setSliderStyle(juce::Slider::LinearHorizontal);
        s->setTextBoxStyle(juce::Slider::TextBoxRight, false, 80, 24);
        addAndMakeVisible(*s);
    }
    targetA_ = std::make_unique<SliderAttachment>(processor_.apvts, "target", target_);
    strengthA_ = std::make_unique<SliderAttachment>(processor_.apvts, "strength", strength_);
    maxCutA_ = std::make_unique<SliderAttachment>(processor_.apvts, "maxcut", maxCut_);
    startTimerHz(20);
}

void RT60Editor::timerCallback() { processor_.updateModelFromParameters(); graph_.repaint(); }
void RT60Editor::paint(juce::Graphics& g) { g.fillAll(juce::Colour::fromRGB(14,16,20)); }
void RT60Editor::resized()
{
    auto r = getLocalBounds().reduced(18);
    title_.setBounds(r.removeFromTop(38));
    graph_.setBounds(r.removeFromTop(410));
    target_.setBounds(r.removeFromTop(42)); strength_.setBounds(r.removeFromTop(42)); maxCut_.setBounds(r.removeFromTop(42));
}
