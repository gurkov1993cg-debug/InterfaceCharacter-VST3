#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "core/CorrectionEngine.hpp"
#include "core/DecayModel.hpp"
#include "core/WaterfallData.hpp"
#include "core/DisplaySnapshot.hpp"

#include <array>
#include <atomic>

class RT60Processor final : public juce::AudioProcessor {
public:
    RT60Processor();
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "RT60 Room Decay Corrector"; }
    double getTailLengthSeconds() const override { return 0.0; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;
    rt60::DecayModel& model() noexcept { return model_; }
    bool reloadActiveProfile();
    int activeStageCount() const noexcept;
    bool hasActiveProfile() const noexcept { return hasProfile_.load(std::memory_order_acquire); }
    const rt60::WaterfallData* waterfall(int channel, bool afterCorrection) const noexcept;

private:
    struct BankPair {
        rt60::CorrectionFilterBank left;
        rt60::CorrectionFilterBank right;
    };

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameters();
    static juce::File profileDirectory();
    static juce::File activeProfileFile(int channel);
    static juce::File legacyProfileFile();
    static juce::File waterfallFile(int channel, bool afterCorrection);
    static juce::File displaySnapshotFile();
    void applyProfileToModel();
    void loadWaterfallSnapshots();
    void loadDisplaySnapshot();
    void publishBanks();

    rt60::DecayModel model_;
    std::array<rt60::CorrectionProfile, 2> profiles_{};
    std::array<rt60::WaterfallData, 2> beforeWaterfalls_{};
    std::array<rt60::WaterfallData, 2> afterWaterfalls_{};
    std::array<BankPair, 3> bankSlots_{};
    std::atomic<int> activeBankIndex_{0};
    std::atomic<int> pendingBankIndex_{-1};
    std::atomic<bool> hasProfile_{false};
    double sampleRate_ = 48000.0;
};
