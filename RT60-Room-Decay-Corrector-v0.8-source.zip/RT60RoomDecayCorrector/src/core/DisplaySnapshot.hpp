#pragma once

#include "core/DecayModel.hpp"

#include <array>
#include <string>

namespace rt60 {

struct DisplaySnapshot {
    static constexpr int kFormatVersion = 1;
    std::array<float, kBandCount> beforeMs{};
    std::array<bool, kBandCount> beforeValid{};
    std::array<float, kBandCount> afterMs{};
    std::array<bool, kBandCount> afterValid{};

    bool hasBefore() const noexcept;
    bool hasAfter() const noexcept;
};

class DisplaySnapshotCodec {
public:
    static std::string serialize(const DisplaySnapshot& snapshot);
    static bool deserialize(const std::string& text, DisplaySnapshot& snapshot);
};

} // namespace rt60
