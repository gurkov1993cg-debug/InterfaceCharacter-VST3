#include "core/DisplaySnapshot.hpp"

#include <cmath>
#include <iomanip>
#include <sstream>

namespace rt60 {
namespace {

bool validMs(float value) noexcept
{
    return std::isfinite(value) && value >= 0.0f && value <= 10000.0f;
}

} // namespace

bool DisplaySnapshot::hasBefore() const noexcept
{
    for (bool valid : beforeValid)
        if (valid)
            return true;
    return false;
}

bool DisplaySnapshot::hasAfter() const noexcept
{
    for (bool valid : afterValid)
        if (valid)
            return true;
    return false;
}

std::string DisplaySnapshotCodec::serialize(const DisplaySnapshot& snapshot)
{
    std::ostringstream out;
    out << "RT60_DISPLAY_SNAPSHOT " << DisplaySnapshot::kFormatVersion << '\n';
    out << std::setprecision(9);
    for (std::size_t i = 0; i < kBandCount; ++i) {
        out << "B " << i << ' '
            << snapshot.beforeMs[i] << ' ' << (snapshot.beforeValid[i] ? 1 : 0) << ' '
            << snapshot.afterMs[i] << ' ' << (snapshot.afterValid[i] ? 1 : 0) << '\n';
    }
    return out.str();
}

bool DisplaySnapshotCodec::deserialize(const std::string& text, DisplaySnapshot& snapshot)
{
    std::istringstream in(text);
    std::string magic;
    int version = 0;
    if (!(in >> magic >> version) || magic != "RT60_DISPLAY_SNAPSHOT"
        || version != DisplaySnapshot::kFormatVersion)
        return false;

    DisplaySnapshot parsed;
    std::array<bool, kBandCount> seen{};
    for (std::size_t row = 0; row < kBandCount; ++row) {
        char tag = 0;
        std::size_t index = 0;
        float before = 0.0f;
        int beforeValid = 0;
        float after = 0.0f;
        int afterValid = 0;
        if (!(in >> tag >> index >> before >> beforeValid >> after >> afterValid)
            || tag != 'B' || index >= kBandCount || seen[index]
            || (beforeValid != 0 && beforeValid != 1)
            || (afterValid != 0 && afterValid != 1)
            || !validMs(before) || !validMs(after))
            return false;
        seen[index] = true;
        parsed.beforeMs[index] = before;
        parsed.beforeValid[index] = beforeValid != 0;
        parsed.afterMs[index] = after;
        parsed.afterValid[index] = afterValid != 0;
    }

    for (bool value : seen)
        if (!value)
            return false;

    std::string trailing;
    if (in >> trailing)
        return false;

    snapshot = parsed;
    return true;
}

} // namespace rt60
