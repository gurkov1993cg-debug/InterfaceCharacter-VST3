# RT60 Room Decay Corrector v0.8

v0.8 fixes the user-visible workflow around measured BEFORE/AFTER data and profile saving.

## Real workflow

1. Select one measurement microphone input and two monitor outputs.
2. Press **MEASURE L + R**. LEFT and RIGHT are swept separately.
3. Press **AUTO CORRECT RT60**. By default **AUTO VERIFY + AFTER GRAPH** is ON, so the app automatically sweeps LEFT and RIGHT again through the correction.
4. The 2D RT60 graph shows **Measured Before / Target / Model Estimate / Measured After** and the waterfall automatically switches to the real measured **AFTER** view when verification is complete.
5. Press **SAVE PROFILE AS...**. The operating-system Save dialog asks for a file name and location and writes one `.rt60profile` bundle containing both correction channels, BEFORE/AFTER waterfalls, and the RT60 display snapshot.
6. Saving also updates the private active mirror used by the VST3 in Cubase. In the VST3 press **Reload Saved Profile** if Cubase was already open.
7. **LOAD PROFILE...** opens any previously saved `.rt60profile` and makes it active for the VST3.

## Safety / DSP

- Separate LEFT and RIGHT measurement and correction.
- Explicit measurement microphone input.
- Live clipping abort.
- Default correction limit 300 Hz.
- Non-boosting decay correction.
- Transactional profile and display-snapshot parsing.
- No FFT, file I/O, allocation, or rendering in the real-time audio callback.

## Tests

Core, measurement, correction, uniformity, waterfall, and display-snapshot tests are included.
