#include "core/DisplaySnapshot.hpp"

#include <cassert>
#include <string>

int main()
{
    rt60::DisplaySnapshot source;
    source.beforeMs[0] = 640.0f;
    source.beforeValid[0] = true;
    source.afterMs[0] = 330.0f;
    source.afterValid[0] = true;
    source.beforeMs[8] = 410.0f;
    source.beforeValid[8] = true;

    assert(source.hasBefore());
    assert(source.hasAfter());

    const std::string encoded = rt60::DisplaySnapshotCodec::serialize(source);
    rt60::DisplaySnapshot roundTrip;
    assert(rt60::DisplaySnapshotCodec::deserialize(encoded, roundTrip));
    assert(roundTrip.beforeValid[0] && roundTrip.afterValid[0]);
    assert(roundTrip.beforeMs[0] == 640.0f);
    assert(roundTrip.afterMs[0] == 330.0f);

    rt60::DisplaySnapshot sentinel;
    sentinel.beforeMs[3] = 777.0f;
    sentinel.beforeValid[3] = true;
    const auto truncated = encoded.substr(0, encoded.size() / 2);
    assert(!rt60::DisplaySnapshotCodec::deserialize(truncated, sentinel));
    assert(sentinel.beforeValid[3] && sentinel.beforeMs[3] == 777.0f);

    return 0;
}
