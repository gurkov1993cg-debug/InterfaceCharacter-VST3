# RT60 Room Decay Corrector v20.2

v20 keeps the standalone interface to the approved dashboard layout and fixes the profile workflow so saved room data can be loaded later in the standalone app and in the VST3.

## Standalone workflow

1. NEW MEASUREMENT
2. MEASURE ROOM L+R
3. AUTO CORRECT + VERIFY
4. SAVE PROFILE AS...
5. LOAD PROFILE...

The dashboard shows RT60 BEFORE / TARGET / AFTER, worst frequency, overall improvement, BEFORE/AFTER waterfalls, the real correction response, audio device, input, sample rate, buffer size, input trim and measurement state.

The correction panel also exposes the real controls again: TARGET RT60, CORRECTION AMOUNT (%), CORRECT UP TO (Hz), TEST SWEEP LEVEL, AUTO TARGET and CORRECTION ACTIVE.

## Real profile data

`.rt60profile` v4 stores:
- LEFT and RIGHT correction stages
- real BEFORE per-band measurement summaries
- real AFTER per-band measurement summaries
- BEFORE and AFTER display curves
- BEFORE and AFTER waterfalls when available
- sample rate, target, correction range, verification state, profile name and timestamp

v4 adds an end-to-end checksum. Profile bytes are written exactly, then the saved file is read back and parsed before SAVE is reported as successful. The shared VST3 mirror is also written and read-back validated.

Older v1/v2/v3 profile bundles remain loadable. Recoverable v16 CRLF-damaged bundles are canonicalised before parsing.

## VST3

The VST3 LOAD PROFILE button loads the same `.rt60profile` and immediately configures the real stereo correction DSP. v20 also embeds the loaded profile bundle inside the DAW project state, so reopening the Cubase project restores the exact profile that was used in that project.

## Windows ASIO / E-MU

The selected measurement input is chosen inside the audio callback while its hardware input pair remains open. This avoids sparse one-channel ASIO reopens that can be problematic with legacy E-MU/PatchMix drivers. The actual device sample rate is used by sweep generation, capture, analysis and correction.

## Tests

Core regression suite: 9/9 tests, including:
- measurement and correction DSP
- display/waterfall state
- real profile data round-trip
- exact binary file write/read
- two different room profiles remain different after reload
- CRLF recovery
- truncation/corruption rejection
- v4 checksum tamper rejection


## v20 live-UI and control restoration

- Restores visible TARGET RT60, CORRECTION AMOUNT (%), CORRECT UP TO (Hz), TEST SWEEP LEVEL, AUTO TARGET and CORRECTION ACTIVE controls.
- Keeps the main workflow buttons large instead of shrinking them when controls are added.

- Restores the real live microphone level meter and PRE/POST readout.
- Adds a real 2-second TEST MIC action that verifies the selected host input and reports peak/RMS/clipping.
- Removes continuous full-window and waterfall repaints; device-input enumeration is throttled to about once per second.
- Halves live meter callback work by deriving POST level from PRE level and digital trim instead of scanning the block twice.
- BEFORE and AFTER waterfalls now share the BEFORE absolute reference, so a measured level reduction is not hidden by independent normalization.
- Waterfall serialization v2 preserves the absolute reference while remaining compatible with v1 saved waterfall data.

## v20.1 fixes

- Reverted the per-column waterfall normalisation. Each frequency starting at
  its own 0 dB reference removes any level difference between BEFORE and AFTER
  by construction, and draws an empty band as a flat line at the top. The
  shared BEFORE absolute reference described above is restored.
  `WaterfallAnalyzer::decayLevelDb()` is kept and covered by its test, but is
  not wired into the graph; it belongs behind an explicit "decay slope" view
  mode, not as the default.
- Fixed a data race between `publishBanks()` and the audio thread. Active and
  pending slot indices are now one packed atomic, so a single load always
  yields a consistent pair and the message thread can never reconfigure the
  slot that playback has just switched to.
- `getTailLengthSeconds()` reports the longest correction pole instead of zero,
  so offline bounces no longer truncate the correction tail.
- Added `tests/test_decay_dsp.cpp`: the first test that exercises the actual
  DSP rather than serialisation. It measures a synthetic 63 Hz / 500 ms and
  100 Hz / 300 ms mode, then runs a 500 ms mode through a 500 -> 250 ms
  correction stage and verifies the result.

## v20.1 mode detection

The 1/3-octave band search is no longer how modes are found. `ModeDetector`
estimates the poles of the low-frequency impulse response directly (least
squares linear prediction, then a joint fit of all damped exponentials) and
`CorrectionEngine::design()` builds its stages from those poles.

The band search stayed as the fallback for captures the detector cannot model,
selected by `allowConservativeBandFallback`, and can be forced with
`useModeDetector = false`.

Measured on synthetic rooms, against the previous band search:

| case | old result | new result |
|---|---|---|
| mode at 68 Hz between two band centres | never found; candidate clamped to 71.6 Hz | found at 68.0 Hz, corrected 860 -> 379 ms |
| 450 ms mode beside a 1300 ms neighbour | read as 1063 ms, left at 971 ms after correction | read as 450 ms, corrected to 342 ms |
| modes off the band centres (37.3 / 52.8 / 71.4 Hz) | frequency right, decay 5-25% high | decay within 2% |

Detection costs about 300 ms per measurement.

### Still open

- Switching banks resets the filter state, so changing profile or bypass during
  playback clicks. Needs a short crossfade across both audio paths.
- `estimatedQ` is computed, optimised and serialised but never reaches
  `makeStage()`.

## v20.2 fixes

- WATERFALL (Decay) now renders the same per-frequency decay quantity exercised by
  `WaterfallAnalyzer::decayLevelDb()`. The graph no longer tests one quantity and
  draws another; BEFORE/AFTER can still share the overall level offset while the
  ridge shape follows the measured decay at each frequency.
- Fixed mixed-unit candidate ranking when `ModeDetector` and conservative band
  fallback are both enabled. Mode `energyShare` is no longer compared directly
  with FFT peak power; each candidate family is normalised against its own
  strongest candidate.
- A precise detected pole suppresses only the overlapping coarse 1/3-octave
  fallback candidate. Separate fallback bands remain available.
- The automatic second-pass fallback now explicitly disables `ModeDetector`, so
  a failed detector-confidence pass really falls back to the conservative band
  path instead of mixing a second low-confidence pole set into it.
- Added `rt60_mode_detector_fallback_tests`, pinning the 58/68 Hz regression while
  conservative fallback is enabled.
- Cubase project-state recall restores the embedded profile only to that plug-in
  instance; it no longer overwrites the machine-wide active profile mirror.
- Corrected the newer-profile warning for the v20 version scheme and marked the
  application/source as 20.2.0.

Core Release and ASan/UBSan regression suites: 13/13 tests passed locally.
