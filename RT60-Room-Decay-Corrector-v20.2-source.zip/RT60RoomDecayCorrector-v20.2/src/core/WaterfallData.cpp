#include "core/WaterfallData.hpp"

#include <algorithm>
#include <cmath>
#include <complex>
#include <iomanip>
#include <limits>
#include <sstream>

namespace rt60 {
namespace {

constexpr double kPi = 3.1415926535897932384626433832795;

bool isPowerOfTwo(std::size_t n) noexcept
{
    return n >= 2 && (n & (n - 1u)) == 0;
}

void fft(std::vector<std::complex<double>>& a)
{
    const std::size_t n = a.size();
    for (std::size_t i = 1, j = 0; i < n; ++i) {
        std::size_t bit = n >> 1u;
        for (; j & bit; bit >>= 1u)
            j ^= bit;
        j ^= bit;
        if (i < j)
            std::swap(a[i], a[j]);
    }

    for (std::size_t len = 2; len <= n; len <<= 1u) {
        const double angle = -2.0 * kPi / static_cast<double>(len);
        const std::complex<double> wlen(std::cos(angle), std::sin(angle));
        for (std::size_t i = 0; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (std::size_t j = 0; j < len / 2; ++j) {
                const auto u = a[i + j];
                const auto v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
}

float interpolateMagnitude(const std::vector<double>& magnitude, double bin)
{
    if (magnitude.empty())
        return 0.0f;
    const auto lo = static_cast<std::size_t>(std::max(0.0, std::floor(bin)));
    if (lo >= magnitude.size() - 1)
        return static_cast<float>(magnitude.back());
    const std::size_t hi = lo + 1;
    const double frac = bin - static_cast<double>(lo);
    return static_cast<float>(magnitude[lo] * (1.0 - frac) + magnitude[hi] * frac);
}

bool finiteVector(const std::vector<float>& values)
{
    return std::all_of(values.begin(), values.end(), [](float v) { return std::isfinite(v); });
}

} // namespace

WaterfallData WaterfallAnalyzer::analyse(const std::vector<float>& impulseResponse,
                                         double sampleRate,
                                         const WaterfallConfig& config)
{
    WaterfallData out;
    out.sampleRate = sampleRate;
    out.floorDb = config.floorDb;

    if (impulseResponse.empty() || sampleRate <= 1000.0 || !isPowerOfTwo(config.fftSize)
        || config.frequencyPoints < 8 || config.minHz <= 0.0f || config.maxHz <= config.minHz
        || config.maxHz >= static_cast<float>(sampleRate * 0.49)
        || config.maxTimeMs <= 0.0f || config.timeStepMs <= 0.0f)
        return {};

    const auto peakIt = std::max_element(impulseResponse.begin(), impulseResponse.end(),
        [](float a, float b) { return std::abs(a) < std::abs(b); });
    const std::size_t peakIndex = static_cast<std::size_t>(std::distance(impulseResponse.begin(), peakIt));

    out.frequenciesHz.resize(static_cast<std::size_t>(config.frequencyPoints));
    const double minLog = std::log(static_cast<double>(config.minHz));
    const double maxLog = std::log(static_cast<double>(config.maxHz));
    for (int i = 0; i < config.frequencyPoints; ++i) {
        const double alpha = config.frequencyPoints > 1
            ? static_cast<double>(i) / static_cast<double>(config.frequencyPoints - 1) : 0.0;
        out.frequenciesHz[static_cast<std::size_t>(i)] = static_cast<float>(std::exp(minLog + alpha * (maxLog - minLog)));
    }

    const int sliceCount = static_cast<int>(std::floor(config.maxTimeMs / config.timeStepMs)) + 1;
    out.timesMs.resize(static_cast<std::size_t>(sliceCount));
    for (int i = 0; i < sliceCount; ++i)
        out.timesMs[static_cast<std::size_t>(i)] = static_cast<float>(i) * config.timeStepMs;

    std::vector<float> raw(out.frequenciesHz.size() * out.timesMs.size(), 0.0f);
    double globalMax = 0.0;
    std::vector<std::complex<double>> spectrum(config.fftSize);
    std::vector<double> magnitude(config.fftSize / 2 + 1);

    for (std::size_t t = 0; t < out.timesMs.size(); ++t) {
        const auto offsetSamples = static_cast<std::size_t>(std::llround(
            static_cast<double>(out.timesMs[t]) * sampleRate / 1000.0));
        const std::size_t start = peakIndex + offsetSamples;

        for (std::size_t n = 0; n < config.fftSize; ++n) {
            const std::size_t source = start + n;
            const double sample = source < impulseResponse.size() ? impulseResponse[source] : 0.0;
            const double window = 0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(n)
                                                       / static_cast<double>(config.fftSize - 1));
            spectrum[n] = std::complex<double>(sample * window, 0.0);
        }
        fft(spectrum);
        for (std::size_t k = 0; k < magnitude.size(); ++k)
            magnitude[k] = std::abs(spectrum[k]);

        for (std::size_t f = 0; f < out.frequenciesHz.size(); ++f) {
            const double bin = static_cast<double>(out.frequenciesHz[f]) * static_cast<double>(config.fftSize) / sampleRate;
            const float mag = interpolateMagnitude(magnitude, bin);
            raw[t * out.frequenciesHz.size() + f] = mag;
            globalMax = std::max(globalMax, static_cast<double>(mag));
        }
    }

    if (globalMax <= 1.0e-15)
        return {};

    out.referenceMagnitude = static_cast<float>(globalMax);
    out.levelsDb.resize(raw.size());
    for (std::size_t i = 0; i < raw.size(); ++i) {
        const double ratio = std::max(static_cast<double>(raw[i]) / globalMax, 1.0e-12);
        const float db = static_cast<float>(20.0 * std::log10(ratio));
        out.levelsDb[i] = std::clamp(db, config.floorDb, 0.0f);
    }
    return out;
}


float WaterfallAnalyzer::relativeLevelOffsetDb(const WaterfallData& reference,
                                               const WaterfallData& compared) noexcept
{
    if (!reference.valid() || !compared.valid()
        || !std::isfinite(reference.referenceMagnitude)
        || !std::isfinite(compared.referenceMagnitude)
        || reference.referenceMagnitude <= 1.0e-15f
        || compared.referenceMagnitude <= 1.0e-15f)
        return 0.0f;

    const float db = 20.0f * std::log10(compared.referenceMagnitude / reference.referenceMagnitude);
    return std::clamp(db, -60.0f, 24.0f);
}

float WaterfallAnalyzer::decayLevelDb(const WaterfallData& data,
                                      std::size_t timeIndex,
                                      std::size_t frequencyIndex) noexcept
{
    if (!data.valid() || timeIndex >= data.timesMs.size()
        || frequencyIndex >= data.frequenciesHz.size())
        return data.floorDb;

    // A decay waterfall must show how each frequency falls relative to its own
    // measured t=0 level.  Using the global spectrum peak as the vertical
    // reference can hide a low-frequency modal tail when that band starts well
    // below the broadband peak, making BEFORE and AFTER look misleadingly alike.
    const float initialDb = data.level(0, frequencyIndex);
    const float currentDb = data.level(timeIndex, frequencyIndex);
    return std::clamp(currentDb - initialDb, data.floorDb, 0.0f);
}

std::string WaterfallAnalyzer::serialize(const WaterfallData& data)
{
    if (!data.valid())
        return {};
    std::ostringstream out;
    out << std::setprecision(9);
    out << "RT60_WATERFALL 2\n";
    out << "RATE " << data.sampleRate << '\n';
    out << "FLOOR " << data.floorDb << '\n';
    out << "REFERENCE " << data.referenceMagnitude << '\n';
    out << "FREQS " << data.frequenciesHz.size();
    for (float v : data.frequenciesHz) out << ' ' << v;
    out << '\n';
    out << "TIMES " << data.timesMs.size();
    for (float v : data.timesMs) out << ' ' << v;
    out << '\n';
    out << "LEVELS " << data.levelsDb.size();
    for (float v : data.levelsDb) out << ' ' << v;
    out << '\n';
    return out.str();
}

bool WaterfallAnalyzer::deserialize(const std::string& text, WaterfallData& data)
{
    std::istringstream in(text);
    std::string magic;
    int version = 0;
    if (!(in >> magic >> version) || magic != "RT60_WATERFALL" || (version != 1 && version != 2))
        return false;

    WaterfallData parsed;
    std::string tag;
    std::size_t count = 0;

    if (!(in >> tag >> parsed.sampleRate) || tag != "RATE" || !std::isfinite(parsed.sampleRate) || parsed.sampleRate <= 0.0)
        return false;
    if (!(in >> tag >> parsed.floorDb) || tag != "FLOOR" || !std::isfinite(parsed.floorDb) || parsed.floorDb >= 0.0f)
        return false;
    if (version >= 2) {
        if (!(in >> tag >> parsed.referenceMagnitude) || tag != "REFERENCE"
            || !std::isfinite(parsed.referenceMagnitude) || parsed.referenceMagnitude < 0.0f)
            return false;
    } else {
        // v1 normalized each graph independently and did not preserve an
        // absolute comparison reference. Keep it loadable without inventing one.
        parsed.referenceMagnitude = 0.0f;
    }

    if (!(in >> tag >> count) || tag != "FREQS" || count < 8 || count > 4096)
        return false;
    parsed.frequenciesHz.resize(count);
    for (float& v : parsed.frequenciesHz) if (!(in >> v)) return false;

    if (!(in >> tag >> count) || tag != "TIMES" || count < 2 || count > 4096)
        return false;
    parsed.timesMs.resize(count);
    for (float& v : parsed.timesMs) if (!(in >> v)) return false;

    const std::size_t expected = parsed.frequenciesHz.size() * parsed.timesMs.size();
    if (!(in >> tag >> count) || tag != "LEVELS" || count != expected || count > 10000000)
        return false;
    parsed.levelsDb.resize(count);
    for (float& v : parsed.levelsDb) if (!(in >> v)) return false;

    if (!finiteVector(parsed.frequenciesHz) || !finiteVector(parsed.timesMs) || !finiteVector(parsed.levelsDb))
        return false;
    if (!std::is_sorted(parsed.frequenciesHz.begin(), parsed.frequenciesHz.end())
        || !std::is_sorted(parsed.timesMs.begin(), parsed.timesMs.end()))
        return false;
    if (parsed.frequenciesHz.front() <= 0.0f || parsed.timesMs.front() < 0.0f)
        return false;
    for (float db : parsed.levelsDb)
        if (db < parsed.floorDb - 0.01f || db > 0.01f)
            return false;

    data = std::move(parsed);
    return true;
}

} // namespace rt60
