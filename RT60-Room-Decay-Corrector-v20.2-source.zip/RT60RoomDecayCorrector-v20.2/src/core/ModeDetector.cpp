#include "core/ModeDetector.hpp"

#include <algorithm>
#include <cmath>
#include <complex>
#include <numeric>

namespace rt60 {
namespace {

constexpr double kPi = 3.1415926535897932384626433832795;
constexpr double kLog001 = -6.907755278982137; // ln(0.001)

struct Biquad {
    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0;
    double z1 = 0.0, z2 = 0.0;
    double process(double x) noexcept
    {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
};

Biquad lowPass(double sampleRate, double frequency, double q)
{
    const double w = 2.0 * kPi * frequency / sampleRate;
    const double alpha = std::sin(w) / (2.0 * q);
    const double c = std::cos(w);
    const double a0 = 1.0 + alpha;
    Biquad f;
    f.b0 = ((1.0 - c) * 0.5) / a0;
    f.b1 = (1.0 - c) / a0;
    f.b2 = f.b0;
    f.a1 = (-2.0 * c) / a0;
    f.a2 = (1.0 - alpha) / a0;
    return f;
}

// Solve a small symmetric positive-definite system with Gaussian elimination
// and partial pivoting. Sizes here are at most a few dozen unknowns.
bool solve(std::vector<double>& a, std::vector<double>& b, std::size_t n)
{
    for (std::size_t col = 0; col < n; ++col) {
        std::size_t pivot = col;
        for (std::size_t row = col + 1; row < n; ++row)
            if (std::abs(a[row * n + col]) > std::abs(a[pivot * n + col]))
                pivot = row;
        if (std::abs(a[pivot * n + col]) < 1.0e-14)
            return false;
        if (pivot != col) {
            for (std::size_t k = 0; k < n; ++k)
                std::swap(a[col * n + k], a[pivot * n + k]);
            std::swap(b[col], b[pivot]);
        }
        const double diagonal = a[col * n + col];
        for (std::size_t row = col + 1; row < n; ++row) {
            const double factor = a[row * n + col] / diagonal;
            if (factor == 0.0)
                continue;
            for (std::size_t k = col; k < n; ++k)
                a[row * n + k] -= factor * a[col * n + k];
            b[row] -= factor * b[col];
        }
    }
    for (std::size_t i = n; i-- > 0;) {
        double sum = b[i];
        for (std::size_t k = i + 1; k < n; ++k)
            sum -= a[i * n + k] * b[k];
        b[i] = sum / a[i * n + i];
    }
    return true;
}

// Forward linear prediction by least squares (the covariance formulation).
// For a sum of damped sinusoids this is Prony's method: the roots of the
// prediction polynomial are the poles of the signal.
std::vector<double> linearPrediction(const std::vector<double>& x, std::size_t order)
{
    if (x.size() <= order * 2)
        return {};
    const std::size_t n = order;
    std::vector<double> r(n * n, 0.0), rhs(n, 0.0);
    for (std::size_t sample = order; sample < x.size(); ++sample) {
        for (std::size_t i = 0; i < n; ++i) {
            const double xi = x[sample - i - 1];
            rhs[i] -= xi * x[sample];
            for (std::size_t j = i; j < n; ++j)
                r[i * n + j] += xi * x[sample - j - 1];
        }
    }
    for (std::size_t i = 0; i < n; ++i)
        for (std::size_t j = 0; j < i; ++j)
            r[i * n + j] = r[j * n + i];

    double trace = 0.0;
    for (std::size_t i = 0; i < n; ++i)
        trace += r[i * n + i];
    const double ridge = std::max(1.0e-12, trace / static_cast<double>(n) * 1.0e-7);
    for (std::size_t i = 0; i < n; ++i)
        r[i * n + i] += ridge;

    if (!solve(r, rhs, n))
        return {};
    return rhs; // a[0..order-1]
}

// Durand-Kerner root finding on the monic polynomial
// z^p + a0 z^(p-1) + ... + a(p-1).
std::vector<std::complex<double>> polynomialRoots(const std::vector<double>& a)
{
    const std::size_t p = a.size();
    if (p == 0)
        return {};
    std::vector<std::complex<double>> roots(p);
    std::complex<double> seed(0.4, 0.9), value(1.0, 0.0);
    for (std::size_t i = 0; i < p; ++i) {
        roots[i] = value;
        value *= seed;
    }

    auto evaluate = [&a, p](const std::complex<double>& z) {
        std::complex<double> result(1.0, 0.0);
        for (std::size_t i = 0; i < p; ++i)
            result = result * z + a[i];
        return result;
    };

    for (int iteration = 0; iteration < 900; ++iteration) {
        double movement = 0.0;
        for (std::size_t i = 0; i < p; ++i) {
            std::complex<double> denominator(1.0, 0.0);
            for (std::size_t j = 0; j < p; ++j) {
                if (j == i)
                    continue;
                denominator *= (roots[i] - roots[j]);
            }
            if (std::abs(denominator) < 1.0e-300)
                continue;
            const auto step = evaluate(roots[i]) / denominator;
            roots[i] -= step;
            movement = std::max(movement, std::abs(step));
        }
        if (movement < 1.0e-13)
            break;
    }
    return roots;
}

struct Pole {
    double frequencyHz = 0.0;
    double decayPerSample = 0.0; // ln|z|, negative
    double amplitude = 0.0;
    double energy = 0.0;
};

// Given fixed pole frequencies and decay rates, solve linearly for the
// amplitude and phase of every mode at once. This is what separates two
// overlapping modes: neither is asked to explain the other's energy.
bool fitAmplitudes(const std::vector<double>& x, double rate,
                   std::vector<Pole>& poles, double& residualEnergy)
{
    const std::size_t m = poles.size();
    if (m == 0)
        return false;
    const std::size_t unknowns = 2 * m;
    const std::size_t n = x.size();

    std::vector<double> basis(unknowns * n);
    for (std::size_t k = 0; k < m; ++k) {
        const double w = 2.0 * kPi * poles[k].frequencyHz / rate;
        const double d = poles[k].decayPerSample;
        for (std::size_t i = 0; i < n; ++i) {
            const double envelope = std::exp(d * static_cast<double>(i));
            const double phase = w * static_cast<double>(i);
            basis[(2 * k) * n + i] = envelope * std::cos(phase);
            basis[(2 * k + 1) * n + i] = envelope * std::sin(phase);
        }
    }

    std::vector<double> normal(unknowns * unknowns, 0.0), rhs(unknowns, 0.0);
    for (std::size_t i = 0; i < unknowns; ++i) {
        const double* bi = &basis[i * n];
        for (std::size_t j = i; j < unknowns; ++j) {
            const double* bj = &basis[j * n];
            double sum = 0.0;
            for (std::size_t s = 0; s < n; ++s)
                sum += bi[s] * bj[s];
            normal[i * unknowns + j] = sum;
        }
        double sum = 0.0;
        for (std::size_t s = 0; s < n; ++s)
            sum += bi[s] * x[s];
        rhs[i] = sum;
    }
    for (std::size_t i = 0; i < unknowns; ++i)
        for (std::size_t j = 0; j < i; ++j)
            normal[i * unknowns + j] = normal[j * unknowns + i];

    double trace = 0.0;
    for (std::size_t i = 0; i < unknowns; ++i)
        trace += normal[i * unknowns + i];
    const double ridge = std::max(1.0e-15, trace / static_cast<double>(unknowns) * 1.0e-9);
    for (std::size_t i = 0; i < unknowns; ++i)
        normal[i * unknowns + i] += ridge;

    auto coefficients = rhs;
    auto matrix = normal;
    if (!solve(matrix, coefficients, unknowns))
        return false;

    std::vector<double> model(n, 0.0);
    for (std::size_t i = 0; i < unknowns; ++i) {
        const double c = coefficients[i];
        if (c == 0.0)
            continue;
        const double* bi = &basis[i * n];
        for (std::size_t s = 0; s < n; ++s)
            model[s] += c * bi[s];
    }
    residualEnergy = 0.0;
    for (std::size_t s = 0; s < n; ++s) {
        const double e = x[s] - model[s];
        residualEnergy += e * e;
    }

    for (std::size_t k = 0; k < m; ++k) {
        const double re = coefficients[2 * k];
        const double im = coefficients[2 * k + 1];
        poles[k].amplitude = std::sqrt(re * re + im * im);
        double energy = 0.0;
        for (std::size_t s = 0; s < n; ++s) {
            const double v = re * basis[(2 * k) * n + s] + im * basis[(2 * k + 1) * n + s];
            energy += v * v;
        }
        poles[k].energy = energy;
    }
    return true;
}

double totalEnergy(const std::vector<double>& x)
{
    double sum = 0.0;
    for (double v : x)
        sum += v * v;
    return sum;
}

} // namespace

std::vector<float> ModeDetector::decimateLowBand(const std::vector<float>& input,
                                                 double sampleRate,
                                                 double targetRate,
                                                 double& decimatedRate)
{
    decimatedRate = sampleRate;
    if (input.empty() || sampleRate <= 0.0 || targetRate <= 0.0)
        return {};
    const int factor = std::max(1, static_cast<int>(std::floor(sampleRate / targetRate)));
    decimatedRate = sampleRate / factor;

    // Anti-alias below the new Nyquist, then keep every factor-th sample.
    auto lp1 = lowPass(sampleRate, decimatedRate * 0.38, 0.541196);
    auto lp2 = lowPass(sampleRate, decimatedRate * 0.38, 1.306563);
    std::vector<float> out;
    out.reserve(input.size() / static_cast<std::size_t>(factor) + 1);
    for (std::size_t i = 0; i < input.size(); ++i) {
        const double v = lp2.process(lp1.process(static_cast<double>(input[i])));
        if (i % static_cast<std::size_t>(factor) == 0)
            out.push_back(static_cast<float>(v));
    }
    return out;
}

std::vector<DetectedMode> ModeDetector::detect(const std::vector<float>& impulseResponse,
                                               double sampleRate,
                                               const ModeDetectorConfig& config)
{
    std::vector<DetectedMode> result;
    if (impulseResponse.size() < 1024 || sampleRate < 8000.0)
        return result;

    // Start at the direct arrival so the model does not have to explain the
    // pre-arrival noise floor.
    const auto peakIt = std::max_element(impulseResponse.begin(), impulseResponse.end(),
                                         [](float a, float b) { return std::abs(a) < std::abs(b); });
    const std::size_t peak = static_cast<std::size_t>(std::distance(impulseResponse.begin(), peakIt));
    const std::size_t available = impulseResponse.size() > peak ? impulseResponse.size() - peak : 0;
    const std::size_t wanted = static_cast<std::size_t>(config.analysisSeconds * sampleRate);
    const std::size_t count = std::min(available, wanted);
    if (count < static_cast<std::size_t>(sampleRate * 0.4))
        return result;

    std::vector<float> segment(impulseResponse.begin() + static_cast<std::ptrdiff_t>(peak),
                               impulseResponse.begin() + static_cast<std::ptrdiff_t>(peak + count));

    const double targetRate = std::max(4.0 * static_cast<double>(config.maxHz), 800.0);
    double rate = sampleRate;
    const auto decimatedFloat = decimateLowBand(segment, sampleRate, targetRate, rate);
    if (decimatedFloat.size() < 256)
        return result;

    std::vector<double> x(decimatedFloat.begin(), decimatedFloat.end());
    const double mean = std::accumulate(x.begin(), x.end(), 0.0) / static_cast<double>(x.size());
    for (double& v : x)
        v -= mean;

    // Skip the first few milliseconds: the direct sound is not a mode and a
    // large impulsive onset biases the prediction fit.
    const std::size_t skip = std::min<std::size_t>(x.size() / 3,
        static_cast<std::size_t>(rate * static_cast<double>(config.skipSeconds)));
    x.erase(x.begin(), x.begin() + static_cast<std::ptrdiff_t>(skip));
    if (x.size() < 256)
        return result;

    const double signalEnergy = totalEnergy(x);
    if (signalEnergy <= 0.0)
        return result;

    const std::size_t order = std::min<std::size_t>(static_cast<std::size_t>(std::max(8, config.predictionOrder)),
                                                    x.size() / 4);
    const auto a = linearPrediction(x, order);
    if (a.empty())
        return result;

    const auto roots = polynomialRoots(a);
    if (roots.empty())
        return result;

    const double minDecay = kLog001 / (static_cast<double>(config.maxT60Ms) / 1000.0 * rate);
    const double maxDecay = kLog001 / (static_cast<double>(config.minT60Ms) / 1000.0 * rate);

    std::vector<Pole> poles;
    for (const auto& z : roots) {
        const double magnitude = std::abs(z);
        if (!(magnitude > 0.0) || magnitude >= 1.0)
            continue;
        const double decay = std::log(magnitude);
        if (decay > minDecay || decay < maxDecay)
            continue; // outside the plausible T60 window
        const double frequency = std::arg(z) * rate / (2.0 * kPi);
        if (frequency < config.minHz || frequency > config.maxHz)
            continue;
        Pole p;
        p.frequencyHz = frequency;
        p.decayPerSample = decay;
        poles.push_back(p);
    }
    if (poles.empty())
        return result;

    std::sort(poles.begin(), poles.end(),
              [](const Pole& l, const Pole& r) { return l.frequencyHz < r.frequencyHz; });

    // Merge poles that are so close they describe one physical mode.
    std::vector<Pole> merged;
    for (const auto& p : poles) {
        if (!merged.empty()) {
            const double spacing = std::abs(p.frequencyHz - merged.back().frequencyHz);
            const double bandwidth = std::max(1.0, -p.decayPerSample * rate / kPi);
            if (spacing < bandwidth * 0.5)
                continue;
        }
        merged.push_back(p);
    }
    poles = std::move(merged);
    if (static_cast<int>(poles.size()) > config.maxModes * 2)
        poles.resize(static_cast<std::size_t>(config.maxModes * 2));

    double residual = 0.0;
    if (!fitAmplitudes(x, rate, poles, residual))
        return result;

    // Drop the weakest poles, then refit, so the remaining modes are not
    // distorted by components that only modelled noise.
    std::sort(poles.begin(), poles.end(),
              [](const Pole& l, const Pole& r) { return l.energy > r.energy; });
    if (static_cast<int>(poles.size()) > config.maxModes)
        poles.resize(static_cast<std::size_t>(config.maxModes));
    if (!fitAmplitudes(x, rate, poles, residual))
        return result;

    // Coordinate refinement: nudge each pole's frequency and decay, keeping any
    // change that lowers the joint residual.
    for (int pass = 0; pass < std::max(0, config.refinementPasses); ++pass) {
        const double frequencyStep = (0.30 / (pass + 1)) * rate / static_cast<double>(x.size());
        for (std::size_t k = 0; k < poles.size(); ++k) {
            for (int axis = 0; axis < 2; ++axis) {
                for (int direction = -1; direction <= 1; direction += 2) {
                    auto trial = poles;
                    if (axis == 0)
                        trial[k].frequencyHz += direction * frequencyStep;
                    else
                        trial[k].decayPerSample *= (1.0 + direction * 0.06 / (pass + 1));
                    if (trial[k].frequencyHz < config.minHz || trial[k].frequencyHz > config.maxHz)
                        continue;
                    if (trial[k].decayPerSample > minDecay || trial[k].decayPerSample < maxDecay)
                        continue;
                    double trialResidual = 0.0;
                    if (!fitAmplitudes(x, rate, trial, trialResidual))
                        continue;
                    if (trialResidual < residual) {
                        residual = trialResidual;
                        poles = trial;
                    }
                }
            }
        }
    }

    const double explained = std::max(0.0, 1.0 - residual / signalEnergy);
    for (const auto& p : poles) {
        const double share = p.energy / signalEnergy;
        if (share < config.minEnergyShare)
            continue;
        const double t60Ms = kLog001 / (p.decayPerSample * rate) * 1000.0;
        if (!std::isfinite(t60Ms) || t60Ms < config.minT60Ms || t60Ms > config.maxT60Ms)
            continue;
        const double snrDb = 10.0 * std::log10(std::max(p.energy, 1.0e-30)
                                               / std::max(residual, 1.0e-30));

        DetectedMode mode;
        mode.frequencyHz = static_cast<float>(p.frequencyHz);
        mode.t60Ms = static_cast<float>(t60Ms);
        mode.amplitude = static_cast<float>(p.amplitude);
        mode.energyShare = static_cast<float>(share);
        mode.confidence = static_cast<float>(std::clamp(explained, 0.0, 1.0)
                                             * std::clamp((snrDb + 6.0) / 18.0, 0.0, 1.0));
        result.push_back(mode);
    }

    std::sort(result.begin(), result.end(),
              [](const DetectedMode& l, const DetectedMode& r) { return l.energyShare > r.energyShare; });
    return result;
}

} // namespace rt60
