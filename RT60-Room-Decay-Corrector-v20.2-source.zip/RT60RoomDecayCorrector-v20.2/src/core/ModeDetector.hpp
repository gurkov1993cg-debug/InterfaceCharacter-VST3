#pragma once

#include <cstddef>
#include <vector>

namespace rt60 {

struct DetectedMode {
    float frequencyHz = 0.0f;
    float t60Ms = 0.0f;
    float amplitude = 0.0f;   // linear amplitude of this mode at t = 0
    float energyShare = 0.0f; // fraction of the analysed low-frequency energy
    float confidence = 0.0f;  // 0..1, combines model fit and per-mode SNR
};

struct ModeDetectorConfig {
    float minHz = 20.0f;
    float maxHz = 320.0f;
    float analysisSeconds = 2.6f;
    float skipSeconds = 0.10f;   // let the direct sound and early reflections pass
    float minT60Ms = 80.0f;
    float maxT60Ms = 4000.0f;
    int predictionOrder = 60;   // linear-prediction order at the decimated rate
    int maxModes = 14;
    int refinementPasses = 3;
    float minEnergyShare = 0.004f;
};

// Estimates individual room modes directly as poles of the low-frequency
// impulse response, then fits every mode simultaneously.
//
// The previous approach walked fixed 1/3-octave bands and took the strongest
// FFT peak inside each one. That fails in three ways this class is built to
// avoid:
//   * a mode sitting between two band centres could not be reported at its
//     real frequency, because the candidate was clamped to the band edges;
//   * a long neighbouring mode leaked into the analysis of a short one, so the
//     short mode was credited with the neighbour's decay time;
//   * one physical mode could be reported once per band it leaked into.
// Fitting all poles jointly separates overlapping modes instead of trying to
// isolate them with a filter, which is impossible when the spacing approaches
// the modal bandwidth.
class ModeDetector {
public:
    static std::vector<DetectedMode> detect(const std::vector<float>& impulseResponse,
                                            double sampleRate,
                                            const ModeDetectorConfig& config = {});

    // Exposed so tests can drive the numerics without an impulse response.
    static std::vector<float> decimateLowBand(const std::vector<float>& input,
                                              double sampleRate,
                                              double targetRate,
                                              double& decimatedRate);
};

} // namespace rt60
