#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "core/CorrectionEngine.hpp"
#include "core/DecayModel.hpp"
#include "core/WaterfallData.hpp"
#include "core/DisplaySnapshot.hpp"
#include "core/ProfileBundle.hpp"

#include <array>
#include <atomic>
#include <cstdint>
#include <vector>

class RT60Processor final : public juce::AudioProcessor {
public:
    RT60Processor();
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "RT60 Room Decay Corrector"; }
    double getTailLengthSeconds() const override;
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;
    rt60::DecayModel& model() noexcept { return model_; }
    bool reloadActiveProfile();
    bool loadProfileBundleFromFile(const juce::File& file);
    juce::String activeProfileName() const { return currentProfileName_; }
    juce::String profileWarning() const { return profileWarning_; }
    const rt60::ProfileMetadata& profileMetadata() const noexcept { return metadata_; }
    const rt60::DisplaySnapshot& displaySnapshot() const noexcept { return displaySnapshot_; }
    const std::array<rt60::CorrectionProfile, 2>& profiles() const noexcept { return profiles_; }
    bool swapWithPreviousProfile();
    bool loadBestVerifiedProfile();
    const std::vector<juce::String>& recentProfilePaths() const noexcept { return recentProfilePaths_; }
    bool loadRecentProfile(int index);
    int activeStageCount() const noexcept;
    bool hasActiveProfile() const noexcept { return hasProfile_.load(std::memory_order_acquire); }
    const rt60::WaterfallData* waterfall(int channel, bool afterCorrection) const noexcept;

private:
    struct BankPair {
        rt60::CorrectionFilterBank left;
        rt60::CorrectionFilterBank right;
    };

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameters();
    static juce::File profileDirectory();
    static juce::File activeProfileFile(int channel);
    static juce::File legacyProfileFile();
    static juce::File waterfallFile(int channel, bool afterCorrection);
    static juce::File displaySnapshotFile();
    static juce::File activeBundleFile();
    static juce::File bestVerifiedProfileFile();
    void applyProfileToModel();
    void loadWaterfallSnapshots();
    void loadDisplaySnapshot();
    void applyDisplaySnapshot(const rt60::DisplaySnapshot& snapshot);
    bool writeActiveMirror(const rt60::ProfileBundle& bundle);
    void publishBanks();
    rt60::ProfileBundle currentBundle() const;
    void applyBundle(const rt60::ProfileBundle& bundle, const juce::String& name);
    void rememberRecent(const juce::File& file);

    rt60::DecayModel model_;
    std::array<rt60::CorrectionProfile, 2> profiles_{};
    std::array<rt60::MeasurementResult, 2> beforeMeasurements_{};
    std::array<rt60::MeasurementResult, 2> afterMeasurements_{};
    std::array<rt60::WaterfallData, 2> beforeWaterfalls_{};
    std::array<rt60::WaterfallData, 2> afterWaterfalls_{};
    rt60::DisplaySnapshot displaySnapshot_{};
    rt60::ProfileMetadata metadata_{};
    rt60::ProfileBundle previousBundle_{};
    juce::String previousProfileName_;
    bool hasPreviousBundle_ = false;
    std::vector<juce::String> recentProfilePaths_;
    std::array<BankPair, 3> bankSlots_{};
    // Active and pending slot indices share ONE atomic word. Two separate
    // atomics allowed the audio thread to promote pending to active between the
    // message thread's two loads, after which publishBanks() could reconfigure
    // the slot processBlock() had just started using - clearing and
    // reallocating stages_ underneath a running filter. A single packed load
    // always returns a consistent pair.
    static constexpr int kNoPendingBank = 0xFF;
    static std::uint32_t packBankState(int active, int pending) noexcept
    {
        return static_cast<std::uint32_t>(active & 0xFF)
             | (static_cast<std::uint32_t>(pending & 0xFF) << 8);
    }
    static int bankStateActive(std::uint32_t state) noexcept { return static_cast<int>(state & 0xFF); }
    static int bankStatePending(std::uint32_t state) noexcept { return static_cast<int>((state >> 8) & 0xFF); }
    std::atomic<std::uint32_t> bankState_{packBankState(0, kNoPendingBank)};
    std::atomic<bool> hasProfile_{false};
    juce::String currentProfileName_;
    juce::String profileWarning_;
    double sampleRate_ = 48000.0;
};
