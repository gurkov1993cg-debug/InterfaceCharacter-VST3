#include "core/CorrectionEngine.hpp"
#include "core/MeasurementEngine.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

namespace {
constexpr double kPi = 3.1415926535897932384626433832795;
int failures = 0;

void check(bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << "\n";
        ++failures;
    }
}

// Impulse response of a single second-order resonator: exactly the signal
// shape the modal correction is designed to act on.
std::vector<float> modalImpulseResponse(double sampleRate,
                                        double frequencyHz,
                                        double t60Ms,
                                        double seconds)
{
    const auto count = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> signal(count, 0.0f);
    const double t60 = t60Ms / 1000.0;
    const double log001 = std::log(0.001);
    for (std::size_t i = 0; i < count; ++i) {
        const double t = static_cast<double>(i) / sampleRate;
        signal[i] = static_cast<float>(std::exp(log001 * t / t60)
                                       * std::sin(2.0 * kPi * frequencyHz * t));
    }
    return signal;
}
}

int main()
{
    constexpr double sampleRate = 48000.0;

    rt60::MeasurementConfig cfg;
    cfg.sampleRate = sampleRate;
    rt60::MeasurementEngine engine(cfg);

    // --- Test 1: does the measurement recover a known T60? -----------------
    struct Case { double hz; double t60Ms; };
    for (const Case c : {Case{63.0, 500.0}, Case{100.0, 300.0}}) {
        const auto ir = modalImpulseResponse(sampleRate, c.hz, c.t60Ms, 2.5);
        const auto m = engine.analyseBandAtFrequency(ir, static_cast<float>(c.hz));
        std::cout << "MEASURE " << c.hz << " Hz  expected " << c.t60Ms
                  << " ms  ->  rt60 " << m.rt60Ms
                  << "  edt " << m.edtMs << "  t20 " << m.t20Ms << "  t30 " << m.t30Ms
                  << "  fit " << m.fitQuality << "  conf " << m.confidence
                  << "  dyn " << m.dynamicRangeDb << " dB"
                  << "  valid " << (m.valid ? "yes" : "NO") << "\n";
        check(m.valid, "measurement must be valid for a clean synthetic mode");
        check(std::abs(m.rt60Ms - c.t60Ms) < c.t60Ms * 0.05,
              "measured T60 must be within 5% of the synthesised T60");
    }

    // --- Test 2: does the correction filter actually shorten the decay? ----
    rt60::CorrectionProfile profile;
    profile.targetMs = 250.0f;
    profile.strength = 1.0f;
    rt60::CorrectionStageSpec stage;
    stage.frequencyHz = 63.0f;
    stage.measuredT60Ms = 500.0f;
    stage.desiredT60Ms = 250.0f;
    stage.estimatedQ = 8.0f;
    stage.confidence = 1.0f;
    stage.sourceBand = 4;
    profile.stages.push_back(stage);

    rt60::CorrectionFilterBank bank;
    bank.configure(profile, sampleRate);
    std::cout << "BANK stages configured: " << bank.stageCount() << "\n";
    check(bank.stageCount() == 1, "one stage must survive configure()");

    auto corrected = modalImpulseResponse(sampleRate, 63.0, 500.0, 2.5);
    bank.process(corrected.data(), static_cast<int>(corrected.size()));
    const auto after = engine.analyseBandAtFrequency(corrected, 63.0f);
    std::cout << "CORRECT 63 Hz  500 -> 250 ms  ->  rt60 " << after.rt60Ms
              << "  fit " << after.fitQuality
              << "  valid " << (after.valid ? "yes" : "NO") << "\n";
    check(after.valid, "corrected signal must still yield a valid decay fit");
    check(std::abs(after.rt60Ms - 250.0f) < 250.0f * 0.10f,
          "corrected T60 must land within 10% of the requested 250 ms");

    // --- Test 3: a stage must not be a silent no-op on unrelated audio -----
    const float attenuation = rt60::CorrectionEngine::stageAttenuationDb(stage, sampleRate);
    std::cout << "STAGE attenuation at 63 Hz: " << attenuation << " dB\n";
    check(attenuation < -0.5f, "the stage must produce a real cut at the modal frequency");

    if (failures > 0) {
        std::cerr << failures << " check(s) failed\n";
        return 1;
    }
    std::cout << "decay DSP tests passed\n";
    return 0;
}
