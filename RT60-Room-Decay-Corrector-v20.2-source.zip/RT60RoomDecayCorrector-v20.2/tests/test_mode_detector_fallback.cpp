#include "core/CorrectionEngine.hpp"
#include "core/MeasurementEngine.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <random>
#include <vector>

namespace {
constexpr double kPi = 3.1415926535897932384626433832795;
struct Mode { double hz, t60Ms, amplitude; };

void require(bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << "\n";
        std::exit(1);
    }
}

std::vector<float> roomIR(double sampleRate, double seconds,
                          const std::vector<Mode>& modes,
                          double tailT60Ms, double noiseFloorDb, unsigned seed)
{
    const auto count = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> ir(count, 0.0f);
    const double log001 = std::log(0.001);
    std::mt19937 rng(seed);
    std::normal_distribution<double> gauss(0.0, 1.0);

    for (const auto& m : modes) {
        for (std::size_t i = 0; i < count; ++i) {
            const double t = static_cast<double>(i) / sampleRate;
            ir[i] += static_cast<float>(m.amplitude
                * std::exp(log001 * t / (m.t60Ms / 1000.0))
                * std::sin(2.0 * kPi * m.hz * t));
        }
    }
    for (std::size_t i = 0; i < count; ++i) {
        const double t = static_cast<double>(i) / sampleRate;
        ir[i] += static_cast<float>(0.9
            * std::exp(log001 * t / (tailT60Ms / 1000.0)) * gauss(rng));
    }
    ir[0] += 1.0f;
    const double noise = std::pow(10.0, noiseFloorDb / 20.0);
    for (auto& sample : ir)
        sample += static_cast<float>(noise * gauss(rng));
    return ir;
}

const rt60::CorrectionStageSpec* nearestStage(const rt60::CorrectionProfile& profile, float hz)
{
    const rt60::CorrectionStageSpec* best = nullptr;
    float distance = 1.0e9f;
    for (const auto& stage : profile.stages) {
        const float d = std::abs(stage.frequencyHz - hz);
        if (d < distance) {
            distance = d;
            best = &stage;
        }
    }
    return best;
}
}

int main()
{
    constexpr double sampleRate = 48000.0;
    const auto ir = roomIR(sampleRate, 3.0,
                           {{58.0, 900.0, 0.50}, {68.0, 860.0, 0.50}},
                           320.0, -65.0, 777);

    rt60::MeasurementConfig measurementConfig;
    measurementConfig.sampleRate = sampleRate;
    rt60::MeasurementEngine analyser(measurementConfig);
    const auto measurement = analyser.analyseImpulseResponse(ir);
    require(measurement.valid, "synthetic room measurement must be valid");

    rt60::CorrectionDesignConfig config;
    config.minConfidence = 0.20f;
    config.allowConservativeBandFallback = true;
    config.useModeDetector = true;
    config.maxNewStages = 8;

    rt60::CorrectionEngine designer;
    const auto profile = designer.design(measurement, config);

    const auto* low = nearestStage(profile, 58.0f);
    const auto* high = nearestStage(profile, 68.0f);
    require(low != nullptr && std::abs(low->frequencyHz - 58.0f) < 1.0f,
            "fallback mode must preserve the detector's 58 Hz pole");
    require(high != nullptr && std::abs(high->frequencyHz - 68.0f) < 1.0f,
            "fallback mode must preserve the detector's 68 Hz pole");

    std::cout << "fallback stages:";
    for (const auto& stage : profile.stages)
        std::cout << ' ' << stage.frequencyHz;
    std::cout << " Hz\nmode-detector fallback regression passed\n";
    return 0;
}
