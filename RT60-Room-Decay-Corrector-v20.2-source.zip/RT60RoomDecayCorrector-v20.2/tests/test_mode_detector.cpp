#include "core/CorrectionEngine.hpp"
#include "core/MeasurementEngine.hpp"
#include "core/ModeDetector.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <random>
#include <string>
#include <vector>

namespace {
constexpr double kPi = 3.1415926535897932384626433832795;
int failures = 0;

void check(bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << "\n";
        ++failures;
    }
}

struct Mode { double hz, t60Ms, amplitude; };

std::vector<float> singleMode(double sampleRate, double seconds, const Mode& m)
{
    const auto count = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> out(count);
    const double log001 = std::log(0.001);
    for (std::size_t i = 0; i < count; ++i) {
        const double t = static_cast<double>(i) / sampleRate;
        out[i] = static_cast<float>(m.amplitude * std::exp(log001 * t / (m.t60Ms / 1000.0))
                                    * std::sin(2.0 * kPi * m.hz * t));
    }
    return out;
}

// Direct sound, a set of modes, a shorter broadband tail and a noise floor.
std::vector<float> roomIR(double sampleRate, double seconds,
                          const std::vector<Mode>& modes,
                          double tailT60Ms, double noiseFloorDb, unsigned seed)
{
    const auto count = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> ir(count, 0.0f);
    const double log001 = std::log(0.001);
    std::mt19937 rng(seed);
    std::normal_distribution<double> gauss(0.0, 1.0);

    for (const auto& m : modes) {
        const auto s = singleMode(sampleRate, seconds, m);
        for (std::size_t i = 0; i < count; ++i)
            ir[i] += s[i];
    }
    for (std::size_t i = 0; i < count; ++i) {
        const double t = static_cast<double>(i) / sampleRate;
        ir[i] += static_cast<float>(0.9 * std::exp(log001 * t / (tailT60Ms / 1000.0)) * gauss(rng));
    }
    ir[0] += 1.0f;
    const double noise = std::pow(10.0, noiseFloorDb / 20.0);
    for (auto& s : ir)
        s += static_cast<float>(noise * gauss(rng));
    return ir;
}

// Envelope decay of a signal containing exactly one frequency. No analysis
// filter is involved, so no filter ringing can contaminate the number.
double envelopeT60Ms(const std::vector<float>& x, double sampleRate)
{
    const auto win = static_cast<std::size_t>(sampleRate * 0.02);
    const std::size_t hop = std::max<std::size_t>(1, win / 2);
    std::vector<double> times, levels;
    for (std::size_t i = 0; i + win < x.size(); i += hop) {
        double energy = 0.0;
        for (std::size_t j = 0; j < win; ++j)
            energy += static_cast<double>(x[i + j]) * x[i + j];
        times.push_back((static_cast<double>(i) + win * 0.5) / sampleRate);
        levels.push_back(10.0 * std::log10(std::max(energy / static_cast<double>(win), 1.0e-30)));
    }
    if (levels.size() < 8)
        return -1.0;
    const double reference = *std::max_element(levels.begin(), levels.end());
    double sx = 0.0, sy = 0.0, sxx = 0.0, sxy = 0.0;
    int n = 0;
    for (std::size_t i = 0; i < levels.size(); ++i) {
        const double rel = levels[i] - reference;
        if (rel > -5.0 || rel < -40.0)
            continue;
        sx += times[i]; sy += rel; sxx += times[i] * times[i]; sxy += times[i] * rel;
        ++n;
    }
    if (n < 5)
        return -1.0;
    const double denominator = n * sxx - sx * sx;
    if (std::abs(denominator) < 1.0e-18)
        return -1.0;
    const double slope = (n * sxy - sx * sy) / denominator;
    return slope >= -1.0 ? -1.0 : -60.0 / slope * 1000.0;
}

const rt60::DetectedMode* nearest(const std::vector<rt60::DetectedMode>& modes, double hz)
{
    const rt60::DetectedMode* best = nullptr;
    double bestDistance = 1.0e9;
    for (const auto& m : modes) {
        const double d = std::abs(m.frequencyHz - hz);
        if (d < bestDistance) { bestDistance = d; best = &m; }
    }
    return bestDistance <= std::max(2.0, hz * 0.04) ? best : nullptr;
}
}

int main()
{
    constexpr double sampleRate = 48000.0;

    // --- Modes that do not sit on 1/3-octave centres --------------------
    {
        const std::vector<Mode> modes{{37.3, 880, 0.55}, {52.8, 800, 0.60},
                                      {71.4, 700, 0.45}, {93.1, 620, 0.32}};
        const auto ir = roomIR(sampleRate, 3.0, modes, 320.0, -65.0, 777);
        const auto found = rt60::ModeDetector::detect(ir, sampleRate);
        for (const auto& m : modes) {
            const auto* d = nearest(found, m.hz);
            std::printf("  %6.1f Hz true %6.0f ms -> %s\n", m.hz, m.t60Ms,
                        d ? (std::to_string(static_cast<int>(d->frequencyHz * 100) / 100.0)
                             + " Hz / " + std::to_string(static_cast<int>(d->t60Ms)) + " ms").c_str()
                          : "NOT FOUND");
            check(d != nullptr, "every well-separated mode must be detected");
            if (d == nullptr)
                continue;
            check(std::abs(d->frequencyHz - m.hz) < 1.0f,
                  "detected frequency must not be snapped to a band centre");
            check(std::abs(d->t60Ms - m.t60Ms) < m.t60Ms * 0.12,
                  "detected T60 must be within 12% of the synthesised value");
        }
    }

    // --- A long mode next to a short one --------------------------------
    // The band search credited the 450 ms mode with its 1300 ms neighbour's
    // decay and then over-corrected it badly.
    {
        const std::vector<Mode> modes{{37.3, 450, 0.55}, {52.8, 1300, 0.60}, {71.4, 700, 0.45}};
        const auto ir = roomIR(sampleRate, 3.0, modes, 320.0, -65.0, 777);
        const auto found = rt60::ModeDetector::detect(ir, sampleRate);
        const auto* shortMode = nearest(found, 37.3);
        const auto* longMode = nearest(found, 52.8);
        check(shortMode != nullptr, "the short mode next to a long one must be detected");
        check(longMode != nullptr, "the long mode must be detected");
        if (shortMode != nullptr) {
            std::printf("  37.3 Hz true 450 ms -> %.1f ms\n", shortMode->t60Ms);
            check(shortMode->t60Ms < 600.0f,
                  "a 450 ms mode must not inherit its 1300 ms neighbour's decay");
        }
        if (longMode != nullptr)
            check(std::abs(longMode->t60Ms - 1300.0f) < 200.0f, "the long mode must read near 1300 ms");
    }

    // --- Two modes that fall inside one 1/3-octave band ------------------
    // 68 Hz used to be unreachable: the 63 Hz band's peak was 58 Hz and the
    // 80 Hz band clamped its candidate to 71.3 Hz.
    {
        const std::vector<Mode> modes{{58.0, 900, 0.50}, {68.0, 860, 0.50}};
        const auto ir = roomIR(sampleRate, 3.0, modes, 320.0, -65.0, 777);
        const auto found = rt60::ModeDetector::detect(ir, sampleRate);
        const auto* low = nearest(found, 58.0);
        const auto* high = nearest(found, 68.0);
        check(low != nullptr && high != nullptr, "both modes inside one band must be resolved");
        if (low != nullptr && high != nullptr)
            std::printf("  58/68 Hz -> %.2f Hz and %.2f Hz\n", low->frequencyHz, high->frequencyHz);

        // And the correction built from them must actually shorten both.
        rt60::MeasurementConfig mcfg;
        mcfg.sampleRate = sampleRate;
        rt60::MeasurementEngine engine(mcfg);
        rt60::CorrectionEngine designer;
        const auto measured = engine.analyseImpulseResponse(ir);
        const auto profile = designer.design(measured, {});
        check(profile.stages.size() >= 2, "both modes must produce a correction stage");

        for (const auto& m : modes) {
            auto isolated = singleMode(sampleRate, 3.0, m);
            rt60::CorrectionFilterBank bank;
            bank.configure(profile, sampleRate);
            bank.process(isolated.data(), static_cast<int>(isolated.size()));
            const double after = envelopeT60Ms(isolated, sampleRate);
            std::printf("  %.0f Hz  %.0f ms -> %.0f ms after correction\n", m.hz, m.t60Ms, after);
            check(after > 0.0 && after < m.t60Ms * 0.65,
                  "each resolved mode must be measurably shortened by the correction");
        }
    }

    if (failures > 0) {
        std::cerr << failures << " check(s) failed\n";
        return 1;
    }
    std::cout << "mode detector tests passed\n";
    return 0;
}
