#include "core/ProfileBundle.hpp"

#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>

namespace {

void require(bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << "\n";
        std::exit(1);
    }
}
rt60::ProfileBundle makeBundle(const std::string& name, float roomMs, float afterMs)
{
    rt60::ProfileBundle b;
    for (int ch = 0; ch < 2; ++ch) {
        b.profiles[ch].targetMs = 300.0f;
        b.profiles[ch].strength = 0.85f;
        b.profiles[ch].autoTarget = true;
        b.profiles[ch].measuredBandMs[8] = roomMs + ch * 15.0f;
        b.profiles[ch].targetBandMs[8] = 300.0f;
        rt60::CorrectionStageSpec stage;
        stage.frequencyHz = 160.0f;
        stage.measuredT60Ms = roomMs + ch * 15.0f;
        stage.desiredT60Ms = 300.0f;
        stage.estimatedQ = 5.5f;
        stage.confidence = 0.92f;
        stage.sourceBand = 8;
        b.profiles[ch].stages.push_back(stage);

        b.beforeMeasurements[ch].sampleRate = 48000.0;
        b.beforeMeasurements[ch].valid = true;
        b.beforeMeasurements[ch].peakDbFs = -18.0f - ch;
        b.beforeMeasurements[ch].bands[8].frequencyHz = 160.0f;
        b.beforeMeasurements[ch].bands[8].rt60Ms = roomMs + ch * 15.0f;
        b.beforeMeasurements[ch].bands[8].confidence = 0.92f;
        b.beforeMeasurements[ch].bands[8].valid = true;

        b.afterMeasurements[ch] = b.beforeMeasurements[ch];
        b.afterMeasurements[ch].bands[8].rt60Ms = afterMs + ch * 10.0f;

        b.display.beforeMs[ch][8] = b.beforeMeasurements[ch].bands[8].rt60Ms;
        b.display.beforeValid[ch][8] = true;
        b.display.afterMs[ch][8] = b.afterMeasurements[ch].bands[8].rt60Ms;
        b.display.afterValid[ch][8] = true;
    }
    b.hasMeasurementDetails = true;
    b.metadata.appMajor = 20;
    b.metadata.appMinor = 0;
    b.metadata.measurementSampleRate = 48000.0;
    b.metadata.targetMs = 300.0f;
    b.metadata.maxCorrectionHz = 300.0f;
    b.metadata.verified = true;
    b.metadata.profileName = name;
    b.metadata.createdUtc = "2026-09-01T12:00:00Z";
    return b;
}

bool writeExact(const std::string& path, const std::string& bytes)
{
    std::ofstream out(path.c_str(), std::ios::binary | std::ios::trunc);
    out.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    return out.good();
}

std::string readExact(const std::string& path)
{
    std::ifstream in(path.c_str(), std::ios::binary);
    return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}
}

int main()
{
    // Keep this test compatible with the macOS 10.13 deployment target.
    // std::filesystem is only available from macOS 10.15 in libc++.
    const std::string fileA = "rt60_v20_profile_io_Room_A.rt60profile";
    const std::string fileB = "rt60_v20_profile_io_Room_B.rt60profile";

    const auto a = makeBundle("Room A", 780.0f, 340.0f);
    const auto b = makeBundle("Room B", 520.0f, 305.0f);
    const auto bytesA = rt60::ProfileBundleCodec::serialize(a);
    const auto bytesB = rt60::ProfileBundleCodec::serialize(b);
    require(bytesA != bytesB, "different rooms must serialize differently");
    require(writeExact(fileA, bytesA), "write Room A profile");
    require(writeExact(fileB, bytesB), "write Room B profile");

    rt60::ProfileBundle loadedA, loadedB;
    require(rt60::ProfileBundleCodec::deserialize(readExact(fileA), loadedA), "read Room A profile");
    require(rt60::ProfileBundleCodec::deserialize(readExact(fileB), loadedB), "read Room B profile");
    require(loadedA.metadata.profileName == "Room A", "Room A name restored");
    require(loadedB.metadata.profileName == "Room B", "Room B name restored");
    require(std::abs(loadedA.beforeMeasurements[0].bands[8].rt60Ms - 780.0f) < 0.01f, "Room A BEFORE restored");
    require(std::abs(loadedB.beforeMeasurements[0].bands[8].rt60Ms - 520.0f) < 0.01f, "Room B BEFORE restored");
    require(std::abs(loadedA.afterMeasurements[0].bands[8].rt60Ms - 340.0f) < 0.01f, "Room A AFTER restored");
    require(std::abs(loadedB.afterMeasurements[0].bands[8].rt60Ms - 305.0f) < 0.01f, "Room B AFTER restored");
    require(loadedA.profiles[0].stages.size() == 1, "Room A correction restored");
    require(loadedB.profiles[1].stages.size() == 1, "Room B correction restored");

    // Same file, one changed byte: the v4 checksum must reject it.
    auto damaged = readExact(fileA);
    const auto pos = damaged.find("780");
    require(pos != std::string::npos, "serialized Room A contains expected RT60 token");
    damaged[pos] = '9';
    rt60::ProfileBundle rejected = loadedB;
    require(!rt60::ProfileBundleCodec::deserialize(damaged, rejected), "checksum rejects damaged profile");
    require(rejected.metadata.profileName == "Room B", "failed load leaves previous profile untouched"); // transactional failure

    std::remove(fileA.c_str());
    std::remove(fileB.c_str());
    std::cout << "Profile v4 exact disk I/O and two-room reload tests passed\n";
    return 0;
}
