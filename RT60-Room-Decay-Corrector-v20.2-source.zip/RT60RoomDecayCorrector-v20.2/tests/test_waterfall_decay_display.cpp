#include "core/WaterfallData.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

namespace {
constexpr double kPi = 3.1415926535897932384626433832795;

void require(bool condition, const char* message)
{
    if (!condition) {
        std::cerr << "FAILED: " << message << "\n";
        std::exit(1);
    }
}

std::vector<float> makeDecayingSinusoid(double sampleRate,
                                        float frequencyHz,
                                        float t60Ms,
                                        float seconds)
{
    const auto count = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> signal(count, 0.0f);
    const double t60Seconds = static_cast<double>(t60Ms) / 1000.0;
    const double log001 = std::log(0.001);

    for (std::size_t i = 0; i < count; ++i) {
        const double t = static_cast<double>(i) / sampleRate;
        const double envelope = std::exp(log001 * t / t60Seconds);
        signal[i] = static_cast<float>(envelope * std::sin(2.0 * kPi * frequencyHz * t));
    }
    return signal;
}

std::size_t nearestIndex(const std::vector<float>& values, float target)
{
    std::size_t best = 0;
    for (std::size_t i = 1; i < values.size(); ++i)
        if (std::abs(values[i] - target) < std::abs(values[best] - target))
            best = i;
    return best;
}
}

int main()
{
    constexpr double sampleRate = 48000.0;
    constexpr float frequencyHz = 63.0f;

    rt60::WaterfallConfig config;
    config.minHz = 20.0f;
    config.maxHz = 300.0f;
    config.maxTimeMs = 1000.0f;
    config.timeStepMs = 20.0f;
    config.frequencyPoints = 96;
    config.fftSize = 8192;
    config.floorDb = -80.0f;

    const auto before = rt60::WaterfallAnalyzer::analyse(
        makeDecayingSinusoid(sampleRate, frequencyHz, 500.0f, 2.0f), sampleRate, config);
    const auto after = rt60::WaterfallAnalyzer::analyse(
        makeDecayingSinusoid(sampleRate, frequencyHz, 250.0f, 2.0f), sampleRate, config);

    require(before.valid(), "500 ms waterfall must be valid");
    require(after.valid(), "250 ms waterfall must be valid");

    const auto frequencyIndex = nearestIndex(before.frequenciesHz, frequencyHz);
    const auto timeIndex = nearestIndex(before.timesMs, 240.0f);

    const float beforeDecay = rt60::WaterfallAnalyzer::decayLevelDb(before, timeIndex, frequencyIndex);
    const float afterDecay = rt60::WaterfallAnalyzer::decayLevelDb(after, timeIndex, frequencyIndex);

    std::cout << "63 Hz @ " << before.timesMs[timeIndex] << " ms: BEFORE "
              << beforeDecay << " dB, AFTER " << afterDecay << " dB\n";

    // For an exponential amplitude decay, 500 ms T60 is about -28.8 dB at
    // 240 ms and 250 ms T60 is about -57.6 dB. The waterfall display should
    // expose that decay difference instead of hiding it behind the broadband peak.
    require(std::abs(beforeDecay - (-28.8f)) < 2.0f,
            "500 ms decay display must be close to -28.8 dB at 240 ms");
    require(std::abs(afterDecay - (-57.6f)) < 2.0f,
            "250 ms decay display must be close to -57.6 dB at 240 ms");
    require(afterDecay < beforeDecay - 20.0f,
            "AFTER decay must visibly fall much faster than BEFORE");

    std::cout << "waterfall decay display regression passed\n";
    return 0;
}
