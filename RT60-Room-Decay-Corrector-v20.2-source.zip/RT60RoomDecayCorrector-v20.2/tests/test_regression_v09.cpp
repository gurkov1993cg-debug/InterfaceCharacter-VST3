#include "core/CorrectionEngine.hpp"
#include "core/MeasurementEngine.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <vector>

namespace {
constexpr double kPi = 3.14159265358979323846;

std::vector<float> makeModalRoom(double sampleRate, float frequencyHz, float t60Ms, float seconds)
{
    const std::size_t n = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> h(n, 0.0f);
    const double r = std::exp(std::log(0.001) / (sampleRate * (t60Ms / 1000.0)));
    const double a1 = -2.0 * r * std::cos(2.0 * kPi * frequencyHz / sampleRate);
    const double a2 = r * r;
    double y1 = 0.0, y2 = 0.0;
    for (std::size_t i = 0; i < n; ++i) {
        const double x = i == 0 ? 1.0 : 0.0;
        const double y = x - a1 * y1 - a2 * y2;
        h[i] = static_cast<float>(y);
        y2 = y1;
        y1 = y;
    }
    float peak = 0.0f;
    for (float v : h) peak = std::max(peak, std::abs(v));
    if (peak > 0.0f)
        for (auto& v : h) v /= peak;
    return h;
}

bool near(float a, float b, float tolerance) { return std::abs(a - b) <= tolerance; }
}

int main()
{
    // Frozen v0.9 reference fixture. v0.10 intentionally leaves the decay
    // design DSP unchanged; UI/profile work must not silently move these
    // filter decisions.
    constexpr double fs = 48000.0;
    rt60::MeasurementConfig cfg;
    cfg.sampleRate = fs;
    rt60::MeasurementEngine measurement(cfg);

    auto room63 = makeModalRoom(fs, 63.0f, 900.0f, 2.0f);
    auto room125 = makeModalRoom(fs, 125.0f, 700.0f, 2.0f);
    std::vector<float> room(room63.size(), 0.0f);
    for (std::size_t i = 0; i < room.size(); ++i)
        room[i] = room63[i] + 0.65f * room125[i];

    const auto measured = measurement.analyseImpulseResponse(room);
    rt60::CorrectionDesignConfig config;
    config.targetMs = 300.0f;
    config.strength = 0.85f;
    config.maxCorrectionHz = 500.0f;
    config.minConfidence = 0.35f;
    config.maxT60ReductionPerPass = 0.50f;
    // These golden numbers pin the original 1/3-octave band search. That path
    // is now the fallback rather than the default, so it is selected
    // explicitly here; the pole detector has its own test.
    config.useModeDetector = false;

    rt60::CorrectionEngine engine;
    const auto profile = engine.design(measured, config);
    assert(profile.stages.size() == 2);

    const auto& a = profile.stages[0];
    const auto& b = profile.stages[1];
    assert(near(a.frequencyHz, 62.9998f, 0.05f));
    assert(near(a.measuredT60Ms, 907.531f, 1.0f));
    assert(near(a.desiredT60Ms, 453.766f, 1.0f));
    assert(near(a.estimatedQ, 24.0f, 0.05f));
    assert(near(rt60::CorrectionEngine::stageAttenuationDb(a, fs), -6.0218f, 0.05f));

    assert(near(b.frequencyHz, 124.999f, 0.05f));
    assert(near(b.measuredT60Ms, 706.469f, 1.0f));
    assert(near(b.desiredT60Ms, 361.084f, 1.0f));
    assert(near(b.estimatedQ, 24.0f, 0.05f));
    assert(near(rt60::CorrectionEngine::stageAttenuationDb(b, fs), -5.83018f, 0.05f));

    // Both reference stages remain cuts, never boosts.
    assert(rt60::CorrectionEngine::stageAttenuationDb(a, fs) <= 0.0001f);
    assert(rt60::CorrectionEngine::stageAttenuationDb(b, fs) <= 0.0001f);
    return 0;
}
