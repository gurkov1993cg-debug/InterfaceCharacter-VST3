# Apply this update to InterfaceCharacter-VST3

Overlay the files in this archive onto the repository root, preserving paths, then commit/push to `main`.
The existing `.github/workflows/windows-vst3.yml` will run the Windows x64 VST3 build automatically.

Files changed/added:
- src/CharacterProcessor.cpp
- src/CharacterProcessor.hpp
- src/Profile.hpp
- src/vst3/InterfaceCharacterController.cpp
- src/vst3/InterfaceCharacterProcessor.cpp
- src/vst3/entry.cpp
- tests/test_character.cpp
- profiles/reference-profiles.json
- README.md
- docs/lyra1-model.md (new)

Local core validation command:

g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -Isrc src/CharacterProcessor.cpp tests/test_character.cpp -o interface_character_tests
./interface_character_tests

Expected output:
Interface Character / Prism Lyra 1 DSP tests passed
