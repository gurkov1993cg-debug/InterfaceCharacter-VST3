#include "plugin/PluginEditor.hpp"

RT60Editor::RT60Editor(RT60Processor& p) : AudioProcessorEditor(&p), processor_(p)
{
    setSize(1000, 820);
    graph_.setModel(&processor_.model());
    addAndMakeVisible(graph_);
    addAndMakeVisible(waterfallGraph_);

    title_.setText("RT60 ROOM DECAY CORRECTOR v0.7 - SAVED PROFILE + WATERFALL", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(22.0f, juce::Font::bold));
    addAndMakeVisible(title_);

    waterfallLabel_.setText("Waterfall", juce::dontSendNotification);
    addAndMakeVisible(waterfallLabel_);
    waterfallChannelSelector_.addItem("LEFT", 1);
    waterfallChannelSelector_.addItem("RIGHT", 2);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    waterfallStateSelector_.addItem("BEFORE", 1);
    waterfallStateSelector_.addItem("AFTER", 2);
    waterfallStateSelector_.setSelectedId(1, juce::dontSendNotification);
    addAndMakeVisible(waterfallChannelSelector_);
    addAndMakeVisible(waterfallStateSelector_);
    waterfallChannelSelector_.onChange = [this] { refreshWaterfall(); };
    waterfallStateSelector_.onChange = [this] { refreshWaterfall(); };

    addAndMakeVisible(status_);
    addAndMakeVisible(reloadButton_);
    addAndMakeVisible(bypassButton_);
    bypassA_ = std::make_unique<ButtonAttachment>(processor_.apvts, "bypass", bypassButton_);

    reloadButton_.onClick = [this] {
        processor_.reloadActiveProfile();
        updateStatus();
        graph_.repaint();
        refreshWaterfall();
    };
    updateStatus();
    refreshWaterfall();
    startTimerHz(10);
}

void RT60Editor::refreshWaterfall()
{
    const int channel = juce::jlimit(0, 1, waterfallChannelSelector_.getSelectedId() - 1);
    const bool after = waterfallStateSelector_.getSelectedId() == 2;
    waterfallGraph_.setData(processor_.waterfall(channel, after));
    waterfallGraph_.setCaption("MEASURED WATERFALL - " + juce::String(channel == 0 ? "LEFT" : "RIGHT")
                               + (after ? " AFTER" : " BEFORE") + " - 20 to 300 Hz");
}

void RT60Editor::updateStatus()
{
    if (processor_.hasActiveProfile())
        status_.setText("ACTIVE measured stereo decay profile | " + juce::String(processor_.activeStageCount())
                        + " correction stages | BEFORE/AFTER waterfall loaded when available",
                        juce::dontSendNotification);
    else
        status_.setText("No saved profile. Run standalone: MEASURE L + R -> AUTO CORRECT RT60 -> SAVE PROFILE.",
                        juce::dontSendNotification);
}

void RT60Editor::timerCallback()
{
    graph_.repaint();
    waterfallGraph_.repaint();
}

void RT60Editor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(14, 16, 20));
}

void RT60Editor::resized()
{
    auto r = getLocalBounds().reduced(18);
    title_.setBounds(r.removeFromTop(38));
    status_.setBounds(r.removeFromTop(28));
    graph_.setBounds(r.removeFromTop(300));
    r.removeFromTop(8);
    waterfallGraph_.setBounds(r.removeFromTop(330));
    r.removeFromTop(6);
    auto selectors = r.removeFromTop(30);
    waterfallLabel_.setBounds(selectors.removeFromLeft(75));
    waterfallChannelSelector_.setBounds(selectors.removeFromLeft(130));
    selectors.removeFromLeft(8);
    waterfallStateSelector_.setBounds(selectors.removeFromLeft(130));
    r.removeFromTop(6);
    auto row = r.removeFromTop(38);
    reloadButton_.setBounds(row.removeFromLeft(260));
    row.removeFromLeft(12);
    bypassButton_.setBounds(row.removeFromLeft(120));
}
