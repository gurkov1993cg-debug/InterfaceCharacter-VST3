#include "core/CorrectionEngine.hpp"
#include "core/MeasurementEngine.hpp"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

namespace {
constexpr double kPi = 3.14159265358979323846;

std::vector<float> makeModalRoom(double sampleRate, float frequencyHz, float t60Ms, float seconds)
{
    const std::size_t n = static_cast<std::size_t>(sampleRate * seconds);
    std::vector<float> h(n, 0.0f);
    const double r = std::exp(std::log(0.001) / (sampleRate * (t60Ms / 1000.0)));
    const double a1 = -2.0 * r * std::cos(2.0 * kPi * frequencyHz / sampleRate);
    const double a2 = r * r;
    double y1 = 0.0, y2 = 0.0;
    for (std::size_t i = 0; i < n; ++i) {
        const double x = i == 0 ? 1.0 : 0.0;
        const double y = x - a1 * y1 - a2 * y2;
        h[i] = static_cast<float>(y);
        y2 = y1;
        y1 = y;
    }
    float peak = 0.0f;
    for (float v : h) peak = std::max(peak, std::abs(v));
    if (peak > 0.0f)
        for (auto& v : h) v /= peak;
    return h;
}

float bandRt60Near(const rt60::MeasurementResult& r, float frequency)
{
    float bestDistance = 1.0e9f;
    float value = 0.0f;
    for (const auto& b : r.bands) {
        const float d = std::abs(std::log(b.frequencyHz / frequency));
        if (b.valid && d < bestDistance) {
            bestDistance = d;
            value = b.rt60Ms;
        }
    }
    return value;
}
}

int main()
{
    constexpr double fs = 48000.0;
    constexpr float frequency = 63.0f;
    constexpr float roomT60 = 900.0f;
    constexpr float targetT60 = 300.0f;

    rt60::MeasurementConfig cfg;
    cfg.sampleRate = fs;
    rt60::MeasurementEngine measurement(cfg);

    auto room = makeModalRoom(fs, frequency, roomT60, 2.0f);
    const auto before = measurement.analyseImpulseResponse(room);
    const float beforeMs = bandRt60Near(before, frequency);

    rt60::CorrectionProfile profile;
    profile.targetMs = targetT60;
    profile.stages.push_back({frequency, roomT60, targetT60, 4});

    rt60::CorrectionFilterBank corrector;
    corrector.configure(profile, fs);
    corrector.process(room.data(), static_cast<int>(room.size()));
    const auto after = measurement.analyseImpulseResponse(room);
    const float afterMs = bandRt60Near(after, frequency);

    std::cout << "before=" << beforeMs << " ms after=" << afterMs << " ms\n";
    if (!(beforeMs > 650.0f && beforeMs < 1200.0f)) return 1;
    if (!(afterMs > 180.0f && afterMs < 480.0f)) return 2;
    if (!(afterMs < beforeMs * 0.65f)) return 3;

    const std::string encoded = rt60::CorrectionEngine::serialize(profile);
    rt60::CorrectionProfile decoded;
    if (!rt60::CorrectionEngine::deserialize(encoded, decoded)) return 4;
    if (decoded.stages.size() != 1) return 5;
    if (std::abs(decoded.stages[0].frequencyHz - frequency) > 0.1f) return 6;

    // Full automatic design test: detect two late modal peaks from the measured
    // impulse response, build the profile, and shorten both without manual bands.
    auto roomA = makeModalRoom(fs, 63.0f, 900.0f, 2.0f);
    auto roomB = makeModalRoom(fs, 125.0f, 700.0f, 2.0f);
    std::vector<float> twoModes(roomA.size(), 0.0f);
    for (std::size_t i = 0; i < twoModes.size(); ++i)
        twoModes[i] = roomA[i] + 0.65f * roomB[i];

    const auto multiBefore = measurement.analyseImpulseResponse(twoModes);
    rt60::CorrectionDesignConfig designCfg;
    designCfg.targetMs = targetT60;
    designCfg.strength = 1.0f;
    designCfg.maxCorrectionHz = 500.0f;
    rt60::CorrectionEngine engine;
    auto autoProfile = engine.design(multiBefore, designCfg);
    if (autoProfile.stages.size() < 2 || autoProfile.stages.size() > 5) return 7;

    rt60::CorrectionFilterBank autoBank;
    autoBank.configure(autoProfile, fs);
    autoBank.process(twoModes.data(), static_cast<int>(twoModes.size()));
    const auto multiAfter = measurement.analyseImpulseResponse(twoModes);
    const float after63 = bandRt60Near(multiAfter, 63.0f);
    const float after125 = bandRt60Near(multiAfter, 125.0f);
    std::cout << "auto stages=" << autoProfile.stages.size()
              << " after63=" << after63 << " after125=" << after125 << "\n";
    if (!(after63 > 180.0f && after63 < 450.0f)) return 8;
    if (!(after125 > 180.0f && after125 < 450.0f)) return 9;
    return 0;
}
