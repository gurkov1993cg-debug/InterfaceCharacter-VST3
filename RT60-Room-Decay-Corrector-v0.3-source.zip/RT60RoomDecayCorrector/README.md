# RT60 Room Decay Corrector v0.3

Closed-loop room-decay correction prototype for Windows and macOS Intel, with a standalone measurement app and VST3 monitor-correction plugin.

## Priority 1: real RT60 decay correction

v0.3 replaces the old static "cut the loud band" idea with a modal pole/zero decay shaper:

1. Play an exponential sweep and capture the measurement microphone.
2. Deconvolve to an impulse response.
3. Measure EDT/T20/T30/RT60 in 29 third-octave bands.
4. Inspect the late-field spectrum to locate dominant ringing frequencies inside long-decay bands.
5. For each selected mode, place a digital zero on the measured room pole and a new stable pole corresponding to the requested target decay.
6. Play the verification sweep THROUGH the active correction.
7. Re-measure the actual corrected response.
8. If residual long decay remains, append a gentler correction pass and repeat, up to four closed-loop passes.
9. Save the measured correction as the active profile. The VST3 loads that same profile automatically.

The correction filter is constrained to never create positive gain, protecting headroom and avoiding deep-null boosts.

## Standalone workflow

- Select microphone input and monitor output in the audio-device panel.
- Set `Target RT60`.
- Keep `Decay correction strength` at 100% for full target pursuit, or lower it for gentler correction.
- Set `Max correction frequency` (default 1200 Hz).
- Press `MEASURE ROOM`.
- When the measurement is valid, press `AUTO CORRECT RT60`.
- The app automatically measures through the correction, refines residual decay, and updates `Measured After`.
- `CORRECTION ACTIVE` bypasses/enables the current profile for verification.

## VST3 workflow

The standalone app writes the active profile to the user's application-data folder. The VST3 loads it when inserted/started. Use `RELOAD MEASURED PROFILE` after creating a new room measurement without restarting the DAW.

For Cubase, place the VST3 on the Control Room monitor path so room correction is not rendered into exports.

## Physics / scope

The algorithm can strongly reshape the loudspeaker-to-microphone decay response at the measured listening position by cancelling identified modal poles and replacing them with more heavily damped target poles. Exact RT60 equality throughout an entire room cannot be guaranteed from one loudspeaker/microphone transfer function; spatial correction will be a later phase after the single-position closed-loop engine is validated on real measurements.

## Tests

The core includes deterministic decay-correction tests. A synthetic 63 Hz room mode with about 900 ms decay is transformed to about 300 ms using the same pole/zero engine. A two-mode automatic-detection test verifies that multiple modal decays are detected and shortened toward the target.
