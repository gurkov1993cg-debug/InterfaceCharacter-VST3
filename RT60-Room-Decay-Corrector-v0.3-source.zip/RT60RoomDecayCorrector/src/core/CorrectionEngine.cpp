#include "core/CorrectionEngine.hpp"

#include <algorithm>
#include <cmath>
#include <complex>
#include <iomanip>
#include <limits>
#include <sstream>

namespace rt60 {
namespace {

constexpr double kPi = 3.1415926535897932384626433832795;
constexpr std::array<float, kBandCount> kCenters{{
    25, 31.5f, 40, 50, 63, 80, 100, 125, 160, 200,
    250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000,
    2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000
}};

std::size_t nextPow2(std::size_t value)
{
    std::size_t n = 1;
    while (n < value) n <<= 1u;
    return n;
}

void fft(std::vector<std::complex<double>>& a)
{
    const std::size_t n = a.size();
    for (std::size_t i = 1, j = 0; i < n; ++i) {
        std::size_t bit = n >> 1u;
        for (; j & bit; bit >>= 1u) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (std::size_t len = 2; len <= n; len <<= 1u) {
        const double angle = -2.0 * kPi / static_cast<double>(len);
        const std::complex<double> wlen(std::cos(angle), std::sin(angle));
        for (std::size_t i = 0; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (std::size_t j = 0; j < len / 2; ++j) {
                const auto u = a[i + j];
                const auto v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
}

struct PeakInfo {
    float frequencyHz = 0.0f;
    double power = 0.0;
};

PeakInfo dominantPeak(const std::vector<float>& ir, double sampleRate, float center)
{
    PeakInfo result{center, 0.0};
    if (ir.empty() || sampleRate <= 0.0) return result;

    // Ignore the direct sound and inspect the late field, where room modes
    // dominate. This prevents a broadband direct impulse from creating a
    // false correction stage in every 1/3-octave band.
    const std::size_t start = std::min(ir.size(), static_cast<std::size_t>(sampleRate * 0.015));
    const std::size_t available = ir.size() > start ? ir.size() - start : 0;
    const std::size_t copyCount = std::min<std::size_t>(available, static_cast<std::size_t>(sampleRate * 2.0));
    if (copyCount < 64) return result;
    const std::size_t n = nextPow2(copyCount);
    std::vector<std::complex<double>> bins(n);
    for (std::size_t i = 0; i < copyCount; ++i) {
        const double w = copyCount > 1 ? 0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(i) / static_cast<double>(copyCount - 1)) : 1.0;
        bins[i] = static_cast<double>(ir[start + i]) * w;
    }
    fft(bins);

    const double edge = std::pow(2.0, 1.0 / 6.0);
    const double low = center / edge;
    const double high = center * edge;
    std::size_t first = static_cast<std::size_t>(std::ceil(low * static_cast<double>(n) / sampleRate));
    std::size_t last = static_cast<std::size_t>(std::floor(high * static_cast<double>(n) / sampleRate));
    first = std::max<std::size_t>(1, first);
    last = std::min<std::size_t>(n / 2 - 1, last);
    if (last <= first) return result;

    std::size_t best = first;
    double bestPower = 0.0;
    for (std::size_t k = first; k <= last; ++k) {
        const double power = std::norm(bins[k - 1]) + std::norm(bins[k]) + std::norm(bins[k + 1]);
        if (power > bestPower) {
            bestPower = power;
            best = k;
        }
    }
    result.frequencyHz = static_cast<float>(static_cast<double>(best) * sampleRate / static_cast<double>(n));
    result.power = bestPower;
    return result;
}

float safeDesired(float measured, float target, float strength)
{
    strength = std::clamp(strength, 0.0f, 1.0f);
    return std::max(target, measured + strength * (target - measured));
}

bool nearSameMode(float a, float b)
{
    if (a <= 0.0f || b <= 0.0f) return false;
    return std::abs(std::log2(a / b)) < (1.0f / 12.0f); // within one semitone
}

CorrectionFilterBank::Stage makeStage(const CorrectionStageSpec& spec, double sampleRate)
{
    CorrectionFilterBank::Stage s;
    if (sampleRate <= 1000.0 || spec.frequencyHz <= 0.0f || spec.frequencyHz >= sampleRate * 0.47)
        return s;

    const double measuredSec = std::max(0.06, static_cast<double>(spec.measuredT60Ms) / 1000.0);
    const double desiredSec = std::clamp(static_cast<double>(spec.desiredT60Ms) / 1000.0, 0.05, measuredSec);
    if (desiredSec >= measuredSec * 0.995)
        return s;

    // A modal pole with radius r loses 60 dB in T60 seconds when
    // r^(Fs*T60) = 0.001. The correction places a zero on the measured
    // room pole and a new, more heavily damped pole at the desired T60.
    const double log001 = std::log(0.001);
    const double rRoom = std::exp(log001 / (sampleRate * measuredSec));
    const double rDesired = std::exp(log001 / (sampleRate * desiredSec));
    const double w = 2.0 * kPi * static_cast<double>(spec.frequencyHz) / sampleRate;
    const double c = std::cos(w);

    s.b0 = 1.0;
    s.b1 = -2.0 * rRoom * c;
    s.b2 = rRoom * rRoom;
    s.a1 = -2.0 * rDesired * c;
    s.a2 = rDesired * rDesired;

    // Never allow a correction stage to create positive gain. Scale the
    // numerator so the maximum sampled magnitude is <= 0 dB. This preserves
    // the pole/zero decay transformation while protecting headroom.
    double maxMag = 0.0;
    for (int i = 0; i <= 512; ++i) {
        const double omega = kPi * static_cast<double>(i) / 512.0;
        const std::complex<double> z1(std::cos(-omega), std::sin(-omega));
        const std::complex<double> z2 = z1 * z1;
        const auto num = s.b0 + s.b1 * z1 + s.b2 * z2;
        const auto den = 1.0 + s.a1 * z1 + s.a2 * z2;
        if (std::abs(den) > 1.0e-12)
            maxMag = std::max(maxMag, std::abs(num / den));
    }
    if (maxMag > 1.0) {
        const double scale = 1.0 / maxMag;
        s.b0 *= scale; s.b1 *= scale; s.b2 *= scale;
    }
    return s;
}

} // namespace

CorrectionProfile CorrectionEngine::design(const MeasurementResult& measurement,
                                           const CorrectionDesignConfig& config) const
{
    CorrectionProfile profile;
    profile.targetMs = std::clamp(config.targetMs, 80.0f, 2000.0f);
    profile.strength = std::clamp(config.strength, 0.0f, 1.0f);

    struct Candidate {
        CorrectionStageSpec spec;
        float score = 0.0f;
        double peakPower = 0.0;
    };
    std::vector<Candidate> candidates;

    for (std::size_t i = 0; i < kBandCount; ++i) {
        const auto& band = measurement.bands[i];
        const float measured = band.valid ? band.rt60Ms : 0.0f;
        profile.measuredBandMs[i] = measured;
        profile.targetBandMs[i] = profile.targetMs;
        if (!band.valid || measured <= profile.targetMs * (1.0f + config.tolerance))
            continue;
        if (kCenters[i] < config.minCorrectionHz || kCenters[i] > config.maxCorrectionHz)
            continue;

        Candidate c;
        c.spec.sourceBand = i;
        c.spec.measuredT60Ms = measured;
        c.spec.desiredT60Ms = safeDesired(measured, profile.targetMs, profile.strength);
        const auto peak = dominantPeak(measurement.impulseResponse,
                                       measurement.sampleRate,
                                       kCenters[i]);
        c.spec.frequencyHz = peak.frequencyHz;
        c.peakPower = peak.power;
        // Clamp to the source 1/3-octave band to avoid impossible peak assignment.
        const float edge = static_cast<float>(std::pow(2.0, 1.0 / 6.0));
        c.spec.frequencyHz = std::clamp(c.spec.frequencyHz, kCenters[i] / edge, kCenters[i] * edge);
        c.score = (measured / profile.targetMs - 1.0f) * std::max(0.25f, band.fitQuality);
        candidates.push_back(c);
    }

    double strongestPower = 0.0;
    for (const auto& c : candidates)
        strongestPower = std::max(strongestPower, c.peakPower);
    if (strongestPower > 0.0) {
        // Ignore late-field peaks more than 36 dB below the strongest candidate.
        // They are normally leakage/noise, not modes worth actively cancelling.
        const double floorPower = strongestPower * 0.000251188643150958; // -36 dB power
        candidates.erase(std::remove_if(candidates.begin(), candidates.end(),
            [floorPower](const Candidate& c) { return c.peakPower < floorPower; }), candidates.end());
    }

    std::sort(candidates.begin(), candidates.end(), [strongestPower](const Candidate& a, const Candidate& b) {
        const double wa = strongestPower > 0.0 ? std::sqrt(a.peakPower / strongestPower) : 1.0;
        const double wb = strongestPower > 0.0 ? std::sqrt(b.peakPower / strongestPower) : 1.0;
        return a.score * wa > b.score * wb;
    });

    for (const auto& candidate : candidates) {
        bool duplicate = false;
        for (const auto& existing : profile.stages) {
            if (nearSameMode(existing.frequencyHz, candidate.spec.frequencyHz)) {
                duplicate = true;
                break;
            }
        }
        if (!duplicate)
            profile.stages.push_back(candidate.spec);
        if (static_cast<int>(profile.stages.size()) >= config.maxNewStages)
            break;
    }
    return profile;
}

void CorrectionEngine::appendIncremental(CorrectionProfile& accumulated,
                                         const CorrectionProfile& incremental,
                                         std::size_t maxTotalStages)
{
    const bool hadStages = !accumulated.stages.empty();
    if (accumulated.targetMs <= 0.0f)
        accumulated.targetMs = incremental.targetMs;
    accumulated.strength = incremental.strength;
    if (!hadStages)
        accumulated.measuredBandMs = incremental.measuredBandMs;
    accumulated.targetBandMs = incremental.targetBandMs;

    for (const auto& stage : incremental.stages) {
        if (accumulated.stages.size() >= maxTotalStages)
            break;
        accumulated.stages.push_back(stage);
    }
}

std::string CorrectionEngine::serialize(const CorrectionProfile& profile)
{
    std::ostringstream out;
    out << std::setprecision(9);
    out << "RT60_PROFILE " << CorrectionProfile::kFormatVersion << '\n';
    out << "TARGET " << profile.targetMs << '\n';
    out << "STRENGTH " << profile.strength << '\n';
    out << "BANDS";
    for (float v : profile.measuredBandMs) out << ' ' << v;
    out << '\n';
    out << "TARGETS";
    for (float v : profile.targetBandMs) out << ' ' << v;
    out << '\n';
    for (const auto& s : profile.stages)
        out << "STAGE " << s.frequencyHz << ' ' << s.measuredT60Ms << ' '
            << s.desiredT60Ms << ' ' << s.sourceBand << '\n';
    return out.str();
}

bool CorrectionEngine::deserialize(const std::string& text, CorrectionProfile& profile)
{
    std::istringstream in(text);
    std::string tag;
    int version = 0;
    if (!(in >> tag >> version) || tag != "RT60_PROFILE" || version != CorrectionProfile::kFormatVersion)
        return false;

    CorrectionProfile parsed;
    while (in >> tag) {
        if (tag == "TARGET") {
            in >> parsed.targetMs;
        } else if (tag == "STRENGTH") {
            in >> parsed.strength;
        } else if (tag == "BANDS") {
            for (auto& v : parsed.measuredBandMs) in >> v;
        } else if (tag == "TARGETS") {
            for (auto& v : parsed.targetBandMs) in >> v;
        } else if (tag == "STAGE") {
            CorrectionStageSpec s;
            in >> s.frequencyHz >> s.measuredT60Ms >> s.desiredT60Ms >> s.sourceBand;
            if (in && s.frequencyHz > 0.0f)
                parsed.stages.push_back(s);
        } else {
            std::string rest;
            std::getline(in, rest);
        }
    }
    profile = std::move(parsed);
    return true;
}

void CorrectionFilterBank::configure(const CorrectionProfile& profile, double sampleRate)
{
    stages_.clear();
    stages_.reserve(profile.stages.size());
    for (const auto& spec : profile.stages) {
        auto stage = makeStage(spec, sampleRate);
        // Identity means the requested transformation was not usable.
        if (std::abs(stage.b1) > 1.0e-12 || std::abs(stage.b2) > 1.0e-12 ||
            std::abs(stage.a1) > 1.0e-12 || std::abs(stage.a2) > 1.0e-12)
            stages_.push_back(stage);
    }
    reset();
}

void CorrectionFilterBank::reset() noexcept
{
    for (auto& s : stages_) s.z1 = s.z2 = 0.0;
}

float CorrectionFilterBank::processSample(float sample) noexcept
{
    double x = sample;
    for (auto& s : stages_) {
        const double y = s.b0 * x + s.z1;
        s.z1 = s.b1 * x - s.a1 * y + s.z2;
        s.z2 = s.b2 * x - s.a2 * y;
        x = y;
    }
    return static_cast<float>(x);
}

void CorrectionFilterBank::process(float* samples, int count) noexcept
{
    if (samples == nullptr || count <= 0) return;
    for (int i = 0; i < count; ++i) samples[i] = processSample(samples[i]);
}

} // namespace rt60
