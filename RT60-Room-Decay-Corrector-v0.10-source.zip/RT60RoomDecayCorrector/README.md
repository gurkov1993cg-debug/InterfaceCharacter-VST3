# RT60 Room Decay Corrector v0.10

v0.10 keeps the working v0.9 decay-correction DSP intact and focuses on inspection, repeatability, measurement confidence, and safer profile management.

## What v0.10 adds

- **LEFT / RIGHT / WORST RT60 graph view** using real per-speaker BEFORE and AFTER measurements.
- **Decay-change readout** with average low-frequency improvement plus the three longest measured bands.
- **Measurement Quality panel** showing capture peak, SNR/dynamic-range estimate, trusted-band count, and clipping state for L/R.
- **Filter Inspector** showing every live correction stage as frequency, estimated Q, actual attenuation at the modal centre, measured RT60 -> desired RT60, and confidence.
- **Profile bundle v2 metadata**: app version, measurement sample rate, target, maximum correction frequency, VERIFIED/UNVERIFIED, fallback usage, timestamp, and profile name.
- **Sample-rate/profile warnings** in the VST3. Correction stages are stored in physical Hz/time and are recalculated for the current session sample rate; the warning is informational, not a blind rejection.
- **Profile Manager in the VST3** with direct load, shared-profile reload, session recent list, A/B previous, UNDO LOAD, and BEST VERIFIED.
- **Best verified mirror**: saving a VERIFIED standalone profile also updates `best_verified.rt60profile` for one-click recall inside Cubase.
- **Transactional loading remains**: corrupt/truncated profile bundles never partially replace the currently working correction.
- **v0.9 regression lock test** freezes a deterministic two-mode reference fixture so UI/profile changes cannot silently alter Fc/Q/decay/attenuation decisions.

## DSP safety retained

- No automatic boost stages.
- Default correction limit remains 300 Hz.
- LEFT and RIGHT are measured and corrected independently.
- Clipped sweeps are rejected.
- Correction-bank publication remains lock-free in the real-time audio callback.
- AUTO VERIFY can iterate to the best measured stereo pass; warnings keep the candidate instead of destroying it.

## Recommended standalone workflow

1. Select one measurement microphone input and two monitor outputs.
2. `MEASURE L + R`.
3. Check **MEASUREMENT QUALITY** and switch the RT60 graph between LEFT / RIGHT / WORST.
4. `AUTO CORRECT RT60`.
5. Inspect the generated stages in **FILTER INSPECTOR**.
6. Use AUTO VERIFY or `RE-MEASURE L + R` for a real AFTER measurement.
7. Check the numerical decay-change readout.
8. `SAVE PROFILE AS...`.

## Cubase / VST3 workflow

Put the VST3 on a **Control Room / Monitor insert**, not on the mix/export path.

Inside the VST3 you can:

- `LOAD PROFILE...` directly;
- `RELOAD SHARED` from the standalone mirror;
- use `A/B PREVIOUS` or `UNDO LOAD` after loading another profile;
- recall `BEST VERIFIED`;
- choose LEFT / RIGHT / WORST on the RT60 graph;
- inspect the exact correction stages and profile metadata.

## Core tests

v0.10 has eight core tests:

1. decay model
2. measurement / deconvolution
3. correction engine and real feedback
4. stereo decay uniformity
5. measured waterfall
6. stereo display snapshot v2 + v1 compatibility
7. profile bundle v2 metadata + transactional rejection
8. frozen v0.9 DSP regression fixture

The local v0.10 core suite passes **8/8**.
