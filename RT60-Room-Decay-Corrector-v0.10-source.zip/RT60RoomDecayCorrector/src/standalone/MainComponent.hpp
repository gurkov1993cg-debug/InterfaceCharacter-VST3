#pragma once

#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>

#include "core/CorrectionEngine.hpp"
#include "core/DecayUniformity.hpp"
#include "core/DecayModel.hpp"
#include "core/MeasurementEngine.hpp"
#include "ui/RT60Graph.hpp"
#include "core/WaterfallData.hpp"
#include "core/DisplaySnapshot.hpp"
#include "core/ProfileBundle.hpp"
#include "ui/WaterfallGraph.hpp"

#include <array>
#include <atomic>
#include <vector>
#include <memory>

class MainComponent final : public juce::Component,
                            private juce::AudioIODeviceCallback,
                            private juce::Timer {
public:
    MainComponent();
    ~MainComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    struct CorrectionBanks {
        rt60::CorrectionFilterBank left;
        rt60::CorrectionFilterBank right;
    };

    struct MeasurementBuffers {
        std::vector<float> excitation;
        std::vector<float> capture;
    };

    void refreshModel();
    void refreshMicInputSelector();
    void updateGraphFromStereo(bool afterCorrection);
    void refreshGraphView();
    void refreshImprovementReadout();
    void refreshMeasurementQuality();
    void refreshFilterInspector();
    void updateWaterfallForMeasurement(int channel, bool afterCorrection, const rt60::MeasurementResult& result);
    void refreshWaterfallView();
    void saveWaterfallSnapshots();
    void loadWaterfallSnapshots();
    void startMeasurement(bool afterCorrection);
    void startMeasurementChannel(int logicalChannel);
    void finishMeasurementOnMessageThread();
    void finishStereoMeasurementPass();
    void updateMeasurementConfigFromDevice();
    void startAutoCorrection();
    void publishCorrectionBanks();
    void saveActiveProfiles();
    void saveProfileNow();
    void beginSaveProfileAs();
    void beginLoadProfile();
    bool saveProfileBundleToFile(const juce::File& file);
    bool loadProfileBundleFromFile(const juce::File& file);
    rt60::ProfileBundle makeProfileBundle(const juce::String& profileName = {}) const;
    void saveDisplaySnapshot();
    bool loadDisplaySnapshot(rt60::DisplaySnapshot& snapshot) const;
    rt60::DisplaySnapshot makeDisplaySnapshot() const;
    void applyDisplaySnapshot(const rt60::DisplaySnapshot& snapshot);
    void loadActiveProfiles();
    void finishAutoCorrection(bool hitIterationLimit, const juce::String& stopReason = {});
    void restoreBestVerifiedPass();
    void abortUnhelpfulAutoCorrection(const juce::String& reason);
    rt60::DecayUniformityReport evaluateUniformity(int channel,
                                                   const rt60::MeasurementResult& result) const;
    void applyRecommendedStereoTarget();
    float combinedObjective(const std::array<rt60::DecayUniformityReport, 2>& reports) const;
    bool hasAnyCorrection() const noexcept;
    bool baselinesValid() const noexcept;
    void enableIdleControls();
    static juce::File profileDirectory();
    static juce::File activeProfileFile(int channel);
    static juce::File legacyProfileFile();
    static juce::File waterfallFile(int channel, bool afterCorrection);
    static juce::File displaySnapshotFile();
    static juce::File activeBundleFile();
    static juce::File bestVerifiedProfileFile();

    void audioDeviceIOCallbackWithContext(const float* const* inputChannelData,
                                          int numInputChannels,
                                          float* const* outputChannelData,
                                          int numOutputChannels,
                                          int numSamples,
                                          const juce::AudioIODeviceCallbackContext&) override;
    void audioDeviceAboutToStart(juce::AudioIODevice* device) override;
    void audioDeviceStopped() override;
    void timerCallback() override;

    rt60::DecayModel model_;
    rt60::MeasurementEngine measurement_;
    rt60::CorrectionEngine correctionEngine_;
    std::array<rt60::CorrectionProfile, 2> correctionProfiles_{};
    std::array<rt60::CorrectionProfile, 2> bestCorrectionProfiles_{};
    std::array<rt60::MeasurementResult, 2> baselineMeasurements_{};
    std::array<rt60::MeasurementResult, 2> latestMeasurements_{};
    std::array<rt60::MeasurementResult, 2> bestVerifiedMeasurements_{};
    std::array<rt60::DecayUniformityReport, 2> bestVerifiedReports_{};
    RT60Graph graph_;
    WaterfallGraph waterfallGraph_;
    std::array<rt60::WaterfallData, 2> beforeWaterfalls_{};
    std::array<rt60::WaterfallData, 2> afterWaterfalls_{};
    std::array<rt60::WaterfallData, 2> bestAfterWaterfalls_{};
    rt60::DisplaySnapshot displaySnapshot_{};
    rt60::ProfileMetadata loadedMetadata_{};

    // Three slots allow the message thread to build a complete replacement
    // while the audio thread owns the active slot. The audio callback only
    // swaps integer indices at a block boundary: no lock, allocation or
    // vector mutation occurs in the real-time thread.
    std::array<CorrectionBanks, 3> correctionBankSlots_{};
    std::atomic<int> activeBankIndex_{0};
    std::atomic<int> pendingBankIndex_{-1};

    // Two measurement slots eliminate the excitation_/capture_ reallocation
    // race. A slot is prepared completely before measuring_ is published.
    std::array<MeasurementBuffers, 2> measurementBuffers_{};
    std::atomic<int> activeMeasurementBuffer_{0};

    juce::AudioDeviceManager deviceManager_;
    juce::AudioDeviceSelectorComponent deviceSelector_;

    juce::Slider targetSlider_;
    juce::Slider strengthSlider_;
    juce::Slider maxCutSlider_;
    juce::Slider sweepLevelSlider_;
    juce::ComboBox micInputSelector_;
    juce::ComboBox graphChannelSelector_;
    juce::ComboBox waterfallChannelSelector_;
    juce::ComboBox waterfallStateSelector_;
    juce::Label title_;
    juce::Label targetLabel_, strengthLabel_, maxCutLabel_, sweepLevelLabel_, micInputLabel_, graphViewLabel_, waterfallLabel_, status_;
    juce::Label improvementLabel_, qualityLabel_, filterInspectorLabel_;
    juce::TextEditor filterInspector_;
    juce::TextButton demoButton_{"LOAD DEMO"};
    juce::TextButton loadProfileButton_{"LOAD PROFILE..."};
    juce::TextButton measureButton_{"MEASURE L + R"};
    juce::TextButton autoCorrectButton_{"AUTO CORRECT RT60"};
    juce::TextButton remeasureButton_{"RE-MEASURE L + R"};
    juce::TextButton saveProfileButton_{"SAVE PROFILE AS..."};
    juce::ToggleButton correctionToggle_{"CORRECTION ACTIVE"};
    juce::ToggleButton autoTargetToggle_{"AUTO TARGET"};
    juce::ToggleButton autoVerifyToggle_{"AUTO VERIFY + AFTER GRAPH"};

    std::unique_ptr<juce::FileChooser> saveProfileChooser_;
    std::unique_ptr<juce::FileChooser> loadProfileChooser_;
    juce::String currentProfileName_;

    std::atomic<std::size_t> measurementPosition_{0};
    std::atomic<bool> measuring_{false};
    std::atomic<bool> measurementFinished_{false};
    std::atomic<bool> measurementClipped_{false};
    std::atomic<bool> measurementIsAfter_{false};
    std::atomic<int> measurementLogicalChannel_{0};
    std::atomic<int> selectedMicInput_{0};
    std::atomic<bool> correctionEnabled_{false};

    bool autoCorrecting_ = false;
    bool haveBestVerifiedPass_ = false;
    bool currentProfileVerified_ = false;
    bool currentProfileUsedFallback_ = false;
    int autoIteration_ = 0;
    int bestVerifiedPass_ = 0;
    float digitalTwinScore_ = 0.0f;
    float baselineObjectiveMs_ = 0.0f;
    float bestObjectiveMs_ = 0.0f;
    juce::String micInputSignature_;
    static constexpr int kMaxAutoIterations = 6;
};
