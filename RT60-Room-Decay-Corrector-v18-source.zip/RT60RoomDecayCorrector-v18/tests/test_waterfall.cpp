#include "core/WaterfallData.hpp"

#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

int main()
{
    constexpr double sampleRate = 48000.0;
    std::vector<float> ir(static_cast<std::size_t>(sampleRate * 2.2), 0.0f);
    ir[200] = 1.0f;
    for (std::size_t i = 200; i < ir.size(); ++i) {
        const double t = static_cast<double>(i - 200) / sampleRate;
        ir[i] += static_cast<float>(0.55 * std::sin(2.0 * 3.141592653589793 * 63.0 * t) * std::exp(-t / 0.28));
        ir[i] += static_cast<float>(0.30 * std::sin(2.0 * 3.141592653589793 * 125.0 * t) * std::exp(-t / 0.16));
    }

    const auto wf = rt60::WaterfallAnalyzer::analyse(ir, sampleRate);
    assert(wf.valid());
    assert(wf.frequenciesHz.front() >= 19.9f);
    assert(wf.frequenciesHz.back() <= 300.1f);
    assert(wf.timesMs.back() >= 999.0f);

    std::size_t closest63 = 0;
    for (std::size_t i = 1; i < wf.frequenciesHz.size(); ++i)
        if (std::abs(wf.frequenciesHz[i] - 63.0f) < std::abs(wf.frequenciesHz[closest63] - 63.0f))
            closest63 = i;
    assert(wf.level(0, closest63) > wf.level(wf.timesMs.size() - 1, closest63));

    const auto encoded = rt60::WaterfallAnalyzer::serialize(wf);
    rt60::WaterfallData decoded;
    assert(rt60::WaterfallAnalyzer::deserialize(encoded, decoded));
    assert(decoded.valid());
    assert(decoded.levelsDb.size() == wf.levelsDb.size());

    rt60::WaterfallData sentinel = decoded;
    assert(!rt60::WaterfallAnalyzer::deserialize(encoded.substr(0, encoded.size() / 2), sentinel));
    assert(sentinel.levelsDb.size() == decoded.levelsDb.size());

    std::cout << "waterfall tests passed\n";
    return 0;
}
