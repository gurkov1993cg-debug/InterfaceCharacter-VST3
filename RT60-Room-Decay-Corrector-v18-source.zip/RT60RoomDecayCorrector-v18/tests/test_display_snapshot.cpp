#include "core/DisplaySnapshot.hpp"

#include <cassert>
#include <cmath>
#include <sstream>
#include <string>

int main()
{
    rt60::DisplaySnapshot source;
    source.beforeMs[0][0] = 640.0f;
    source.beforeValid[0][0] = true;
    source.afterMs[0][0] = 330.0f;
    source.afterValid[0][0] = true;
    source.beforeMs[1][0] = 710.0f;
    source.beforeValid[1][0] = true;
    source.afterMs[1][0] = 390.0f;
    source.afterValid[1][0] = true;
    source.beforeMs[0][8] = 410.0f;
    source.beforeValid[0][8] = true;

    assert(source.hasBefore());
    assert(source.hasAfter());
    assert(source.hasBefore(0));
    assert(source.hasAfter(1));

    float value = 0.0f;
    assert(source.valueBefore(rt60::DisplayChannelView::Left, 0, value) && value == 640.0f);
    assert(source.valueBefore(rt60::DisplayChannelView::Right, 0, value) && value == 710.0f);
    assert(source.valueBefore(rt60::DisplayChannelView::Worst, 0, value) && value == 710.0f);

    const std::string encoded = rt60::DisplaySnapshotCodec::serialize(source);
    rt60::DisplaySnapshot roundTrip;
    assert(rt60::DisplaySnapshotCodec::deserialize(encoded, roundTrip));
    assert(roundTrip.beforeValid[0][0] && roundTrip.afterValid[0][0]);
    assert(roundTrip.beforeValid[1][0] && roundTrip.afterValid[1][0]);
    assert(roundTrip.beforeMs[0][0] == 640.0f);
    assert(roundTrip.beforeMs[1][0] == 710.0f);
    assert(roundTrip.afterMs[1][0] == 390.0f);

    // v1 compatibility: old snapshots stored only WORST. v2 intentionally
    // duplicates that legacy curve into L/R so old bundles remain visible.
    std::ostringstream legacy;
    legacy << "RT60_DISPLAY_SNAPSHOT 1\n";
    for (std::size_t i = 0; i < rt60::kBandCount; ++i)
        legacy << "B " << i << ' ' << (i == 0 ? 700.0f : 0.0f) << ' ' << (i == 0 ? 1 : 0)
               << ' ' << (i == 0 ? 350.0f : 0.0f) << ' ' << (i == 0 ? 1 : 0) << '\n';
    rt60::DisplaySnapshot legacyDecoded;
    assert(rt60::DisplaySnapshotCodec::deserialize(legacy.str(), legacyDecoded));
    assert(legacyDecoded.beforeValid[0][0] && legacyDecoded.beforeValid[1][0]);
    assert(legacyDecoded.beforeMs[0][0] == 700.0f && legacyDecoded.beforeMs[1][0] == 700.0f);

    rt60::DisplaySnapshot sentinel;
    sentinel.beforeMs[0][3] = 777.0f;
    sentinel.beforeValid[0][3] = true;
    const auto truncated = encoded.substr(0, encoded.size() / 2);
    assert(!rt60::DisplaySnapshotCodec::deserialize(truncated, sentinel));
    assert(sentinel.beforeValid[0][3] && sentinel.beforeMs[0][3] == 777.0f);

    return 0;
}
