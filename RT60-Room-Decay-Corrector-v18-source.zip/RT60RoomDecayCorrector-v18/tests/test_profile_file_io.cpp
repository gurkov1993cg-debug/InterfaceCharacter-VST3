#include "core/ProfileBundle.hpp"

#include <cassert>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>

namespace {
rt60::ProfileBundle makeBundle(const std::string& name, float roomMs, float afterMs)
{
    rt60::ProfileBundle b;
    for (int ch = 0; ch < 2; ++ch) {
        b.profiles[ch].targetMs = 300.0f;
        b.profiles[ch].strength = 0.85f;
        b.profiles[ch].autoTarget = true;
        b.profiles[ch].measuredBandMs[8] = roomMs + ch * 15.0f;
        b.profiles[ch].targetBandMs[8] = 300.0f;
        rt60::CorrectionStageSpec stage;
        stage.frequencyHz = 160.0f;
        stage.measuredT60Ms = roomMs + ch * 15.0f;
        stage.desiredT60Ms = 300.0f;
        stage.estimatedQ = 5.5f;
        stage.confidence = 0.92f;
        stage.sourceBand = 8;
        b.profiles[ch].stages.push_back(stage);

        b.beforeMeasurements[ch].sampleRate = 48000.0;
        b.beforeMeasurements[ch].valid = true;
        b.beforeMeasurements[ch].peakDbFs = -18.0f - ch;
        b.beforeMeasurements[ch].bands[8].frequencyHz = 160.0f;
        b.beforeMeasurements[ch].bands[8].rt60Ms = roomMs + ch * 15.0f;
        b.beforeMeasurements[ch].bands[8].confidence = 0.92f;
        b.beforeMeasurements[ch].bands[8].valid = true;

        b.afterMeasurements[ch] = b.beforeMeasurements[ch];
        b.afterMeasurements[ch].bands[8].rt60Ms = afterMs + ch * 10.0f;

        b.display.beforeMs[ch][8] = b.beforeMeasurements[ch].bands[8].rt60Ms;
        b.display.beforeValid[ch][8] = true;
        b.display.afterMs[ch][8] = b.afterMeasurements[ch].bands[8].rt60Ms;
        b.display.afterValid[ch][8] = true;
    }
    b.hasMeasurementDetails = true;
    b.metadata.appMajor = 18;
    b.metadata.appMinor = 0;
    b.metadata.measurementSampleRate = 48000.0;
    b.metadata.targetMs = 300.0f;
    b.metadata.maxCorrectionHz = 300.0f;
    b.metadata.verified = true;
    b.metadata.profileName = name;
    b.metadata.createdUtc = "2026-09-01T12:00:00Z";
    return b;
}

bool writeExact(const std::filesystem::path& path, const std::string& bytes)
{
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    return out.good();
}

std::string readExact(const std::filesystem::path& path)
{
    std::ifstream in(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}
}

int main()
{
    const auto dir = std::filesystem::temp_directory_path() / "rt60_v18_profile_io";
    std::filesystem::create_directories(dir);
    const auto fileA = dir / "Room_A.rt60profile";
    const auto fileB = dir / "Room_B.rt60profile";

    const auto a = makeBundle("Room A", 780.0f, 340.0f);
    const auto b = makeBundle("Room B", 520.0f, 305.0f);
    const auto bytesA = rt60::ProfileBundleCodec::serialize(a);
    const auto bytesB = rt60::ProfileBundleCodec::serialize(b);
    assert(bytesA != bytesB);
    assert(writeExact(fileA, bytesA));
    assert(writeExact(fileB, bytesB));

    rt60::ProfileBundle loadedA, loadedB;
    assert(rt60::ProfileBundleCodec::deserialize(readExact(fileA), loadedA));
    assert(rt60::ProfileBundleCodec::deserialize(readExact(fileB), loadedB));
    assert(loadedA.metadata.profileName == "Room A");
    assert(loadedB.metadata.profileName == "Room B");
    assert(std::abs(loadedA.beforeMeasurements[0].bands[8].rt60Ms - 780.0f) < 0.01f);
    assert(std::abs(loadedB.beforeMeasurements[0].bands[8].rt60Ms - 520.0f) < 0.01f);
    assert(std::abs(loadedA.afterMeasurements[0].bands[8].rt60Ms - 340.0f) < 0.01f);
    assert(std::abs(loadedB.afterMeasurements[0].bands[8].rt60Ms - 305.0f) < 0.01f);
    assert(loadedA.profiles[0].stages.size() == 1);
    assert(loadedB.profiles[1].stages.size() == 1);

    // Same file, one changed byte: the v4 checksum must reject it.
    auto damaged = readExact(fileA);
    const auto pos = damaged.find("780");
    assert(pos != std::string::npos);
    damaged[pos] = '7';
    rt60::ProfileBundle rejected = loadedB;
    assert(!rt60::ProfileBundleCodec::deserialize(damaged, rejected));
    assert(rejected.metadata.profileName == "Room B"); // transactional failure

    std::filesystem::remove_all(dir);
    std::cout << "Profile v4 exact disk I/O and two-room reload tests passed\n";
    return 0;
}
