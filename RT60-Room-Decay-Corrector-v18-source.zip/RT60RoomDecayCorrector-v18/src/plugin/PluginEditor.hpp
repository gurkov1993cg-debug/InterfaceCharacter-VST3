#pragma once

#include <juce_gui_extra/juce_gui_extra.h>
#include "plugin/PluginProcessor.hpp"
#include "ui/RT60Graph.hpp"
#include "ui/WaterfallGraph.hpp"

class RT60Editor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit RT60Editor(RT60Processor&);
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void updateStatus();
    void refreshWaterfall();
    void refreshGraphView();
    void refreshImprovement();
    void refreshInspector();
    void refreshRecentProfiles();
    void refreshAll();
    void beginLoadProfile();

    RT60Processor& processor_;
    RT60Graph graph_;
    WaterfallGraph waterfallGraph_;
    juce::Label title_, status_, profileMeta_, graphLabel_, waterfallLabel_, improvementLabel_, inspectorLabel_, recentLabel_;
    juce::ComboBox graphChannelSelector_;
    juce::ComboBox waterfallChannelSelector_;
    juce::ComboBox waterfallStateSelector_;
    juce::ComboBox recentProfileSelector_;
    juce::TextEditor filterInspector_;
    juce::TextButton loadProfileButton_{"LOAD PROFILE..."};
    juce::TextButton reloadButton_{"RELOAD SHARED"};
    juce::TextButton abButton_{"A/B PREVIOUS"};
    juce::TextButton undoButton_{"UNDO LOAD"};
    juce::TextButton bestVerifiedButton_{"BEST VERIFIED"};
    juce::ToggleButton bypassButton_{"BYPASS"};
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<ButtonAttachment> bypassA_;
    std::unique_ptr<juce::FileChooser> loadProfileChooser_;
};
