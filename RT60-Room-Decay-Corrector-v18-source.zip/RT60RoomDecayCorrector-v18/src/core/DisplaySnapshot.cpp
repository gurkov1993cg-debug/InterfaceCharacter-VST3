#include "core/DisplaySnapshot.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

namespace rt60 {
namespace {

bool validMs(float value) noexcept
{
    return std::isfinite(value) && value >= 0.0f && value <= 10000.0f;
}

bool valueForView(const std::array<DisplaySnapshot::FloatBands, 2>& values,
                  const std::array<DisplaySnapshot::BoolBands, 2>& valid,
                  DisplayChannelView view,
                  std::size_t band,
                  float& value) noexcept
{
    if (band >= kBandCount)
        return false;

    if (view == DisplayChannelView::Left || view == DisplayChannelView::Right) {
        const int channel = view == DisplayChannelView::Left ? 0 : 1;
        if (!valid[static_cast<std::size_t>(channel)][band])
            return false;
        value = values[static_cast<std::size_t>(channel)][band];
        return true;
    }

    bool any = false;
    float worst = 0.0f;
    for (int channel = 0; channel < 2; ++channel) {
        if (valid[static_cast<std::size_t>(channel)][band]) {
            worst = any ? std::max(worst, values[static_cast<std::size_t>(channel)][band])
                        : values[static_cast<std::size_t>(channel)][band];
            any = true;
        }
    }
    if (any)
        value = worst;
    return any;
}

bool parseV1(std::istringstream& in, DisplaySnapshot& snapshot)
{
    DisplaySnapshot parsed;
    std::array<bool, kBandCount> seen{};
    for (std::size_t row = 0; row < kBandCount; ++row) {
        char tag = 0;
        std::size_t index = 0;
        float before = 0.0f;
        int beforeValid = 0;
        float after = 0.0f;
        int afterValid = 0;
        if (!(in >> tag >> index >> before >> beforeValid >> after >> afterValid)
            || tag != 'B' || index >= kBandCount || seen[index]
            || (beforeValid != 0 && beforeValid != 1)
            || (afterValid != 0 && afterValid != 1)
            || !validMs(before) || !validMs(after))
            return false;
        seen[index] = true;

        // v1 stored only the WORST channel. Duplicate it into L/R so old
        // profile bundles remain visually useful while v2 keeps real stereo.
        for (int channel = 0; channel < 2; ++channel) {
            parsed.beforeMs[static_cast<std::size_t>(channel)][index] = before;
            parsed.beforeValid[static_cast<std::size_t>(channel)][index] = beforeValid != 0;
            parsed.afterMs[static_cast<std::size_t>(channel)][index] = after;
            parsed.afterValid[static_cast<std::size_t>(channel)][index] = afterValid != 0;
        }
    }

    for (bool value : seen)
        if (!value)
            return false;

    std::string trailing;
    if (in >> trailing)
        return false;

    snapshot = parsed;
    return true;
}

} // namespace

bool DisplaySnapshot::hasBefore() const noexcept
{
    return hasBefore(0) || hasBefore(1);
}

bool DisplaySnapshot::hasAfter() const noexcept
{
    return hasAfter(0) || hasAfter(1);
}

bool DisplaySnapshot::hasBefore(int channel) const noexcept
{
    if (channel < 0 || channel > 1)
        return false;
    for (bool valid : beforeValid[static_cast<std::size_t>(channel)])
        if (valid)
            return true;
    return false;
}

bool DisplaySnapshot::hasAfter(int channel) const noexcept
{
    if (channel < 0 || channel > 1)
        return false;
    for (bool valid : afterValid[static_cast<std::size_t>(channel)])
        if (valid)
            return true;
    return false;
}

bool DisplaySnapshot::valueBefore(DisplayChannelView view, std::size_t band, float& value) const noexcept
{
    return valueForView(beforeMs, beforeValid, view, band, value);
}

bool DisplaySnapshot::valueAfter(DisplayChannelView view, std::size_t band, float& value) const noexcept
{
    return valueForView(afterMs, afterValid, view, band, value);
}

std::string DisplaySnapshotCodec::serialize(const DisplaySnapshot& snapshot)
{
    std::ostringstream out;
    out << "RT60_DISPLAY_SNAPSHOT " << DisplaySnapshot::kFormatVersion << '\n';
    out << std::setprecision(9);
    for (int channel = 0; channel < 2; ++channel) {
        const char side = channel == 0 ? 'L' : 'R';
        for (std::size_t i = 0; i < kBandCount; ++i) {
            out << side << ' ' << i << ' '
                << snapshot.beforeMs[static_cast<std::size_t>(channel)][i] << ' '
                << (snapshot.beforeValid[static_cast<std::size_t>(channel)][i] ? 1 : 0) << ' '
                << snapshot.afterMs[static_cast<std::size_t>(channel)][i] << ' '
                << (snapshot.afterValid[static_cast<std::size_t>(channel)][i] ? 1 : 0) << '\n';
        }
    }
    return out.str();
}

bool DisplaySnapshotCodec::deserialize(const std::string& text, DisplaySnapshot& snapshot)
{
    std::istringstream in(text);
    std::string magic;
    int version = 0;
    if (!(in >> magic >> version) || magic != "RT60_DISPLAY_SNAPSHOT")
        return false;

    if (version == 1)
        return parseV1(in, snapshot);
    if (version != DisplaySnapshot::kFormatVersion)
        return false;

    DisplaySnapshot parsed;
    std::array<std::array<bool, kBandCount>, 2> seen{};
    for (std::size_t row = 0; row < kBandCount * 2; ++row) {
        char side = 0;
        std::size_t index = 0;
        float before = 0.0f;
        int beforeValid = 0;
        float after = 0.0f;
        int afterValid = 0;
        if (!(in >> side >> index >> before >> beforeValid >> after >> afterValid)
            || (side != 'L' && side != 'R') || index >= kBandCount
            || (beforeValid != 0 && beforeValid != 1)
            || (afterValid != 0 && afterValid != 1)
            || !validMs(before) || !validMs(after))
            return false;

        const int channel = side == 'L' ? 0 : 1;
        if (seen[static_cast<std::size_t>(channel)][index])
            return false;
        seen[static_cast<std::size_t>(channel)][index] = true;
        parsed.beforeMs[static_cast<std::size_t>(channel)][index] = before;
        parsed.beforeValid[static_cast<std::size_t>(channel)][index] = beforeValid != 0;
        parsed.afterMs[static_cast<std::size_t>(channel)][index] = after;
        parsed.afterValid[static_cast<std::size_t>(channel)][index] = afterValid != 0;
    }

    for (const auto& channelSeen : seen)
        for (bool value : channelSeen)
            if (!value)
                return false;

    std::string trailing;
    if (in >> trailing)
        return false;

    snapshot = parsed;
    return true;
}

} // namespace rt60
