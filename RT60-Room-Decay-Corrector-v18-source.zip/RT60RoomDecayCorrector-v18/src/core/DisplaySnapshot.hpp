#pragma once

#include "core/DecayModel.hpp"

#include <array>
#include <string>

namespace rt60 {

enum class DisplayChannelView : int {
    Left = 0,
    Right = 1,
    Worst = 2
};

struct DisplaySnapshot {
    static constexpr int kFormatVersion = 2;
    using FloatBands = std::array<float, kBandCount>;
    using BoolBands = std::array<bool, kBandCount>;

    std::array<FloatBands, 2> beforeMs{};
    std::array<BoolBands, 2> beforeValid{};
    std::array<FloatBands, 2> afterMs{};
    std::array<BoolBands, 2> afterValid{};

    bool hasBefore() const noexcept;
    bool hasAfter() const noexcept;
    bool hasBefore(int channel) const noexcept;
    bool hasAfter(int channel) const noexcept;

    bool valueBefore(DisplayChannelView view, std::size_t band, float& value) const noexcept;
    bool valueAfter(DisplayChannelView view, std::size_t band, float& value) const noexcept;
};

class DisplaySnapshotCodec {
public:
    static std::string serialize(const DisplaySnapshot& snapshot);
    static bool deserialize(const std::string& text, DisplaySnapshot& snapshot);
};

} // namespace rt60
