#pragma once

#include "core/CorrectionEngine.hpp"
#include "core/MeasurementEngine.hpp"
#include "core/DisplaySnapshot.hpp"
#include "core/WaterfallData.hpp"

#include <array>
#include <string>

namespace rt60 {

struct ProfileMetadata {
    int appMajor = 0;
    int appMinor = 0;
    double measurementSampleRate = 0.0;
    float targetMs = 0.0f;
    float maxCorrectionHz = 0.0f;
    bool verified = false;
    bool usedFallback = false;
    bool legacyBundle = false;
    std::string createdUtc;
    std::string profileName;
};

struct ProfileBundle {
    static constexpr int kFormatVersion = 4;
    std::array<CorrectionProfile, 2> profiles{};
    // v3 stores the analysed measurement state as well as the display curves.
    // The impulse-response vectors are intentionally not serialized, only the
    // per-band analysis/quality summary needed to restore the UI faithfully.
    std::array<MeasurementResult, 2> beforeMeasurements{};
    std::array<MeasurementResult, 2> afterMeasurements{};
    std::array<WaterfallData, 2> beforeWaterfalls{};
    std::array<WaterfallData, 2> afterWaterfalls{};
    DisplaySnapshot display{};
    ProfileMetadata metadata{};
    bool hasMeasurementDetails = false;

    bool hasCorrection() const noexcept
    {
        return !profiles[0].empty() || !profiles[1].empty();
    }
};

class ProfileBundleCodec {
public:
    static std::string serialize(const ProfileBundle& bundle);
    static bool deserialize(const std::string& text, ProfileBundle& bundle);
};

} // namespace rt60
