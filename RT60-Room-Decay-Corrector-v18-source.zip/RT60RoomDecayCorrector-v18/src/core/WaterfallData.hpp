#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace rt60 {

struct WaterfallConfig {
    float minHz = 20.0f;
    float maxHz = 300.0f;
    float maxTimeMs = 1000.0f;
    float timeStepMs = 20.0f;
    int frequencyPoints = 96;
    std::size_t fftSize = 8192;
    float floorDb = -80.0f;
};

struct WaterfallData {
    double sampleRate = 48000.0;
    float floorDb = -80.0f;
    std::vector<float> frequenciesHz;
    std::vector<float> timesMs;
    // Row-major: time slice first, then frequency point.
    std::vector<float> levelsDb;

    bool valid() const noexcept
    {
        return sampleRate > 0.0 && !frequenciesHz.empty() && !timesMs.empty()
            && levelsDb.size() == frequenciesHz.size() * timesMs.size();
    }

    float level(std::size_t timeIndex, std::size_t frequencyIndex) const noexcept
    {
        if (!valid() || timeIndex >= timesMs.size() || frequencyIndex >= frequenciesHz.size())
            return floorDb;
        return levelsDb[timeIndex * frequenciesHz.size() + frequencyIndex];
    }
};

class WaterfallAnalyzer {
public:
    static WaterfallData analyse(const std::vector<float>& impulseResponse,
                                 double sampleRate,
                                 const WaterfallConfig& config = {});
    static std::string serialize(const WaterfallData& data);
    static bool deserialize(const std::string& text, WaterfallData& data);
};

} // namespace rt60
