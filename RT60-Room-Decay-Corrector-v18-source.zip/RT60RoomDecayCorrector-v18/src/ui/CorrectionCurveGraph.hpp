#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "core/CorrectionEngine.hpp"

#include <array>

class CorrectionCurveGraph final : public juce::Component {
public:
    void setProfiles(const std::array<rt60::CorrectionProfile, 2>* profiles) noexcept
    {
        profiles_ = profiles;
        repaint();
    }

    void setSampleRate(double sampleRate) noexcept
    {
        sampleRate_ = sampleRate > 1000.0 ? sampleRate : 48000.0;
        repaint();
    }

    void paint(juce::Graphics&) override;

private:
    float xForFrequency(float hz, juce::Rectangle<float> area) const;
    float yForDb(float db, juce::Rectangle<float> area) const;

    const std::array<rt60::CorrectionProfile, 2>* profiles_ = nullptr;
    double sampleRate_ = 48000.0;
};
