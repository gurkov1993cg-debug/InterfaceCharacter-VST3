#include "ui/CorrectionCurveGraph.hpp"

#include <algorithm>
#include <array>
#include <cmath>

float CorrectionCurveGraph::xForFrequency(float hz, juce::Rectangle<float> area) const
{
    const float minLog = std::log10(20.0f);
    const float maxLog = std::log10(20000.0f);
    const float x = (std::log10(juce::jlimit(20.0f, 20000.0f, hz)) - minLog) / (maxLog - minLog);
    return area.getX() + x * area.getWidth();
}

float CorrectionCurveGraph::yForDb(float db, juce::Rectangle<float> area) const
{
    const float clamped = juce::jlimit(-12.0f, 12.0f, db);
    return juce::jmap(clamped, -12.0f, 12.0f, area.getBottom(), area.getY());
}

void CorrectionCurveGraph::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(15, 18, 22));
    auto area = getLocalBounds().toFloat().reduced(50.0f, 36.0f);
    area.setY(area.getY() + 8.0f);
    area.setHeight(area.getHeight() - 8.0f);

    g.setFont(13.0f);
    g.setColour(juce::Colour::fromRGB(56, 62, 70));
    for (float db : {-12.0f, -6.0f, 0.0f, 6.0f, 12.0f}) {
        const auto y = yForDb(db, area);
        g.drawHorizontalLine(static_cast<int>(y), area.getX(), area.getRight());
        g.setColour(juce::Colours::lightgrey.withAlpha(0.9f));
        g.drawText(juce::String(static_cast<int>(db)), 4, static_cast<int>(y) - 9, 38, 18,
                   juce::Justification::centredRight);
        g.setColour(juce::Colour::fromRGB(56, 62, 70));
    }

    for (float hz : {20.0f, 50.0f, 100.0f, 200.0f, 500.0f, 1000.0f, 2000.0f, 5000.0f, 10000.0f, 20000.0f}) {
        const auto x = xForFrequency(hz, area);
        g.drawVerticalLine(static_cast<int>(x), area.getY(), area.getBottom());
        g.setColour(juce::Colours::lightgrey.withAlpha(0.9f));
        const auto label = hz >= 1000.0f ? juce::String(hz / 1000.0f, hz == 1000.0f ? 0 : 1) + "k"
                                        : juce::String(static_cast<int>(hz));
        g.drawText(label, static_cast<int>(x) - 21, static_cast<int>(area.getBottom()) + 4, 42, 18,
                   juce::Justification::centred);
        g.setColour(juce::Colour::fromRGB(56, 62, 70));
    }

    const auto zeroY = yForDb(0.0f, area);
    g.setColour(juce::Colour::fromRGB(70, 160, 58).withAlpha(0.35f));
    g.fillRect(juce::Rectangle<float>(area.getX(), zeroY - 1.0f, area.getWidth(), 2.0f));

    if (profiles_ == nullptr || ((*profiles_)[0].empty() && (*profiles_)[1].empty())) {
        g.setColour(juce::Colours::lightgrey.withAlpha(0.7f));
        g.drawText("No correction profile loaded", getLocalBounds().reduced(20), juce::Justification::centred);
        return;
    }

    constexpr int points = 240;
    juce::Path path;
    for (int i = 0; i < points; ++i) {
        const float alpha = static_cast<float>(i) / static_cast<float>(points - 1);
        const float hz = 20.0f * std::pow(1000.0f, alpha);
        float db = 0.0f;
        int contributors = 0;
        for (int channel = 0; channel < 2; ++channel) {
            const auto& profile = (*profiles_)[static_cast<std::size_t>(channel)];
            if (!profile.empty()) {
                db += rt60::CorrectionEngine::profileMagnitudeDbAt(profile, sampleRate_, hz);
                ++contributors;
            }
        }
        if (contributors > 0)
            db /= static_cast<float>(contributors);
        const auto x = xForFrequency(hz, area);
        const auto y = yForDb(db, area);
        if (i == 0) path.startNewSubPath(x, y);
        else path.lineTo(x, y);
    }

    g.setColour(juce::Colour::fromRGB(98, 195, 57));
    g.strokePath(path, juce::PathStrokeType(2.5f));
}
