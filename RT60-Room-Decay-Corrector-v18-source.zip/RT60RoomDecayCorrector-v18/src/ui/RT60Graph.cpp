#include "ui/RT60Graph.hpp"

#include <cmath>

float RT60Graph::xForFrequency(float hz, juce::Rectangle<float> area) const
{
    const float minLog = std::log10(20.0f);
    const float maxLog = std::log10(20000.0f);
    return area.getX() + area.getWidth() * (std::log10(hz) - minLog) / (maxLog - minLog);
}

float RT60Graph::yForMs(float ms, juce::Rectangle<float> area) const
{
    const float clamped = juce::jlimit(100.0f, 10000.0f, ms);
    const float norm = (std::log10(clamped) - 2.0f) / 2.0f;
    return area.getBottom() - norm * area.getHeight();
}

bool RT60Graph::displayedValue(int kind, std::size_t bandIndex, float& value) const noexcept
{
    if (model_ == nullptr || bandIndex >= model_->bands().size())
        return false;

    const auto& band = model_->bands()[bandIndex];
    if (snapshot_ != nullptr) {
        if (kind == 0)
            return snapshot_->hasBefore() && snapshot_->valueBefore(view_, bandIndex, value);
        if (kind == 3)
            return snapshot_->hasAfter() && snapshot_->valueAfter(view_, bandIndex, value);
        // A model estimate is meaningful only after a real/demo BEFORE curve
        // exists. This prevents NEW MEASUREMENT from showing stale old-room data.
        if (kind == 2 && !snapshot_->hasBefore())
            return false;
    }

    if (kind == 0) {
        value = band.measuredMs;
        return true;
    }
    if (kind == 1) {
        value = band.targetMs;
        return true;
    }
    if (kind == 2) {
        value = band.predictedMs;
        return true;
    }
    if (kind == 3 && band.hasMeasuredAfter) {
        value = band.measuredAfterMs;
        return true;
    }
    return false;
}

const char* RT60Graph::viewName() const noexcept
{
    switch (view_) {
        case rt60::DisplayChannelView::Left: return "LEFT";
        case rt60::DisplayChannelView::Right: return "RIGHT";
        case rt60::DisplayChannelView::Worst: return "WORST";
    }
    return "WORST";
}

void RT60Graph::drawCurve(juce::Graphics& g, juce::Rectangle<float> area, int kind, float thickness)
{
    if (model_ == nullptr) return;
    juce::Path p;
    bool first = true;
    for (std::size_t i = 0; i < model_->bands().size(); ++i) {
        float value = 0.0f;
        if (!displayedValue(kind, i, value)) {
            first = true;
            continue;
        }
        const auto x = xForFrequency(model_->bands()[i].frequencyHz, area);
        const auto y = yForMs(value, area);
        if (first) { p.startNewSubPath(x, y); first = false; }
        else p.lineTo(x, y);
    }
    g.strokePath(p, juce::PathStrokeType(thickness));
}

void RT60Graph::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(15, 18, 22));
    auto area = getLocalBounds().toFloat().reduced(58.0f, 38.0f);
    area.setY(area.getY() + 4.0f);
    area.setHeight(area.getHeight() - 2.0f);

    const juce::Colour grid = juce::Colour::fromRGB(48, 53, 58);
    for (float ms : {100.0f, 200.0f, 500.0f, 1000.0f, 2000.0f, 5000.0f, 10000.0f}) {
        const float y = yForMs(ms, area);
        g.setColour(grid);
        g.drawHorizontalLine(static_cast<int>(y), area.getX(), area.getRight());
        if (ms == 100.0f || ms == 1000.0f || ms == 10000.0f) {
            g.setColour(juce::Colours::lightgrey);
            const auto label = juce::String(ms / 1000.0f, ms == 100.0f ? 2 : 1);
            g.drawText(label, 4, static_cast<int>(y) - 9, 46, 18, juce::Justification::centredRight);
        }
    }

    for (float hz : {20.0f, 50.0f, 100.0f, 200.0f, 500.0f, 1000.0f, 2000.0f, 5000.0f, 10000.0f, 20000.0f}) {
        const float x = xForFrequency(hz, area);
        g.setColour(grid);
        g.drawVerticalLine(static_cast<int>(x), area.getY(), area.getBottom());
        g.setColour(juce::Colours::lightgrey);
        const auto label = hz >= 1000.0f ? juce::String(hz / 1000.0f, hz == 1000.0f ? 0 : 1) + "k"
                                        : juce::String(static_cast<int>(hz));
        g.drawText(label, static_cast<int>(x) - 22, static_cast<int>(area.getBottom()) + 5, 44, 18,
                   juce::Justification::centred);
    }
    g.setColour(juce::Colours::lightgrey);
    g.drawText("Hz", static_cast<int>(area.getRight()) - 12, static_cast<int>(area.getBottom()) + 5, 30, 18,
               juce::Justification::centredRight);

    g.setColour(juce::Colour::fromRGB(245, 65, 60));
    drawCurve(g, area, 0, 2.5f); // BEFORE
    g.setColour(juce::Colour::fromRGB(100, 200, 62));
    drawCurve(g, area, 1, 2.2f); // TARGET
    g.setColour(juce::Colour::fromRGB(65, 145, 235));
    drawCurve(g, area, 3, 2.5f); // AFTER

    g.setFont(juce::FontOptions(14.0f, juce::Font::bold));
    g.setColour(juce::Colours::white);
    g.drawText("RT60 DECAY TIME (s)", 48, 7, 210, 22, juce::Justification::left);
    g.setFont(juce::FontOptions(13.0f));
    g.setColour(juce::Colour::fromRGB(245, 65, 60));
    g.drawText("—  BEFORE", 380, 7, 100, 22, juce::Justification::left);
    g.setColour(juce::Colour::fromRGB(100, 200, 62));
    g.drawText("- -  TARGET", 490, 7, 105, 22, juce::Justification::left);
    g.setColour(juce::Colour::fromRGB(65, 145, 235));
    g.drawText("—  AFTER", 605, 7, 95, 22, juce::Justification::left);
}
