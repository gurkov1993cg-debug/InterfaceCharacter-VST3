#include "ui/WaterfallGraph.hpp"

#include <algorithm>
#include <array>
#include <cmath>

float WaterfallGraph::xForFrequency(float hz, juce::Rectangle<float> area) const
{
    if (data_ == nullptr || data_->frequenciesHz.empty())
        return area.getX();
    const float minHz = data_->frequenciesHz.front();
    const float maxHz = data_->frequenciesHz.back();
    const float alpha = (std::log10(hz) - std::log10(minHz)) / (std::log10(maxHz) - std::log10(minHz));
    return area.getX() + juce::jlimit(0.0f, 1.0f, alpha) * area.getWidth();
}

void WaterfallGraph::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(17, 20, 25));
    g.setFont(14.0f);
    g.setColour(juce::Colours::white.withAlpha(0.9f));
    g.drawText(caption_, 12, 6, getWidth() - 24, 22, juce::Justification::centredLeft);

    if (data_ == nullptr || !data_->valid()) {
        g.setColour(juce::Colours::lightgrey.withAlpha(0.75f));
        g.drawText("No measured waterfall data yet", getLocalBounds().reduced(20), juce::Justification::centred);
        return;
    }

    auto plot = getLocalBounds().toFloat().reduced(54.0f, 36.0f);
    plot.setY(plot.getY() + 12.0f);
    plot.setHeight(plot.getHeight() - 10.0f);

    const float depthX = std::min(120.0f, plot.getWidth() * 0.20f);
    const float depthY = std::min(80.0f, plot.getHeight() * 0.24f);
    auto front = plot.withTrimmedRight(depthX).withTrimmedTop(depthY);
    const float levelHeight = front.getHeight() * 0.88f;
    const float floorDb = data_->floorDb;
    const float maxTime = std::max(1.0f, data_->timesMs.back());

    g.setColour(juce::Colour::fromRGB(55, 62, 72));
    for (float db : {0.0f, -20.0f, -40.0f, -60.0f, -80.0f}) {
        if (db < floorDb) continue;
        const float norm = (db - floorDb) / (0.0f - floorDb);
        const float y = front.getBottom() - norm * levelHeight;
        g.drawHorizontalLine(static_cast<int>(y), front.getX(), front.getRight());
        g.setColour(juce::Colours::lightgrey);
        g.drawText(juce::String(static_cast<int>(db)) + " dB", 2, static_cast<int>(y) - 9, 48, 18,
                   juce::Justification::centredRight);
        g.setColour(juce::Colour::fromRGB(55, 62, 72));
    }

    const std::array<float, 8> ticks{{20.0f, 30.0f, 40.0f, 60.0f, 80.0f, 120.0f, 200.0f, 300.0f}};
    for (float hz : ticks) {
        if (hz < data_->frequenciesHz.front() || hz > data_->frequenciesHz.back()) continue;
        const float x = xForFrequency(hz, front);
        g.setColour(juce::Colour::fromRGB(55, 62, 72));
        g.drawVerticalLine(static_cast<int>(x), front.getY(), front.getBottom());
        g.setColour(juce::Colours::lightgrey);
        g.drawText(juce::String(static_cast<int>(hz)), static_cast<int>(x) - 20,
                   static_cast<int>(front.getBottom()) + 5, 40, 18, juce::Justification::centred);
    }
    g.setColour(juce::Colours::lightgrey);
    g.drawText("Hz", static_cast<int>(front.getRight()) - 24, static_cast<int>(front.getBottom()) + 5,
               24, 18, juce::Justification::centredRight);

    // Draw late slices first so early/high-energy ridges remain readable.
    for (std::size_t reverse = data_->timesMs.size(); reverse-- > 0;) {
        const std::size_t t = reverse;
        const float timeNorm = data_->timesMs[t] / maxTime;
        const float dx = depthX * timeNorm;
        const float dy = depthY * timeNorm;
        juce::Path path;
        bool first = true;
        for (std::size_t f = 0; f < data_->frequenciesHz.size(); ++f) {
            const float db = juce::jlimit(floorDb, 0.0f, data_->level(t, f));
            const float norm = (db - floorDb) / (0.0f - floorDb);
            const float x = xForFrequency(data_->frequenciesHz[f], front) + dx;
            const float y = front.getBottom() - dy - norm * levelHeight;
            if (first) { path.startNewSubPath(x, y); first = false; }
            else path.lineTo(x, y);
        }
        const float alpha = 0.22f + 0.70f * (1.0f - timeNorm);
        g.setColour(juce::Colour::fromRGB(80, 210, 245).withAlpha(alpha));
        g.strokePath(path, juce::PathStrokeType(t == 0 ? 2.0f : 1.0f));
    }

    g.setColour(juce::Colours::lightgrey.withAlpha(0.85f));
    for (float tMs : {0.0f, 250.0f, 500.0f, 750.0f, 1000.0f}) {
        if (tMs > maxTime + 1.0f) continue;
        const float n = tMs / maxTime;
        const float x = front.getRight() + depthX * n;
        const float y = front.getBottom() - depthY * n;
        g.drawLine(front.getRight(), front.getBottom(), front.getRight() + depthX, front.getBottom() - depthY, 1.0f);
        g.drawText(juce::String(static_cast<int>(tMs)) + " ms", static_cast<int>(x) - 20,
                   static_cast<int>(y) - 9, 58, 18, juce::Justification::centredLeft);
    }
}
