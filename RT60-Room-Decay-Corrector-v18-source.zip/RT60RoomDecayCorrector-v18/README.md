# RT60 Room Decay Corrector v18

v18 locks the standalone interface to the approved dashboard layout and fixes the profile workflow so saved room data can be loaded later in the standalone app and in the VST3.

## Standalone workflow

1. NEW MEASUREMENT
2. MEASURE ROOM L+R
3. AUTO CORRECT + VERIFY
4. SAVE PROFILE AS...
5. LOAD PROFILE...

The dashboard shows RT60 BEFORE / TARGET / AFTER, worst frequency, overall improvement, BEFORE/AFTER waterfalls, the real correction response, audio device, input, sample rate, buffer size, input trim and measurement state.

## Real profile data

`.rt60profile` v4 stores:
- LEFT and RIGHT correction stages
- real BEFORE per-band measurement summaries
- real AFTER per-band measurement summaries
- BEFORE and AFTER display curves
- BEFORE and AFTER waterfalls when available
- sample rate, target, correction range, verification state, profile name and timestamp

v4 adds an end-to-end checksum. Profile bytes are written exactly, then the saved file is read back and parsed before SAVE is reported as successful. The shared VST3 mirror is also written and read-back validated.

Older v1/v2/v3 profile bundles remain loadable. Recoverable v16 CRLF-damaged bundles are canonicalised before parsing.

## VST3

The VST3 LOAD PROFILE button loads the same `.rt60profile` and immediately configures the real stereo correction DSP. v18 also embeds the loaded profile bundle inside the DAW project state, so reopening the Cubase project restores the exact profile that was used in that project.

## Windows ASIO / E-MU

The selected measurement input is chosen inside the audio callback while its hardware input pair remains open. This avoids sparse one-channel ASIO reopens that can be problematic with legacy E-MU/PatchMix drivers. The actual device sample rate is used by sweep generation, capture, analysis and correction.

## Tests

Core regression suite: 9/9 tests, including:
- measurement and correction DSP
- display/waterfall state
- real profile data round-trip
- exact binary file write/read
- two different room profiles remain different after reload
- CRLF recovery
- truncation/corruption rejection
- v4 checksum tamper rejection
