#include "plugin/PluginProcessor.hpp"
#include "plugin/PluginEditor.hpp"

#include <algorithm>
#include <cmath>

namespace {
bool writeExactProfileText(const juce::File& file, const std::string& text)
{
    return file.replaceWithData(text.data(), text.size());
}
}

juce::AudioProcessorValueTreeState::ParameterLayout RT60Processor::createParameters()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> parameters;
    parameters.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));
    return {parameters.begin(), parameters.end()};
}

RT60Processor::RT60Processor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", createParameters())
{
    model_.setDemoRoom();
}

bool RT60Processor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainInputChannelSet() == layouts.getMainOutputChannelSet()
        && (layouts.getMainOutputChannelSet() == juce::AudioChannelSet::mono()
            || layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo());
}

juce::File RT60Processor::profileDirectory()
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("Room Decay Lab")
        .getChildFile("RT60 Room Decay Corrector");
}

juce::File RT60Processor::activeProfileFile(int channel)
{
    return profileDirectory().getChildFile(channel == 0
        ? "active_profile_left.rt60" : "active_profile_right.rt60");
}

juce::File RT60Processor::legacyProfileFile()
{
    return profileDirectory().getChildFile("active_profile.rt60");
}

juce::File RT60Processor::waterfallFile(int channel, bool afterCorrection)
{
    const juce::String side = channel == 0 ? "left" : "right";
    const juce::String phase = afterCorrection ? "after" : "before";
    return profileDirectory().getChildFile("waterfall_" + phase + "_" + side + ".rt60wf");
}

juce::File RT60Processor::displaySnapshotFile()
{
    return profileDirectory().getChildFile("active_display.rt60g");
}

juce::File RT60Processor::activeBundleFile()
{
    return profileDirectory().getChildFile("active_profile_bundle.rt60profile");
}

juce::File RT60Processor::bestVerifiedProfileFile()
{
    return profileDirectory().getChildFile("best_verified.rt60profile");
}

void RT60Processor::applyDisplaySnapshot(const rt60::DisplaySnapshot& snapshot)
{
    displaySnapshot_ = snapshot;
    model_.clearMeasuredAfter();
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float value = 0.0f;
        if (snapshot.valueBefore(rt60::DisplayChannelView::Worst, i, value))
            model_.setMeasured(i, value);
        if (snapshot.valueAfter(rt60::DisplayChannelView::Worst, i, value))
            model_.setMeasuredAfter(i, value);
    }
}

void RT60Processor::loadDisplaySnapshot()
{
    const auto file = displaySnapshotFile();
    if (!file.existsAsFile())
        return;
    rt60::DisplaySnapshot snapshot;
    if (!rt60::DisplaySnapshotCodec::deserialize(file.loadFileAsString().toStdString(), snapshot))
        return;
    applyDisplaySnapshot(snapshot);
}

void RT60Processor::loadWaterfallSnapshots()
{
    beforeWaterfalls_ = {};
    afterWaterfalls_ = {};
    for (int channel = 0; channel < 2; ++channel) {
        for (int phase = 0; phase < 2; ++phase) {
            const bool after = phase == 1;
            const auto file = waterfallFile(channel, after);
            if (!file.existsAsFile())
                continue;
            rt60::WaterfallData parsed;
            if (rt60::WaterfallAnalyzer::deserialize(file.loadFileAsString().toStdString(), parsed)) {
                if (after) afterWaterfalls_[static_cast<std::size_t>(channel)] = std::move(parsed);
                else beforeWaterfalls_[static_cast<std::size_t>(channel)] = std::move(parsed);
            }
        }
    }
}

const rt60::WaterfallData* RT60Processor::waterfall(int channel, bool afterCorrection) const noexcept
{
    if (channel < 0 || channel > 1)
        return nullptr;
    const auto& data = afterCorrection ? afterWaterfalls_[static_cast<std::size_t>(channel)]
                                       : beforeWaterfalls_[static_cast<std::size_t>(channel)];
    return data.valid() ? &data : nullptr;
}

bool RT60Processor::writeActiveMirror(const rt60::ProfileBundle& bundle)
{
    bool ok = profileDirectory().createDirectory().wasOk() || profileDirectory().isDirectory();
    const auto bundleText = rt60::ProfileBundleCodec::serialize(bundle);
    rt60::ProfileBundle roundTrip;
    if (!rt60::ProfileBundleCodec::deserialize(bundleText, roundTrip))
        return false;
    ok = writeExactProfileText(activeBundleFile(), bundleText) && ok;
    if (ok) {
        rt60::ProfileBundle verify;
        ok = rt60::ProfileBundleCodec::deserialize(activeBundleFile().loadFileAsString().toStdString(), verify) && ok;
    }
    if (bundle.metadata.verified) {
        ok = writeExactProfileText(bestVerifiedProfileFile(), bundleText) && ok;
        if (ok) {
            rt60::ProfileBundle verify;
            ok = rt60::ProfileBundleCodec::deserialize(bestVerifiedProfileFile().loadFileAsString().toStdString(), verify) && ok;
        }
    }

    for (int channel = 0; channel < 2; ++channel) {
        const auto encoded = rt60::CorrectionEngine::serialize(bundle.profiles[static_cast<std::size_t>(channel)]);
        ok = activeProfileFile(channel).replaceWithText(juce::String::fromUTF8(encoded.c_str())) && ok;

        const auto& before = bundle.beforeWaterfalls[static_cast<std::size_t>(channel)];
        const auto& after = bundle.afterWaterfalls[static_cast<std::size_t>(channel)];
        if (before.valid()) {
            const auto text = rt60::WaterfallAnalyzer::serialize(before);
            ok = waterfallFile(channel, false).replaceWithText(juce::String::fromUTF8(text.c_str())) && ok;
        } else {
            waterfallFile(channel, false).deleteFile();
        }
        if (after.valid()) {
            const auto text = rt60::WaterfallAnalyzer::serialize(after);
            ok = waterfallFile(channel, true).replaceWithText(juce::String::fromUTF8(text.c_str())) && ok;
        } else {
            waterfallFile(channel, true).deleteFile();
        }
    }

    const auto displayText = rt60::DisplaySnapshotCodec::serialize(bundle.display);
    ok = displaySnapshotFile().replaceWithText(juce::String::fromUTF8(displayText.c_str())) && ok;
    return ok;
}

rt60::ProfileBundle RT60Processor::currentBundle() const
{
    rt60::ProfileBundle bundle;
    bundle.profiles = profiles_;
    bundle.beforeMeasurements = beforeMeasurements_;
    bundle.afterMeasurements = afterMeasurements_;
    bundle.hasMeasurementDetails = true;
    bundle.beforeWaterfalls = beforeWaterfalls_;
    bundle.afterWaterfalls = afterWaterfalls_;
    bundle.display = displaySnapshot_;
    bundle.metadata = metadata_;
    return bundle;
}

void RT60Processor::applyBundle(const rt60::ProfileBundle& bundle, const juce::String& name)
{
    profiles_ = bundle.profiles;
    beforeMeasurements_ = bundle.beforeMeasurements;
    afterMeasurements_ = bundle.afterMeasurements;
    beforeWaterfalls_ = bundle.beforeWaterfalls;
    afterWaterfalls_ = bundle.afterWaterfalls;
    metadata_ = bundle.metadata;
    currentProfileName_ = name.isNotEmpty() ? name : juce::String::fromUTF8(bundle.metadata.profileName.c_str());
    hasProfile_.store(bundle.hasCorrection(), std::memory_order_release);
    applyProfileToModel();
    applyDisplaySnapshot(bundle.display);
    publishBanks();

    profileWarning_.clear();
    if (bundle.metadata.legacyBundle) {
        profileWarning_ = "Legacy profile bundle: limited sample-rate/verification metadata.";
    } else if ((bundle.metadata.appMajor == 0 && bundle.metadata.appMinor > 19)
               || bundle.metadata.appMajor > 19) {
        profileWarning_ = "Profile was created by a newer RT60 app version; verify it before relying on it.";
    } else if (bundle.metadata.measurementSampleRate > 0.0
               && std::abs(bundle.metadata.measurementSampleRate - sampleRate_) > 1.0) {
        profileWarning_ = "Measured @ " + juce::String(bundle.metadata.measurementSampleRate, 0)
                        + " Hz; Cubase is @ " + juce::String(sampleRate_, 0)
                        + " Hz. Filter frequencies are recalculated safely for the current rate.";
    }
}

void RT60Processor::rememberRecent(const juce::File& file)
{
    const auto path = file.getFullPathName();
    recentProfilePaths_.erase(std::remove(recentProfilePaths_.begin(), recentProfilePaths_.end(), path),
                              recentProfilePaths_.end());
    recentProfilePaths_.insert(recentProfilePaths_.begin(), path);
    if (recentProfilePaths_.size() > 5)
        recentProfilePaths_.resize(5);
}

bool RT60Processor::loadProfileBundleFromFile(const juce::File& file)
{
    if (!file.existsAsFile())
        return false;

    rt60::ProfileBundle parsed;
    if (!rt60::ProfileBundleCodec::deserialize(file.loadFileAsString().toStdString(), parsed))
        return false;

    // Keep one complete previous bundle for instant A/B and undo. The parsed
    // candidate is fully validated before the live correction is touched.
    if (hasProfile_.load(std::memory_order_acquire)) {
        previousBundle_ = currentBundle();
        previousProfileName_ = currentProfileName_;
        hasPreviousBundle_ = previousBundle_.hasCorrection();
    }

    applyBundle(parsed, file.getFileNameWithoutExtension());
    rememberRecent(file);
    writeActiveMirror(parsed);
    return parsed.hasCorrection();
}

bool RT60Processor::swapWithPreviousProfile()
{
    if (!hasPreviousBundle_)
        return false;
    auto current = currentBundle();
    const auto currentName = currentProfileName_;
    applyBundle(previousBundle_, previousProfileName_);
    previousBundle_ = std::move(current);
    previousProfileName_ = currentName;
    hasPreviousBundle_ = previousBundle_.hasCorrection();
    writeActiveMirror(currentBundle());
    return true;
}

bool RT60Processor::loadBestVerifiedProfile()
{
    const auto file = bestVerifiedProfileFile();
    if (!file.existsAsFile())
        return false;
    rt60::ProfileBundle parsed;
    if (!rt60::ProfileBundleCodec::deserialize(file.loadFileAsString().toStdString(), parsed)
        || !parsed.metadata.verified)
        return false;

    if (hasProfile_.load(std::memory_order_acquire)) {
        previousBundle_ = currentBundle();
        previousProfileName_ = currentProfileName_;
        hasPreviousBundle_ = previousBundle_.hasCorrection();
    }
    applyBundle(parsed, parsed.metadata.profileName.empty() ? "BEST VERIFIED" : juce::String::fromUTF8(parsed.metadata.profileName.c_str()));
    writeActiveMirror(parsed);
    return true;
}

bool RT60Processor::loadRecentProfile(int index)
{
    if (index < 0 || index >= static_cast<int>(recentProfilePaths_.size()))
        return false;
    return loadProfileBundleFromFile(juce::File(recentProfilePaths_[static_cast<std::size_t>(index)]));
}

void RT60Processor::applyProfileToModel()
{
    const auto& reference = !profiles_[0].empty() ? profiles_[0] : profiles_[1];
    if (reference.empty())
        return;

    model_.setStrength(reference.strength);
    model_.setMaxCutDb(18.0f);
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float measured = 0.0f;
        float target = 0.0f;
        for (int channel = 0; channel < 2; ++channel) {
            measured = std::max(measured, profiles_[channel].measuredBandMs[i]);
            target = std::max(target, profiles_[channel].targetBandMs[i]);
        }
        if (measured > 0.0f)
            model_.setMeasured(i, measured);
        if (target > 0.0f)
            model_.setTarget(i, target);
    }
}

void RT60Processor::publishBanks()
{
    const int active = activeBankIndex_.load(std::memory_order_acquire);
    const int pending = pendingBankIndex_.load(std::memory_order_acquire);
    int slot = 0;
    while (slot == active || slot == pending)
        ++slot;
    if (slot >= static_cast<int>(bankSlots_.size()))
        return;

    auto& banks = bankSlots_[static_cast<std::size_t>(slot)];
    banks.left.configure(profiles_[0], sampleRate_);
    banks.right.configure(profiles_[1], sampleRate_);
    pendingBankIndex_.store(slot, std::memory_order_release);
}

bool RT60Processor::reloadActiveProfile()
{
    currentProfileName_.clear();
    profileWarning_.clear();

    const auto bundleFile = activeBundleFile();
    if (bundleFile.existsAsFile()) {
        rt60::ProfileBundle bundle;
        if (rt60::ProfileBundleCodec::deserialize(bundleFile.loadFileAsString().toStdString(), bundle)) {
            applyBundle(bundle, juce::String::fromUTF8(bundle.metadata.profileName.c_str()));
            return bundle.hasCorrection();
        }
        profileWarning_ = "Active bundle is corrupt; trying the legacy stereo mirror.";
    }

    loadWaterfallSnapshots();
    displaySnapshot_ = {};
    model_.clearMeasuredAfter();
    std::array<rt60::CorrectionProfile, 2> loaded{};
    bool gotStereo = false;
    bool valid = true;

    for (int channel = 0; channel < 2; ++channel) {
        const auto file = activeProfileFile(channel);
        if (!file.existsAsFile())
            continue;
        gotStereo = true;
        if (!rt60::CorrectionEngine::deserialize(file.loadFileAsString().toStdString(), loaded[channel]))
            valid = false;
    }

    if (!gotStereo) {
        const auto legacy = legacyProfileFile();
        if (legacy.existsAsFile()) {
            rt60::CorrectionProfile mono;
            if (rt60::CorrectionEngine::deserialize(legacy.loadFileAsString().toStdString(), mono)) {
                loaded[0] = mono;
                loaded[1] = mono;
            } else {
                valid = false;
            }
        }
    }

    if (!valid) {
        profiles_ = {};
        hasProfile_.store(false, std::memory_order_release);
        publishBanks();
        return false;
    }

    profiles_ = std::move(loaded);
    metadata_ = {};
    metadata_.legacyBundle = true;
    const bool active = !profiles_[0].empty() || !profiles_[1].empty();
    hasProfile_.store(active, std::memory_order_release);
    applyProfileToModel();
    loadDisplaySnapshot();
    publishBanks();
    if (active)
        profileWarning_ = "Legacy shared profile: no v0.10 verification/sample-rate metadata.";
    return active;
}

int RT60Processor::activeStageCount() const noexcept
{
    return static_cast<int>(profiles_[0].stages.size() + profiles_[1].stages.size());
}

void RT60Processor::prepareToPlay(double sampleRate, int)
{
    sampleRate_ = sampleRate;
    reloadActiveProfile();
}

void RT60Processor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    if (const int pending = pendingBankIndex_.exchange(-1, std::memory_order_acq_rel); pending >= 0)
        activeBankIndex_.store(pending, std::memory_order_release);

    if (apvts.getRawParameterValue("bypass")->load() > 0.5f
        || !hasProfile_.load(std::memory_order_acquire))
        return;

    auto& banks = bankSlots_[static_cast<std::size_t>(activeBankIndex_.load(std::memory_order_acquire))];
    for (int channel = 0; channel < buffer.getNumChannels(); ++channel) {
        auto* data = buffer.getWritePointer(channel);
        if (channel == 0)
            banks.left.process(data, buffer.getNumSamples());
        else
            banks.right.process(data, buffer.getNumSamples());
    }
}

juce::AudioProcessorEditor* RT60Processor::createEditor()
{
    return new RT60Editor(*this);
}

void RT60Processor::getStateInformation(juce::MemoryBlock& dest)
{
    // v19 stores the actual correction bundle inside the DAW project state.
    // The Cubase session therefore reopens with exactly the profile that was
    // loaded, even if the external .rt60profile file is moved later or another
    // room is made active in the standalone app.
    juce::XmlElement root("RT60_STATE");
    root.setAttribute("version", 18);
    if (auto xml = apvts.copyState().createXml())
        root.addChildElement(xml.release());

    if (hasProfile_.load(std::memory_order_acquire)) {
        const auto encoded = rt60::ProfileBundleCodec::serialize(currentBundle());
        auto* profile = root.createNewChildElement("PROFILE_BUNDLE");
        profile->setAttribute("name", currentProfileName_);
        profile->addTextElement(juce::Base64::toBase64(encoded.data(), encoded.size()));
    }
    copyXmlToBinary(root, dest);
}

void RT60Processor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size)) {
        if (xml->hasTagName("RT60_STATE")) {
            if (auto* stateXml = xml->getChildByName("STATE"))
                apvts.replaceState(juce::ValueTree::fromXml(*stateXml));

            if (auto* profileXml = xml->getChildByName("PROFILE_BUNDLE")) {
                juce::MemoryOutputStream decoded;
                if (juce::Base64::convertFromBase64(decoded, profileXml->getAllSubText())) {
                    const std::string text(static_cast<const char*>(decoded.getData()), decoded.getDataSize());
                    rt60::ProfileBundle bundle;
                    if (rt60::ProfileBundleCodec::deserialize(text, bundle)) {
                        applyBundle(bundle, profileXml->getStringAttribute("name"));
                        writeActiveMirror(bundle);
                        return;
                    }
                }
            }
            reloadActiveProfile();
            return;
        }

        // Compatibility with older plug-in state that contained APVTS XML only.
        apvts.replaceState(juce::ValueTree::fromXml(*xml));
    }
    reloadActiveProfile();
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RT60Processor();
}
