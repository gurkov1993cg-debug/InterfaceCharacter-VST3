#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "core/WaterfallData.hpp"

class WaterfallGraph final : public juce::Component {
public:
    void setData(const rt60::WaterfallData* data) noexcept { data_ = data; repaint(); }
    void setCaption(juce::String caption) { caption_ = std::move(caption); repaint(); }
    void setLevelOffsetDb(float offsetDb) noexcept { levelOffsetDb_ = offsetDb; repaint(); }
    void paint(juce::Graphics& g) override;

private:
    float xForFrequency(float hz, juce::Rectangle<float> area) const;
    const rt60::WaterfallData* data_ = nullptr;
    juce::String caption_{"WATERFALL / DECAY"};
    float levelOffsetDb_ = 0.0f;
};
