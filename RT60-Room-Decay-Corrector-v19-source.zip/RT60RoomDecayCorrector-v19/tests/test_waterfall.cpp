#include "core/WaterfallData.hpp"

#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

int main()
{
    constexpr double sampleRate = 48000.0;
    std::vector<float> ir(static_cast<std::size_t>(sampleRate * 2.2), 0.0f);
    ir[200] = 1.0f;
    for (std::size_t i = 200; i < ir.size(); ++i) {
        const double t = static_cast<double>(i - 200) / sampleRate;
        ir[i] += static_cast<float>(0.55 * std::sin(2.0 * 3.141592653589793 * 63.0 * t) * std::exp(-t / 0.28));
        ir[i] += static_cast<float>(0.30 * std::sin(2.0 * 3.141592653589793 * 125.0 * t) * std::exp(-t / 0.16));
    }

    const auto wf = rt60::WaterfallAnalyzer::analyse(ir, sampleRate);
    assert(wf.valid());
    assert(wf.frequenciesHz.front() >= 19.9f);
    assert(wf.frequenciesHz.back() <= 300.1f);
    assert(wf.timesMs.back() >= 999.0f);

    std::size_t closest63 = 0;
    for (std::size_t i = 1; i < wf.frequenciesHz.size(); ++i)
        if (std::abs(wf.frequenciesHz[i] - 63.0f) < std::abs(wf.frequenciesHz[closest63] - 63.0f))
            closest63 = i;
    assert(wf.level(0, closest63) > wf.level(wf.timesMs.size() - 1, closest63));


    // v19 regression: BEFORE/AFTER are no longer normalized independently
    // for display. Two identical decays at different absolute levels keep the
    // same normalized shape but must expose their real relative level offset.
    auto quieterIr = ir;
    for (auto& v : quieterIr) v *= 0.25f;
    const auto quieter = rt60::WaterfallAnalyzer::analyse(quieterIr, sampleRate);
    assert(quieter.valid());
    const float quieterOffset = rt60::WaterfallAnalyzer::relativeLevelOffsetDb(wf, quieter);
    assert(quieterOffset < -11.5f && quieterOffset > -12.6f);

    // Different decay constants must also produce genuinely different waterfall
    // data, not a copied BEFORE snapshot.
    std::vector<float> fasterIr(static_cast<std::size_t>(sampleRate * 2.2), 0.0f);
    fasterIr[200] = 1.0f;
    for (std::size_t i = 200; i < fasterIr.size(); ++i) {
        const double t = static_cast<double>(i - 200) / sampleRate;
        fasterIr[i] += static_cast<float>(0.55 * std::sin(2.0 * 3.141592653589793 * 63.0 * t) * std::exp(-t / 0.12));
        fasterIr[i] += static_cast<float>(0.30 * std::sin(2.0 * 3.141592653589793 * 125.0 * t) * std::exp(-t / 0.08));
    }
    const auto faster = rt60::WaterfallAnalyzer::analyse(fasterIr, sampleRate);
    assert(faster.valid());
    double waterfallDifference = 0.0;
    for (std::size_t i = 0; i < wf.levelsDb.size(); ++i)
        waterfallDifference += std::abs(static_cast<double>(wf.levelsDb[i] - faster.levelsDb[i]));
    assert(waterfallDifference / static_cast<double>(wf.levelsDb.size()) > 1.0);

    const auto encoded = rt60::WaterfallAnalyzer::serialize(wf);
    rt60::WaterfallData decoded;
    assert(rt60::WaterfallAnalyzer::deserialize(encoded, decoded));
    assert(decoded.valid());
    assert(decoded.levelsDb.size() == wf.levelsDb.size());
    assert(decoded.referenceMagnitude > 0.0f);

    // Legacy v1 waterfall files remain loadable; they simply have no shared
    // absolute reference and therefore use 0 dB comparison offset.
    auto legacy = encoded;
    const auto headerPos = legacy.find("RT60_WATERFALL 2");
    assert(headerPos != std::string::npos);
    legacy.replace(headerPos, std::string("RT60_WATERFALL 2").size(), "RT60_WATERFALL 1");
    const auto refStart = legacy.find("REFERENCE ");
    assert(refStart != std::string::npos);
    const auto refEnd = legacy.find('\n', refStart);
    legacy.erase(refStart, refEnd - refStart + 1);
    rt60::WaterfallData legacyDecoded;
    assert(rt60::WaterfallAnalyzer::deserialize(legacy, legacyDecoded));
    assert(legacyDecoded.referenceMagnitude == 0.0f);

    rt60::WaterfallData sentinel = decoded;
    assert(!rt60::WaterfallAnalyzer::deserialize(encoded.substr(0, encoded.size() / 2), sentinel));
    assert(sentinel.levelsDb.size() == decoded.levelsDb.size());

    std::cout << "waterfall tests passed\n";
    return 0;
}
