#include "core/ProfileBundle.hpp"

#include <cassert>
#include <cmath>
#include <iostream>

int main()
{
    rt60::ProfileBundle source;
    source.profiles[0].targetMs = 220.0f;
    source.profiles[0].strength = 0.82f;
    source.profiles[0].autoTarget = true;
    source.profiles[0].measuredBandMs[3] = 610.0f;
    source.profiles[0].targetBandMs[3] = 220.0f;
    rt60::CorrectionStageSpec stage;
    stage.frequencyHz = 50.0f;
    stage.measuredT60Ms = 610.0f;
    stage.desiredT60Ms = 220.0f;
    stage.estimatedQ = 7.0f;
    stage.confidence = 0.9f;
    stage.sourceBand = 3;
    source.profiles[0].stages.push_back(stage);
    source.profiles[1] = source.profiles[0];
    source.display.beforeMs[0][3] = 610.0f;
    source.display.beforeValid[0][3] = true;
    source.display.afterMs[0][3] = 330.0f;
    source.display.afterValid[0][3] = true;
    source.display.beforeMs[1][3] = 640.0f;
    source.display.beforeValid[1][3] = true;
    source.display.afterMs[1][3] = 350.0f;
    source.display.afterValid[1][3] = true;

    source.beforeMeasurements[0].sampleRate = 48000.0;
    source.beforeMeasurements[0].peakDbFs = -18.5f;
    source.beforeMeasurements[0].valid = true;
    source.beforeMeasurements[0].bands[3].frequencyHz = 50.0f;
    source.beforeMeasurements[0].bands[3].rt60Ms = 610.0f;
    source.beforeMeasurements[0].bands[3].dynamicRangeDb = 42.0f;
    source.beforeMeasurements[0].bands[3].confidence = 0.91f;
    source.beforeMeasurements[0].bands[3].valid = true;
    source.beforeMeasurements[1] = source.beforeMeasurements[0];
    source.beforeMeasurements[1].peakDbFs = -19.0f;
    source.beforeMeasurements[1].bands[3].rt60Ms = 640.0f;

    source.afterMeasurements[0] = source.beforeMeasurements[0];
    source.afterMeasurements[0].peakDbFs = -20.0f;
    source.afterMeasurements[0].bands[3].rt60Ms = 330.0f;
    source.afterMeasurements[1] = source.beforeMeasurements[1];
    source.afterMeasurements[1].peakDbFs = -20.5f;
    source.afterMeasurements[1].bands[3].rt60Ms = 350.0f;
    source.hasMeasurementDetails = true;
    source.metadata.appMajor = 0;
    source.metadata.appMinor = 10;
    source.metadata.measurementSampleRate = 48000.0;
    source.metadata.targetMs = 220.0f;
    source.metadata.maxCorrectionHz = 300.0f;
    source.metadata.verified = true;
    source.metadata.usedFallback = false;
    source.metadata.createdUtc = "2026-08-31T20:00:00Z";
    source.metadata.profileName = "Studio A";

    const auto encoded = rt60::ProfileBundleCodec::serialize(source);
    rt60::ProfileBundle decoded;
    assert(rt60::ProfileBundleCodec::deserialize(encoded, decoded));
    assert(decoded.hasCorrection());
    assert(decoded.profiles[0].stages.size() == 1);
    assert(std::abs(decoded.profiles[0].stages[0].frequencyHz - 50.0f) < 0.01f);
    assert(decoded.display.beforeValid[0][3] && decoded.display.beforeValid[1][3]);
    assert(decoded.display.afterValid[0][3] && decoded.display.afterValid[1][3]);
    assert(std::abs(decoded.display.afterMs[1][3] - 350.0f) < 0.01f);
    assert(decoded.metadata.appMinor == 10);
    assert(decoded.metadata.verified);
    assert(!decoded.metadata.legacyBundle);
    assert(std::abs(decoded.metadata.measurementSampleRate - 48000.0) < 0.01);
    assert(decoded.metadata.profileName == "Studio A");
    assert(decoded.hasMeasurementDetails);
    assert(decoded.beforeMeasurements[0].valid);
    assert(std::abs(decoded.beforeMeasurements[0].peakDbFs + 18.5f) < 0.01f);
    assert(decoded.beforeMeasurements[0].bands[3].valid);
    assert(std::abs(decoded.beforeMeasurements[0].bands[3].dynamicRangeDb - 42.0f) < 0.01f);
    assert(std::abs(decoded.afterMeasurements[1].bands[3].rt60Ms - 350.0f) < 0.01f);

    // Two independently saved room states must remain observably different
    // after a serialize/load round-trip. This guards the profile-switching bug
    // where different files appeared to load the same measurement graph.
    auto sourceB = source;
    sourceB.metadata.profileName = "Studio B";
    sourceB.display.beforeMs[0][3] = 810.0f;
    sourceB.beforeMeasurements[0].bands[3].rt60Ms = 810.0f;
    const auto encodedB = rt60::ProfileBundleCodec::serialize(sourceB);
    rt60::ProfileBundle decodedB;
    assert(rt60::ProfileBundleCodec::deserialize(encodedB, decodedB));
    assert(decodedB.metadata.profileName == "Studio B");
    assert(std::abs(decodedB.display.beforeMs[0][3] - decoded.display.beforeMs[0][3]) > 100.0f);
    assert(std::abs(decodedB.beforeMeasurements[0].bands[3].rt60Ms
                    - decoded.beforeMeasurements[0].bands[3].rt60Ms) > 100.0f);

    rt60::ProfileBundle sentinel = decoded;
    sentinel.profiles[0].targetMs = 777.0f;
    const auto truncated = encoded.substr(0, encoded.size() / 2);
    assert(!rt60::ProfileBundleCodec::deserialize(truncated, sentinel));
    assert(std::abs(sentinel.profiles[0].targetMs - 777.0f) < 0.01f);

    auto corrupt = encoded;
    const auto marker = corrupt.find("LEFT_PROFILE");
    assert(marker != std::string::npos);
    corrupt.replace(marker, 4, "BAD_");
    assert(!rt60::ProfileBundleCodec::deserialize(corrupt, sentinel));
    assert(std::abs(sentinel.profiles[0].targetMs - 777.0f) < 0.01f);

    std::cout << "Profile bundle v3 measurement-state tests passed\n";
    return 0;
}
