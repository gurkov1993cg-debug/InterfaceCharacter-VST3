#include "core/ProfileBundle.hpp"

#include <array>
#include <cmath>
#include <cstddef>
#include <iomanip>
#include <sstream>

namespace rt60 {
namespace {

void appendSection(std::string& out, const char* name, const std::string& payload)
{
    out += name;
    out += ' ';
    out += std::to_string(payload.size());
    out += '\n';
    out += payload;
    out += '\n';
}

bool readSection(const std::string& text,
                 std::size_t& pos,
                 const char* expected,
                 std::string& payload)
{
    const auto eol = text.find('\n', pos);
    if (eol == std::string::npos)
        return false;

    const std::string line = text.substr(pos, eol - pos);
    const std::string prefix = std::string(expected) + " ";
    if (line.rfind(prefix, 0) != 0)
        return false;

    std::size_t length = 0;
    try {
        const auto digits = line.substr(prefix.size());
        std::size_t consumed = 0;
        const auto value = std::stoull(digits, &consumed);
        if (consumed != digits.size())
            return false;
        length = static_cast<std::size_t>(value);
    } catch (...) {
        return false;
    }

    pos = eol + 1;
    if (length > text.size() - pos)
        return false;

    payload.assign(text.data() + pos, length);
    pos += length;
    if (pos >= text.size() || text[pos] != '\n')
        return false;
    ++pos;
    return true;
}

std::string serializeMetadata(const ProfileMetadata& metadata)
{
    std::ostringstream out;
    out << "RT60_PROFILE_META 1\n";
    out << std::setprecision(12);
    out << "APP " << metadata.appMajor << ' ' << metadata.appMinor << '\n';
    out << "SAMPLE_RATE " << metadata.measurementSampleRate << '\n';
    out << "TARGET_MS " << metadata.targetMs << '\n';
    out << "MAX_CORRECTION_HZ " << metadata.maxCorrectionHz << '\n';
    out << "VERIFIED " << (metadata.verified ? 1 : 0) << '\n';
    out << "FALLBACK " << (metadata.usedFallback ? 1 : 0) << '\n';
    out << "CREATED_UTC " << std::quoted(metadata.createdUtc) << '\n';
    out << "PROFILE_NAME " << std::quoted(metadata.profileName) << '\n';
    return out.str();
}

bool deserializeMetadata(const std::string& text, ProfileMetadata& metadata)
{
    std::istringstream in(text);
    std::string magic;
    int version = 0;
    if (!(in >> magic >> version) || magic != "RT60_PROFILE_META" || version != 1)
        return false;

    ProfileMetadata parsed;
    bool sawApp = false, sawRate = false, sawTarget = false, sawMax = false;
    bool sawVerified = false, sawFallback = false, sawCreated = false, sawName = false;
    std::string tag;
    while (in >> tag) {
        if (tag == "APP") {
            if (!(in >> parsed.appMajor >> parsed.appMinor) || parsed.appMajor < 0 || parsed.appMinor < 0)
                return false;
            sawApp = true;
        } else if (tag == "SAMPLE_RATE") {
            if (!(in >> parsed.measurementSampleRate) || !std::isfinite(parsed.measurementSampleRate)
                || parsed.measurementSampleRate < 0.0 || parsed.measurementSampleRate > 768000.0)
                return false;
            sawRate = true;
        } else if (tag == "TARGET_MS") {
            if (!(in >> parsed.targetMs) || !std::isfinite(parsed.targetMs)
                || parsed.targetMs < 0.0f || parsed.targetMs > 10000.0f)
                return false;
            sawTarget = true;
        } else if (tag == "MAX_CORRECTION_HZ") {
            if (!(in >> parsed.maxCorrectionHz) || !std::isfinite(parsed.maxCorrectionHz)
                || parsed.maxCorrectionHz < 0.0f || parsed.maxCorrectionHz > 40000.0f)
                return false;
            sawMax = true;
        } else if (tag == "VERIFIED") {
            int value = -1;
            if (!(in >> value) || (value != 0 && value != 1))
                return false;
            parsed.verified = value != 0;
            sawVerified = true;
        } else if (tag == "FALLBACK") {
            int value = -1;
            if (!(in >> value) || (value != 0 && value != 1))
                return false;
            parsed.usedFallback = value != 0;
            sawFallback = true;
        } else if (tag == "CREATED_UTC") {
            if (!(in >> std::quoted(parsed.createdUtc)))
                return false;
            sawCreated = true;
        } else if (tag == "PROFILE_NAME") {
            if (!(in >> std::quoted(parsed.profileName)))
                return false;
            sawName = true;
        } else {
            std::string rest;
            std::getline(in, rest);
            if (in.bad())
                return false;
        }
    }

    if (!in.eof() || !sawApp || !sawRate || !sawTarget || !sawMax
        || !sawVerified || !sawFallback || !sawCreated || !sawName)
        return false;

    metadata = std::move(parsed);
    return true;
}

std::string serializeMeasurementSummary(const MeasurementResult& result)
{
    std::ostringstream out;
    out << "RT60_MEASUREMENT_SUMMARY 1\n";
    out << std::setprecision(12);
    out << "RESULT " << result.sampleRate << ' ' << result.peakDbFs << ' '
        << (result.clipped ? 1 : 0) << ' ' << (result.valid ? 1 : 0) << '\n';
    for (std::size_t i = 0; i < kBandCount; ++i) {
        const auto& band = result.bands[i];
        out << "B " << i << ' '
            << band.frequencyHz << ' ' << band.edtMs << ' ' << band.t20Ms << ' '
            << band.t30Ms << ' ' << band.rt60Ms << ' ' << band.fitQuality << ' '
            << band.noiseFloorDb << ' ' << band.dynamicRangeDb << ' ' << band.confidence << ' '
            << (band.valid ? 1 : 0) << '\n';
    }
    return out.str();
}

bool deserializeMeasurementSummary(const std::string& text, MeasurementResult& result)
{
    std::istringstream in(text);
    std::string magic;
    int version = 0;
    if (!(in >> magic >> version) || magic != "RT60_MEASUREMENT_SUMMARY" || version != 1)
        return false;

    std::string resultTag;
    int clipped = 0, valid = 0;
    MeasurementResult parsed;
    if (!(in >> resultTag >> parsed.sampleRate >> parsed.peakDbFs >> clipped >> valid)
        || resultTag != "RESULT"
        || !std::isfinite(parsed.sampleRate) || parsed.sampleRate <= 0.0 || parsed.sampleRate > 768000.0
        || !std::isfinite(parsed.peakDbFs) || parsed.peakDbFs < -300.0f || parsed.peakDbFs > 60.0f
        || (clipped != 0 && clipped != 1) || (valid != 0 && valid != 1))
        return false;
    parsed.clipped = clipped != 0;
    parsed.valid = valid != 0;
    parsed.impulseResponse.clear();

    std::array<bool, kBandCount> seen{};
    for (std::size_t row = 0; row < kBandCount; ++row) {
        std::string tag;
        std::size_t index = 0;
        int bandValid = 0;
        BandDecayMetrics band;
        if (!(in >> tag >> index
              >> band.frequencyHz >> band.edtMs >> band.t20Ms >> band.t30Ms >> band.rt60Ms
              >> band.fitQuality >> band.noiseFloorDb >> band.dynamicRangeDb >> band.confidence
              >> bandValid)
            || tag != "B" || index >= kBandCount || seen[index]
            || (bandValid != 0 && bandValid != 1)
            || !std::isfinite(band.frequencyHz) || band.frequencyHz < 0.0f || band.frequencyHz > 100000.0f
            || !std::isfinite(band.edtMs) || band.edtMs < 0.0f || band.edtMs > 100000.0f
            || !std::isfinite(band.t20Ms) || band.t20Ms < 0.0f || band.t20Ms > 100000.0f
            || !std::isfinite(band.t30Ms) || band.t30Ms < 0.0f || band.t30Ms > 100000.0f
            || !std::isfinite(band.rt60Ms) || band.rt60Ms < 0.0f || band.rt60Ms > 100000.0f
            || !std::isfinite(band.fitQuality) || band.fitQuality < -10.0f || band.fitQuality > 10.0f
            || !std::isfinite(band.noiseFloorDb) || band.noiseFloorDb < -300.0f || band.noiseFloorDb > 100.0f
            || !std::isfinite(band.dynamicRangeDb) || band.dynamicRangeDb < -10.0f || band.dynamicRangeDb > 300.0f
            || !std::isfinite(band.confidence) || band.confidence < -0.01f || band.confidence > 1.01f)
            return false;
        band.valid = bandValid != 0;
        parsed.bands[index] = band;
        seen[index] = true;
    }

    for (bool value : seen)
        if (!value)
            return false;

    std::string trailing;
    if (in >> trailing)
        return false;

    result = std::move(parsed);
    return true;
}

bool parsePayloads(const std::array<std::string, 7>& payloads, ProfileBundle& parsed)
{
    if (!CorrectionEngine::deserialize(payloads[0], parsed.profiles[0])
        || !CorrectionEngine::deserialize(payloads[1], parsed.profiles[1]))
        return false;

    for (int channel = 0; channel < 2; ++channel) {
        if (!payloads[2 + channel].empty()
            && !WaterfallAnalyzer::deserialize(payloads[2 + channel], parsed.beforeWaterfalls[channel]))
            return false;
        if (!payloads[4 + channel].empty()
            && !WaterfallAnalyzer::deserialize(payloads[4 + channel], parsed.afterWaterfalls[channel]))
            return false;
    }

    return DisplaySnapshotCodec::deserialize(payloads[6], parsed.display);
}

} // namespace

std::string ProfileBundleCodec::serialize(const ProfileBundle& bundle)
{
    std::string out = "RT60_PROFILE_BUNDLE 3\n";
    appendSection(out, "META", serializeMetadata(bundle.metadata));
    appendSection(out, "LEFT_PROFILE", CorrectionEngine::serialize(bundle.profiles[0]));
    appendSection(out, "RIGHT_PROFILE", CorrectionEngine::serialize(bundle.profiles[1]));
    appendSection(out, "WF_BEFORE_LEFT", bundle.beforeWaterfalls[0].valid()
        ? WaterfallAnalyzer::serialize(bundle.beforeWaterfalls[0]) : std::string{});
    appendSection(out, "WF_BEFORE_RIGHT", bundle.beforeWaterfalls[1].valid()
        ? WaterfallAnalyzer::serialize(bundle.beforeWaterfalls[1]) : std::string{});
    appendSection(out, "WF_AFTER_LEFT", bundle.afterWaterfalls[0].valid()
        ? WaterfallAnalyzer::serialize(bundle.afterWaterfalls[0]) : std::string{});
    appendSection(out, "WF_AFTER_RIGHT", bundle.afterWaterfalls[1].valid()
        ? WaterfallAnalyzer::serialize(bundle.afterWaterfalls[1]) : std::string{});
    appendSection(out, "DISPLAY", DisplaySnapshotCodec::serialize(bundle.display));
    appendSection(out, "MEAS_BEFORE_LEFT", serializeMeasurementSummary(bundle.beforeMeasurements[0]));
    appendSection(out, "MEAS_BEFORE_RIGHT", serializeMeasurementSummary(bundle.beforeMeasurements[1]));
    appendSection(out, "MEAS_AFTER_LEFT", serializeMeasurementSummary(bundle.afterMeasurements[0]));
    appendSection(out, "MEAS_AFTER_RIGHT", serializeMeasurementSummary(bundle.afterMeasurements[1]));
    out += "END\n";
    return out;
}

bool ProfileBundleCodec::deserialize(const std::string& text, ProfileBundle& bundle)
{
    const bool v3 = text.rfind("RT60_PROFILE_BUNDLE 3\n", 0) == 0;
    const bool v2 = text.rfind("RT60_PROFILE_BUNDLE 2\n", 0) == 0;
    const bool v1 = text.rfind("RT60_PROFILE_BUNDLE 1\n", 0) == 0;
    if (!v1 && !v2 && !v3)
        return false;

    const char* header = v3 ? "RT60_PROFILE_BUNDLE 3\n"
        : (v2 ? "RT60_PROFILE_BUNDLE 2\n" : "RT60_PROFILE_BUNDLE 1\n");
    std::size_t pos = std::char_traits<char>::length(header);
    ProfileBundle parsed;

    if (v2 || v3) {
        std::string metadataText;
        if (!readSection(text, pos, "META", metadataText)
            || !deserializeMetadata(metadataText, parsed.metadata))
            return false;
    } else {
        parsed.metadata.legacyBundle = true;
    }

    std::array<std::string, 7> payloads;
    const std::array<const char*, 7> names{{
        "LEFT_PROFILE", "RIGHT_PROFILE",
        "WF_BEFORE_LEFT", "WF_BEFORE_RIGHT",
        "WF_AFTER_LEFT", "WF_AFTER_RIGHT", "DISPLAY"
    }};

    for (std::size_t i = 0; i < names.size(); ++i)
        if (!readSection(text, pos, names[i], payloads[i]))
            return false;

    if (!parsePayloads(payloads, parsed))
        return false;

    if (v3) {
        std::array<std::string, 4> measurementPayloads;
        const std::array<const char*, 4> measurementNames{{
            "MEAS_BEFORE_LEFT", "MEAS_BEFORE_RIGHT",
            "MEAS_AFTER_LEFT", "MEAS_AFTER_RIGHT"
        }};
        for (std::size_t i = 0; i < measurementNames.size(); ++i)
            if (!readSection(text, pos, measurementNames[i], measurementPayloads[i]))
                return false;

        if (!deserializeMeasurementSummary(measurementPayloads[0], parsed.beforeMeasurements[0])
            || !deserializeMeasurementSummary(measurementPayloads[1], parsed.beforeMeasurements[1])
            || !deserializeMeasurementSummary(measurementPayloads[2], parsed.afterMeasurements[0])
            || !deserializeMeasurementSummary(measurementPayloads[3], parsed.afterMeasurements[1]))
            return false;
        parsed.hasMeasurementDetails = true;
    }

    if (text.substr(pos) != "END\n")
        return false;

    // Older releases only supported correction bundles, so keep that contract
    // for compatibility. v3 still expects a correction profile here; the new
    // measurement summaries make profile switching deterministic and complete.
    if (!parsed.hasCorrection())
        return false;

    if (v1) {
        const auto& reference = !parsed.profiles[0].empty() ? parsed.profiles[0] : parsed.profiles[1];
        parsed.metadata.targetMs = reference.targetMs;
    }

    // Transactional commit: the caller keeps its current active bundle when
    // the selected file is truncated, corrupt, or otherwise invalid.
    bundle = std::move(parsed);
    return true;
}

} // namespace rt60
