#include "standalone/MainComponent.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <sstream>

namespace {

int validBandCount(const rt60::MeasurementResult& result)
{
    int count = 0;
    for (const auto& band : result.bands)
        if (band.valid)
            ++count;
    return count;
}

int totalStages(const std::array<rt60::CorrectionProfile, 2>& profiles)
{
    return static_cast<int>(profiles[0].stages.size() + profiles[1].stages.size());
}

const char* speakerName(int channel) noexcept
{
    return channel == 0 ? "LEFT" : "RIGHT";
}

int callbackIndexForPhysicalInput(const juce::BigInteger& activeInputs, int physicalChannel) noexcept
{
    if (physicalChannel < 0 || !activeInputs[physicalChannel])
        return -1;

    int callbackIndex = 0;
    for (int channel = 0; channel < physicalChannel; ++channel)
        if (activeInputs[channel])
            ++callbackIndex;

    return callbackIndex;
}

} // namespace

MainComponent::MainComponent()
    : deviceSelector_(deviceManager_, 1, 32, 2, 2, false, false, true, false)
{
    setSize(1500, 900);
    title_.setText("RT60 ROOM DECAY CORRECTOR v16 - CLEAR RESULTS / ASIO / COREAUDIO", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(24.0f, juce::Font::bold));
    title_.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(title_);

    graph_.setModel(&model_);
    graph_.setDisplaySnapshot(&displaySnapshot_);
    addAndMakeVisible(graph_);
    addAndMakeVisible(waterfallGraph_);
    waterfallGraph_.setCaption("LOW-FREQUENCY DECAY - 20 to 300 Hz");
    addAndMakeVisible(deviceSelector_);

    auto setup = [this](juce::Slider& slider, double min, double max, double step) {
        slider.setRange(min, max, step);
        slider.setSliderStyle(juce::Slider::LinearHorizontal);
        slider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 90, 24);
        addAndMakeVisible(slider);
    };
    setup(targetSlider_, 100.0, 1200.0, 5.0);
    setup(strengthSlider_, 25.0, 100.0, 1.0);
    setup(maxCutSlider_, 100.0, 2000.0, 25.0);
    setup(sweepLevelSlider_, -40.0, -6.0, 1.0);
    setup(inputTrimSlider_, -60.0, 24.0, 0.5);
    targetSlider_.setValue(300.0);
    strengthSlider_.setValue(85.0);
    maxCutSlider_.setValue(300.0); // modal/Schroeder-region safe default
    sweepLevelSlider_.setValue(-18.0);
    inputTrimSlider_.setValue(0.0);
    targetSlider_.setTextValueSuffix(" ms");
    strengthSlider_.setTextValueSuffix(" %");
    maxCutSlider_.setTextValueSuffix(" Hz");
    sweepLevelSlider_.setTextValueSuffix(" dBFS");
    inputTrimSlider_.setTextValueSuffix(" dB");

    inputLevelMeter_.setRange(-60.0, 0.0, 0.1);
    inputLevelMeter_.setSliderStyle(juce::Slider::LinearBar);
    inputLevelMeter_.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    inputLevelMeter_.setValue(-60.0, juce::dontSendNotification);
    inputLevelMeter_.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(inputLevelMeter_);
    inputLevelLabel_.setText("LIVE MIC INPUT", juce::dontSendNotification);
    inputLevelValueLabel_.setText("waiting for input...", juce::dontSendNotification);
    inputLevelValueLabel_.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(inputLevelLabel_);
    addAndMakeVisible(inputLevelValueLabel_);

    targetLabel_.setText("Target decay time", juce::dontSendNotification);
    strengthLabel_.setText("Correction amount", juce::dontSendNotification);
    maxCutLabel_.setText("Correct up to frequency", juce::dontSendNotification);
    sweepLevelLabel_.setText("Test sweep level", juce::dontSendNotification);
    inputTrimLabel_.setText("Mic digital trim", juce::dontSendNotification);
    micInputLabel_.setText("Measurement microphone", juce::dontSendNotification);
    graphViewLabel_.setText("Show room decay", juce::dontSendNotification);
    waterfallLabel_.setText("Low-frequency decay", juce::dontSendNotification);
    filterInspectorLabel_.setText("ADVANCED DETAILS (optional) - correction filter stages", juce::dontSendNotification);
    for (auto* label : {&targetLabel_, &strengthLabel_, &maxCutLabel_, &sweepLevelLabel_, &inputTrimLabel_, &micInputLabel_, &graphViewLabel_, &waterfallLabel_, &filterInspectorLabel_})
        addAndMakeVisible(*label);
    addAndMakeVisible(improvementLabel_);
    addAndMakeVisible(qualityLabel_);
    improvementLabel_.setJustificationType(juce::Justification::centredLeft);
    improvementLabel_.setFont(juce::FontOptions(18.0f, juce::Font::bold));
    improvementLabel_.setColour(juce::Label::backgroundColourId, juce::Colour::fromRGB(26, 31, 37));
    improvementLabel_.setColour(juce::Label::outlineColourId, juce::Colour::fromRGB(70, 82, 94));
    qualityLabel_.setJustificationType(juce::Justification::centredLeft);
    qualityLabel_.setFont(juce::FontOptions(14.0f, juce::Font::bold));
    filterInspector_.setMultiLine(true);
    filterInspector_.setReadOnly(true);
    filterInspector_.setScrollbarsShown(true);
    filterInspector_.setCaretVisible(false);
    addAndMakeVisible(filterInspector_);
    addAndMakeVisible(micInputSelector_);
    graphChannelSelector_.addItem("LEFT", 1);
    graphChannelSelector_.addItem("RIGHT", 2);
    graphChannelSelector_.addItem("WORST OF L/R", 3);
    graphChannelSelector_.setSelectedId(3, juce::dontSendNotification);
    addAndMakeVisible(graphChannelSelector_);
    waterfallChannelSelector_.addItem("LEFT", 1);
    waterfallChannelSelector_.addItem("RIGHT", 2);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    waterfallStateSelector_.addItem("BEFORE CORRECTION", 1);
    waterfallStateSelector_.addItem("AFTER CORRECTION", 2);
    waterfallStateSelector_.setSelectedId(1, juce::dontSendNotification);
    addAndMakeVisible(waterfallChannelSelector_);
    addAndMakeVisible(waterfallStateSelector_);

    addAndMakeVisible(newMeasurementButton_);
    addAndMakeVisible(loadProfileButton_);
    addAndMakeVisible(measureButton_);
    addAndMakeVisible(autoCorrectButton_);
    addAndMakeVisible(saveProfileButton_);
    addAndMakeVisible(correctionToggle_);
    addAndMakeVisible(autoTargetToggle_);
    autoTargetToggle_.setToggleState(true, juce::dontSendNotification);
    autoCorrectButton_.setEnabled(false);
    correctionToggle_.setEnabled(false);
    saveProfileButton_.setEnabled(false);

    status_.setText("WORKFLOW: 1) NEW MEASUREMENT  2) MEASURE ROOM L + R  3) AUTO CORRECT + VERIFY  4) SAVE PROFILE AS...  5) LOAD PROFILE...",
                    juce::dontSendNotification);
    addAndMakeVisible(status_);

    targetSlider_.onValueChange = [this] { refreshModel(); };
    strengthSlider_.onValueChange = [this] { refreshModel(); };
    maxCutSlider_.onValueChange = [this] { refreshModel(); };
    sweepLevelSlider_.onValueChange = [this] { updateMeasurementConfigFromDevice(); };
    inputTrimSlider_.onValueChange = [this] {
        const int selected = selectedMicInput_.load(std::memory_order_acquire);
        if (selected >= 0 && selected < static_cast<int>(inputTrimDb_.size()))
            inputTrimDb_[static_cast<std::size_t>(selected)].store(static_cast<float>(inputTrimSlider_.getValue()), std::memory_order_release);
    };
    micInputSelector_.onChange = [this] {
        const int selected = std::max(0, micInputSelector_.getSelectedId() - 1);
        selectedMicInput_.store(selected, std::memory_order_release);
        if (selected >= 0 && selected < static_cast<int>(inputTrimDb_.size()))
            inputTrimSlider_.setValue(inputTrimDb_[static_cast<std::size_t>(selected)].load(std::memory_order_acquire), juce::dontSendNotification);
        activateSelectedMicInput();
    };
    graphChannelSelector_.onChange = [this] { refreshGraphView(); };
    waterfallChannelSelector_.onChange = [this] { refreshWaterfallView(); };
    waterfallStateSelector_.onChange = [this] { refreshWaterfallView(); };
    newMeasurementButton_.onClick = [this] { startNewMeasurementSession(); };
    loadProfileButton_.onClick = [this] { beginLoadProfile(); };
    measureButton_.onClick = [this] { startMeasurement(false); };
    autoCorrectButton_.onClick = [this] { startAutoCorrection(); };
    saveProfileButton_.onClick = [this] { beginSaveProfileAs(); };
    autoTargetToggle_.onClick = [this] {
        const bool automatic = autoTargetToggle_.getToggleState();
        targetSlider_.setEnabled(!automatic);
        if (automatic && baselinesValid())
            applyRecommendedStereoTarget();
        status_.setText(automatic
            ? (baselinesValid()
                ? "AUTO TARGET recalculated from the current LEFT + RIGHT measurement."
                : "AUTO TARGET: one conservative common target will be chosen after LEFT + RIGHT are measured.")
            : "Manual target enabled; set Target decay time and press AUTO CORRECT + VERIFY.",
            juce::dontSendNotification);
    };
    targetSlider_.setEnabled(false);
    correctionToggle_.onClick = [this] {
        const bool enabled = correctionToggle_.getToggleState() && hasAnyCorrection();
        correctionEnabled_.store(enabled, std::memory_order_release);
        status_.setText(enabled ? "Stereo correction profiles ACTIVE." : "Correction BYPASSED.",
                        juce::dontSendNotification);
    };

    for (auto& trim : inputTrimDb_) trim.store(0.0f, std::memory_order_relaxed);

    const auto error = deviceManager_.initialise(1, 2, nullptr, true);
    if (error.isNotEmpty())
        status_.setText("Audio device error: " + error, juce::dontSendNotification);

    // On Windows, JUCE ASIO is explicitly compiled in for v0.12. If there is
    // exactly one ASIO device, prefer it automatically. With multiple ASIO
    // devices the normal Audio Device selector remains in control.
    preferSingleAsioDeviceOnWindows();

    deviceManager_.addAudioCallback(this);
    updateMeasurementConfigFromDevice();
    refreshMicInputSelector();
    loadActiveProfiles();
    loadWaterfallSnapshots();
    rt60::DisplaySnapshot display;
    if (loadDisplaySnapshot(display))
        applyDisplaySnapshot(display);
    refreshModel();
    if (display.hasAfter())
        waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
    refreshWaterfallView();
    refreshGraphView();
    refreshMeasurementQuality();
    refreshFilterInspector();
    startTimerHz(20);
}

MainComponent::~MainComponent()
{
    stopTimer();
    deviceManager_.removeAudioCallback(this);
}

juce::File MainComponent::profileDirectory()
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("Room Decay Lab")
        .getChildFile("RT60 Room Decay Corrector");
}

juce::File MainComponent::activeProfileFile(int channel)
{
    return profileDirectory().getChildFile(channel == 0
        ? "active_profile_left.rt60" : "active_profile_right.rt60");
}

juce::File MainComponent::legacyProfileFile()
{
    return profileDirectory().getChildFile("active_profile.rt60");
}

juce::File MainComponent::waterfallFile(int channel, bool afterCorrection)
{
    const juce::String side = channel == 0 ? "left" : "right";
    const juce::String phase = afterCorrection ? "after" : "before";
    return profileDirectory().getChildFile("waterfall_" + phase + "_" + side + ".rt60wf");
}

juce::File MainComponent::displaySnapshotFile()
{
    return profileDirectory().getChildFile("active_display.rt60g");
}

juce::File MainComponent::activeBundleFile()
{
    return profileDirectory().getChildFile("active_profile_bundle.rt60profile");
}

juce::File MainComponent::bestVerifiedProfileFile()
{
    return profileDirectory().getChildFile("best_verified.rt60profile");
}

rt60::DisplaySnapshot MainComponent::makeDisplaySnapshot() const
{
    return displaySnapshot_;
}

void MainComponent::applyDisplaySnapshot(const rt60::DisplaySnapshot& snapshot)
{
    displaySnapshot_ = snapshot;
    graph_.setDisplaySnapshot(&displaySnapshot_);
    model_.clearMeasuredAfter();
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float value = 0.0f;
        if (displaySnapshot_.valueBefore(rt60::DisplayChannelView::Worst, i, value))
            model_.setMeasured(i, value);
        if (displaySnapshot_.valueAfter(rt60::DisplayChannelView::Worst, i, value))
            model_.setMeasuredAfter(i, value);
    }
    refreshGraphView();
}

void MainComponent::saveDisplaySnapshot()
{
    profileDirectory().createDirectory();
    const auto encoded = rt60::DisplaySnapshotCodec::serialize(displaySnapshot_);
    displaySnapshotFile().replaceWithText(juce::String::fromUTF8(encoded.c_str()));
}

bool MainComponent::loadDisplaySnapshot(rt60::DisplaySnapshot& snapshot) const
{
    const auto file = displaySnapshotFile();
    return file.existsAsFile()
        && rt60::DisplaySnapshotCodec::deserialize(file.loadFileAsString().toStdString(), snapshot);
}

rt60::ProfileBundle MainComponent::makeProfileBundle(const juce::String& profileName) const
{
    rt60::ProfileBundle bundle;
    bundle.profiles = correctionProfiles_;
    bundle.beforeMeasurements = baselineMeasurements_;
    if (displaySnapshot_.hasAfter())
        bundle.afterMeasurements = latestMeasurements_;
    bundle.hasMeasurementDetails = true;
    bundle.beforeWaterfalls = beforeWaterfalls_;
    bundle.afterWaterfalls = afterWaterfalls_;

    // Build the saved graph from the actual measurement state rather than
    // trusting a possibly stale UI snapshot. This makes separately saved
    // room profiles genuinely independent.
    bundle.display = displaySnapshot_;
    for (int channel = 0; channel < 2; ++channel) {
        const auto& before = baselineMeasurements_[static_cast<std::size_t>(channel)];
        if (before.valid) {
            for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
                bundle.display.beforeMs[static_cast<std::size_t>(channel)][i] = before.bands[i].rt60Ms;
                bundle.display.beforeValid[static_cast<std::size_t>(channel)][i] = before.bands[i].valid;
            }
        }
        if (displaySnapshot_.hasAfter(channel)) {
            const auto& after = latestMeasurements_[static_cast<std::size_t>(channel)];
            if (after.valid) {
                for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
                    bundle.display.afterMs[static_cast<std::size_t>(channel)][i] = after.bands[i].rt60Ms;
                    bundle.display.afterValid[static_cast<std::size_t>(channel)][i] = after.bands[i].valid;
                }
            }
        }
    }
    bundle.metadata.appMajor = 16;
    bundle.metadata.appMinor = 0;
    bundle.metadata.measurementSampleRate = measurement_.config().sampleRate;
    if (baselineMeasurements_[0].valid)
        bundle.metadata.measurementSampleRate = baselineMeasurements_[0].sampleRate;
    else if (loadedMetadata_.measurementSampleRate > 0.0)
        bundle.metadata.measurementSampleRate = loadedMetadata_.measurementSampleRate;
    bundle.metadata.targetMs = static_cast<float>(targetSlider_.getValue());
    bundle.metadata.maxCorrectionHz = static_cast<float>(maxCutSlider_.getValue());
    bundle.metadata.verified = currentProfileVerified_;
    bundle.metadata.usedFallback = currentProfileUsedFallback_;
    bundle.metadata.createdUtc = juce::Time::getCurrentTime().toISO8601(true).toStdString();
    bundle.metadata.profileName = profileName.toStdString();
    return bundle;
}

bool MainComponent::saveProfileBundleToFile(const juce::File& file)
{
    if (file == juce::File{})
        return false;

    file.getParentDirectory().createDirectory();
    const auto bundle = makeProfileBundle(file.getFileNameWithoutExtension());
    const auto encoded = rt60::ProfileBundleCodec::serialize(bundle);
    if (!file.replaceWithText(juce::String::fromUTF8(encoded.c_str())))
        return false;

    profileDirectory().createDirectory();
    activeBundleFile().replaceWithText(juce::String::fromUTF8(encoded.c_str()));
    if (bundle.metadata.verified)
        bestVerifiedProfileFile().replaceWithText(juce::String::fromUTF8(encoded.c_str()));

    // Keep the legacy active mirror too so older plug-in builds still work.
    saveActiveProfiles();
    saveWaterfallSnapshots();
    saveDisplaySnapshot();
    currentProfileName_ = file.getFileNameWithoutExtension();
    loadedMetadata_ = bundle.metadata;
    refreshFilterInspector();
    return true;
}

bool MainComponent::loadProfileBundleFromFile(const juce::File& file)
{
    if (!file.existsAsFile())
        return false;

    rt60::ProfileBundle parsed;
    if (!rt60::ProfileBundleCodec::deserialize(file.loadFileAsString().toStdString(), parsed))
        return false;

    // Reset all room-dependent runtime state first. The graph keeps a pointer
    // to model_, so assigning a fresh DecayModel preserves the pointer while
    // removing values left by the previously loaded/measured room.
    model_ = rt60::DecayModel{};
    bestCorrectionProfiles_ = {};
    bestVerifiedMeasurements_ = {};
    bestVerifiedReports_ = {};
    bestAfterWaterfalls_ = {};
    haveBestVerifiedPass_ = false;
    bestVerifiedPass_ = 0;
    baselineObjectiveMs_ = 0.0f;
    bestObjectiveMs_ = 0.0f;
    digitalTwinScore_ = 0.0f;

    correctionProfiles_ = parsed.profiles;
    beforeWaterfalls_ = parsed.beforeWaterfalls;
    afterWaterfalls_ = parsed.afterWaterfalls;

    // A loaded profile must replace the previous room-measurement session,
    // never mix with it. v3 restores the full analysed summaries; old bundles
    // still restore their saved graph/waterfall without pretending that the
    // missing quality metrics belong to the loaded room.
    baselineMeasurements_ = {};
    latestMeasurements_ = {};
    if (parsed.hasMeasurementDetails) {
        baselineMeasurements_ = parsed.beforeMeasurements;
        latestMeasurements_ = parsed.display.hasAfter()
            ? parsed.afterMeasurements : parsed.beforeMeasurements;
    }

    loadedMetadata_ = parsed.metadata;
    currentProfileVerified_ = parsed.metadata.verified;
    currentProfileUsedFallback_ = parsed.metadata.usedFallback;
    currentProfileName_ = file.getFileNameWithoutExtension();

    const auto& reference = !correctionProfiles_[0].empty() ? correctionProfiles_[0] : correctionProfiles_[1];
    if (!reference.empty()) {
        targetSlider_.setValue(reference.targetMs, juce::dontSendNotification);
        strengthSlider_.setValue(reference.strength * 100.0f, juce::dontSendNotification);
        autoTargetToggle_.setToggleState(reference.autoTarget, juce::dontSendNotification);
        targetSlider_.setEnabled(!reference.autoTarget);
        if (parsed.metadata.maxCorrectionHz > 0.0f)
            maxCutSlider_.setValue(parsed.metadata.maxCorrectionHz, juce::dontSendNotification);
        for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
            float target = 0.0f;
            for (int channel = 0; channel < 2; ++channel)
                target = std::max(target, correctionProfiles_[channel].targetBandMs[i]);
            if (target > 0.0f)
                model_.setTarget(i, target);
        }
    }

    applyDisplaySnapshot(parsed.display);
    publishCorrectionBanks();
    const bool enabled = hasAnyCorrection();
    correctionEnabled_.store(enabled, std::memory_order_release);
    correctionToggle_.setEnabled(enabled);
    correctionToggle_.setToggleState(enabled, juce::dontSendNotification);
    saveProfileButton_.setEnabled(enabled);

    const auto activeEncoded = rt60::ProfileBundleCodec::serialize(parsed);
    profileDirectory().createDirectory();
    activeBundleFile().replaceWithText(juce::String::fromUTF8(activeEncoded.c_str()));
    if (parsed.metadata.verified)
        bestVerifiedProfileFile().replaceWithText(juce::String::fromUTF8(activeEncoded.c_str()));
    saveActiveProfiles();
    saveWaterfallSnapshots();
    saveDisplaySnapshot();

    waterfallStateSelector_.setSelectedId(parsed.display.hasAfter() ? 2 : 1, juce::dontSendNotification);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    refreshWaterfallView();
    refreshModel();
    refreshGraphView();
    refreshMeasurementQuality();
    refreshFilterInspector();
    enableIdleControls();
    return true;
}

void MainComponent::beginSaveProfileAs()
{
    if (!hasAnyCorrection()) {
        status_.setText("Nothing to save yet. Run MEASURE ROOM L + R, then AUTO CORRECT + VERIFY.",
                        juce::dontSendNotification);
        return;
    }

    auto folder = juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
    const auto stamp = juce::Time::getCurrentTime().formatted("%Y-%m-%d_%H-%M");
    auto suggested = folder.getChildFile("RT60_Profile_" + stamp + ".rt60profile");
    saveProfileChooser_ = std::make_unique<juce::FileChooser>(
        "Save RT60 correction profile as...", suggested, "*.rt60profile");
    saveProfileChooser_->launchAsync(
        juce::FileBrowserComponent::saveMode
            | juce::FileBrowserComponent::canSelectFiles
            | juce::FileBrowserComponent::warnAboutOverwriting,
        [this](const juce::FileChooser& chooser) {
            auto file = chooser.getResult();
            if (file == juce::File{})
                return;
            if (!file.hasFileExtension("rt60profile"))
                file = file.withFileExtension("rt60profile");
            if (!saveProfileBundleToFile(file)) {
                status_.setText("SAVE FAILED: could not write " + file.getFullPathName(),
                                juce::dontSendNotification);
                return;
            }
            juce::String msg = "PROFILE SAVED AS '" + currentProfileName_ + "' | "
                             + file.getFullPathName() + " | Cubase/VST3 active mirror updated";
            msg += currentProfileVerified_ ? " | VERIFIED" : " | UNVERIFIED";
            status_.setText(msg, juce::dontSendNotification);
        });
}

void MainComponent::beginLoadProfile()
{
    auto folder = juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
    loadProfileChooser_ = std::make_unique<juce::FileChooser>(
        "Load RT60 correction profile...", folder, "*.rt60profile");
    loadProfileChooser_->launchAsync(
        juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& chooser) {
            const auto file = chooser.getResult();
            if (file == juce::File{})
                return;
            if (!loadProfileBundleFromFile(file)) {
                status_.setText("LOAD FAILED: invalid or corrupt RT60 profile bundle.",
                                juce::dontSendNotification);
                return;
            }
            int beforeBands = 0, afterBands = 0;
            for (int channel = 0; channel < 2; ++channel) {
                for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
                    if (displaySnapshot_.beforeValid[static_cast<std::size_t>(channel)][i]) ++beforeBands;
                    if (displaySnapshot_.afterValid[static_cast<std::size_t>(channel)][i]) ++afterBands;
                }
            }
            juce::String msg = "LOADED PROFILE '" + currentProfileName_ + "' | graph state replaced | BEFORE "
                             + juce::String(beforeBands) + " bands | AFTER " + juce::String(afterBands)
                             + " bands | active mirror updated for VST3";
            msg += currentProfileVerified_ ? " | VERIFIED" : " | UNVERIFIED";
            if (loadedMetadata_.legacyBundle)
                msg += " | legacy bundle: limited legacy metadata";
            if (loadedMetadata_.measurementSampleRate > 0.0) {
                if (auto* device = deviceManager_.getCurrentAudioDevice()) {
                    const double now = device->getCurrentSampleRate();
                    if (std::abs(now - loadedMetadata_.measurementSampleRate) > 1.0)
                        msg += " | NOTE: measured @ " + juce::String(loadedMetadata_.measurementSampleRate, 0)
                             + " Hz, current device " + juce::String(now, 0)
                             + " Hz; filter frequencies are safely recalculated for the current rate";
                }
            }
            status_.setText(msg, juce::dontSendNotification);
        });
}

void MainComponent::saveWaterfallSnapshots()
{
    profileDirectory().createDirectory();
    for (int channel = 0; channel < 2; ++channel) {
        const auto& before = beforeWaterfalls_[static_cast<std::size_t>(channel)];
        const auto& after = afterWaterfalls_[static_cast<std::size_t>(channel)];
        if (before.valid()) {
            const auto encoded = rt60::WaterfallAnalyzer::serialize(before);
            waterfallFile(channel, false).replaceWithText(juce::String::fromUTF8(encoded.c_str()));
        } else {
            waterfallFile(channel, false).deleteFile();
        }
        if (after.valid()) {
            const auto encoded = rt60::WaterfallAnalyzer::serialize(after);
            waterfallFile(channel, true).replaceWithText(juce::String::fromUTF8(encoded.c_str()));
        } else {
            waterfallFile(channel, true).deleteFile();
        }
    }
}

void MainComponent::loadWaterfallSnapshots()
{
    for (int channel = 0; channel < 2; ++channel) {
        for (int phase = 0; phase < 2; ++phase) {
            const bool after = phase == 1;
            const auto file = waterfallFile(channel, after);
            if (!file.existsAsFile())
                continue;
            rt60::WaterfallData parsed;
            if (rt60::WaterfallAnalyzer::deserialize(file.loadFileAsString().toStdString(), parsed)) {
                if (after) afterWaterfalls_[static_cast<std::size_t>(channel)] = std::move(parsed);
                else beforeWaterfalls_[static_cast<std::size_t>(channel)] = std::move(parsed);
            }
        }
    }
}

void MainComponent::refreshWaterfallView()
{
    const int channel = juce::jlimit(0, 1, waterfallChannelSelector_.getSelectedId() - 1);
    const bool after = waterfallStateSelector_.getSelectedId() == 2;
    const auto& data = after ? afterWaterfalls_[static_cast<std::size_t>(channel)]
                             : beforeWaterfalls_[static_cast<std::size_t>(channel)];
    waterfallGraph_.setData(data.valid() ? &data : nullptr);
    waterfallGraph_.setCaption("LOW-FREQUENCY DECAY - " + juce::String(speakerName(channel))
                               + (after ? " - AFTER CORRECTION" : " - BEFORE CORRECTION") + " - 20 to 300 Hz");
}

void MainComponent::updateWaterfallForMeasurement(int channel, bool afterCorrection,
                                                   const rt60::MeasurementResult& result)
{
    if (!result.valid || result.impulseResponse.empty())
        return;
    rt60::WaterfallConfig cfg;
    cfg.minHz = 20.0f;
    cfg.maxHz = std::min(300.0f, static_cast<float>(result.sampleRate * 0.45));
    cfg.maxTimeMs = 1000.0f;
    cfg.timeStepMs = 20.0f;
    cfg.frequencyPoints = 96;
    cfg.fftSize = 8192;
    cfg.floorDb = -80.0f;
    auto data = rt60::WaterfallAnalyzer::analyse(result.impulseResponse, result.sampleRate, cfg);
    if (!data.valid())
        return;
    if (afterCorrection)
        afterWaterfalls_[static_cast<std::size_t>(channel)] = std::move(data);
    else
        beforeWaterfalls_[static_cast<std::size_t>(channel)] = std::move(data);
    refreshWaterfallView();
}

bool MainComponent::hasAnyCorrection() const noexcept
{
    return !correctionProfiles_[0].empty() || !correctionProfiles_[1].empty();
}

bool MainComponent::baselinesValid() const noexcept
{
    return baselineMeasurements_[0].valid && baselineMeasurements_[1].valid;
}

void MainComponent::saveActiveProfiles()
{
    if (!hasAnyCorrection())
        return;

    profileDirectory().createDirectory();
    for (int channel = 0; channel < 2; ++channel) {
        const auto encoded = rt60::CorrectionEngine::serialize(correctionProfiles_[channel]);
        activeProfileFile(channel).replaceWithText(juce::String::fromUTF8(encoded.c_str()));
    }
}

void MainComponent::loadActiveProfiles()
{
    const auto bundleFile = activeBundleFile();
    if (bundleFile.existsAsFile()) {
        rt60::ProfileBundle bundle;
        if (rt60::ProfileBundleCodec::deserialize(bundleFile.loadFileAsString().toStdString(), bundle)) {
            correctionProfiles_ = bundle.profiles;
            beforeWaterfalls_ = bundle.beforeWaterfalls;
            afterWaterfalls_ = bundle.afterWaterfalls;
            baselineMeasurements_ = {};
            latestMeasurements_ = {};
            if (bundle.hasMeasurementDetails) {
                baselineMeasurements_ = bundle.beforeMeasurements;
                latestMeasurements_ = bundle.display.hasAfter()
                    ? bundle.afterMeasurements : bundle.beforeMeasurements;
            }
            loadedMetadata_ = bundle.metadata;
            currentProfileVerified_ = bundle.metadata.verified;
            currentProfileUsedFallback_ = bundle.metadata.usedFallback;
            currentProfileName_ = juce::String::fromUTF8(bundle.metadata.profileName.c_str());
            const auto& reference = !correctionProfiles_[0].empty() ? correctionProfiles_[0] : correctionProfiles_[1];
            if (!reference.empty()) {
                targetSlider_.setValue(reference.targetMs, juce::dontSendNotification);
                strengthSlider_.setValue(reference.strength * 100.0f, juce::dontSendNotification);
                autoTargetToggle_.setToggleState(reference.autoTarget, juce::dontSendNotification);
                targetSlider_.setEnabled(!reference.autoTarget);
                if (bundle.metadata.maxCorrectionHz > 0.0f)
                    maxCutSlider_.setValue(bundle.metadata.maxCorrectionHz, juce::dontSendNotification);
            }
            applyDisplaySnapshot(bundle.display);
            publishCorrectionBanks();
            const bool enabled = hasAnyCorrection();
            correctionEnabled_.store(enabled, std::memory_order_release);
            correctionToggle_.setEnabled(enabled);
            correctionToggle_.setToggleState(enabled, juce::dontSendNotification);
            saveProfileButton_.setEnabled(enabled);
            enableIdleControls();
            status_.setText("Loaded active profile bundle: " + juce::String(totalStages(correctionProfiles_))
                            + " stages" + (currentProfileVerified_ ? " | VERIFIED" : " | UNVERIFIED")
                            + (baselinesValid() ? " | measurement state restored" : " | legacy graph-only measurement state"),
                            juce::dontSendNotification);
            return;
        }
        status_.setText("Active profile bundle is corrupt; trying the last legacy stereo mirror without partially loading it.",
                        juce::dontSendNotification);
    }
    std::array<rt60::CorrectionProfile, 2> loaded{};
    bool gotAnyStereoFile = false;
    bool ok = true;

    for (int channel = 0; channel < 2; ++channel) {
        const auto file = activeProfileFile(channel);
        if (!file.existsAsFile())
            continue;
        gotAnyStereoFile = true;
        if (!rt60::CorrectionEngine::deserialize(file.loadFileAsString().toStdString(), loaded[channel]))
            ok = false;
    }

    // Backwards compatibility with v0.4 mono profile: use it on both channels
    // only when no new stereo profile files exist.
    if (!gotAnyStereoFile) {
        const auto legacy = legacyProfileFile();
        if (!legacy.existsAsFile())
            return;
        rt60::CorrectionProfile mono;
        if (!rt60::CorrectionEngine::deserialize(legacy.loadFileAsString().toStdString(), mono))
            return;
        loaded[0] = mono;
        loaded[1] = mono;
    } else if (!ok) {
        status_.setText("Stored stereo profile is corrupt/truncated; it was NOT partially loaded.",
                        juce::dontSendNotification);
        return;
    }

    correctionProfiles_ = std::move(loaded);
    const auto& reference = !correctionProfiles_[0].empty() ? correctionProfiles_[0] : correctionProfiles_[1];
    targetSlider_.setValue(reference.targetMs, juce::dontSendNotification);
    strengthSlider_.setValue(reference.strength * 100.0f, juce::dontSendNotification);
    autoTargetToggle_.setToggleState(reference.autoTarget, juce::dontSendNotification);
    targetSlider_.setEnabled(!reference.autoTarget);

    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float measured = 0.0f;
        float target = 0.0f;
        for (int channel = 0; channel < 2; ++channel) {
            measured = std::max(measured, correctionProfiles_[channel].measuredBandMs[i]);
            target = std::max(target, correctionProfiles_[channel].targetBandMs[i]);
        }
        if (measured > 0.0f)
            model_.setMeasured(i, measured);
        if (target > 0.0f)
            model_.setTarget(i, target);
    }

    publishCorrectionBanks();
    const bool enabled = hasAnyCorrection();
    correctionEnabled_.store(enabled, std::memory_order_release);
    correctionToggle_.setEnabled(enabled);
    correctionToggle_.setToggleState(enabled, juce::dontSendNotification);
    saveProfileButton_.setEnabled(enabled);
    currentProfileVerified_ = false;
    currentProfileUsedFallback_ = false;
    status_.setText("Loaded stereo correction: " + juce::String(totalStages(correctionProfiles_))
                    + " total decay stages.", juce::dontSendNotification);
}

void MainComponent::refreshModel()
{
    model_.setUniformTarget(static_cast<float>(targetSlider_.getValue()));
    model_.setStrength(static_cast<float>(strengthSlider_.getValue()) / 100.0f);
    model_.setMaxCutDb(18.0f);
    graph_.repaint();
    refreshImprovementReadout();
}

void MainComponent::preferSingleAsioDeviceOnWindows()
{
   #if JUCE_WINDOWS
    const auto& types = deviceManager_.getAvailableDeviceTypes();
    for (auto* type : types) {
        if (type == nullptr || !type->getTypeName().containsIgnoreCase("ASIO"))
            continue;

        type->scanForDevices();
        auto names = type->getDeviceNames(false);
        if (names.isEmpty())
            names = type->getDeviceNames(true);

        if (names.size() == 1) {
            deviceManager_.setCurrentAudioDeviceType(type->getTypeName(), true);
            return;
        }
    }
   #endif
}

void MainComponent::updateSelectedMicCallbackIndex()
{
    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr) {
        selectedMicCallbackIndex_.store(-1, std::memory_order_release);
        return;
    }

    const int physical = selectedMicInput_.load(std::memory_order_acquire);
    const auto active = device->getActiveInputChannels();
    selectedMicCallbackIndex_.store(callbackIndexForPhysicalInput(active, physical),
                                    std::memory_order_release);
}

void MainComponent::refreshMicInputSelector()
{
    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr)
        return;

    const auto names = device->getInputChannelNames();
    const auto active = device->getActiveInputChannels();
    juce::String signature;
    for (int i = 0; i < names.size(); ++i)
        signature += names[i] + (active[i] ? "*|" : "-|" );

    // The callback arrays contain only active channels, packed in ascending
    // physical-channel order. Keep a separate physical->callback mapping.
    updateSelectedMicCallbackIndex();

    if (signature == micInputSignature_)
        return;
    micInputSignature_ = signature;

    int selected = selectedMicInput_.load(std::memory_order_acquire);
    int firstActive = -1;
    micInputSelector_.clear(juce::dontSendNotification);
    for (int i = 0; i < names.size(); ++i) {
        if (active[i] && firstActive < 0)
            firstActive = i;
        auto label = names[i].isNotEmpty() ? names[i] : ("Input " + juce::String(i + 1));
        if (!active[i])
            label += " (disabled)";
        micInputSelector_.addItem(label, i + 1);
    }
    if (selected < 0 || selected >= names.size() || !active[selected])
        selected = std::max(0, firstActive);
    selectedMicInput_.store(selected, std::memory_order_release);
    updateSelectedMicCallbackIndex();
    if (names.size() > 0)
        micInputSelector_.setSelectedId(selected + 1, juce::dontSendNotification);
}

void MainComponent::activateSelectedMicInput()
{
    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr)
        return;

    const int selected = selectedMicInput_.load(std::memory_order_acquire);
    const auto names = device->getInputChannelNames();
    if (selected < 0 || selected >= names.size())
        return;

    juce::AudioDeviceManager::AudioDeviceSetup setup;
    deviceManager_.getAudioDeviceSetup(setup);
    setup.useDefaultInputChannels = false;
    setup.inputChannels.clear();
    setup.inputChannels.setBit(selected);

    const auto error = deviceManager_.setAudioDeviceSetup(setup, true);
    if (error.isNotEmpty()) {
        status_.setText("Could not activate " + (names[selected].isNotEmpty() ? names[selected] : ("Input " + juce::String(selected + 1)))
                        + ": " + error, juce::dontSendNotification);
    } else {
        micInputSignature_.clear();
        liveInputPeak_.store(0.0f, std::memory_order_release);
        liveInputRms_.store(0.0f, std::memory_order_release);
        livePostInputPeak_.store(0.0f, std::memory_order_release);
        livePostInputRms_.store(0.0f, std::memory_order_release);
        liveInputAvailable_.store(false, std::memory_order_release);
        displayedInputDb_ = -60.0f;
        updateSelectedMicCallbackIndex();
        status_.setText("Measurement input activated: "
                        + (names[selected].isNotEmpty() ? names[selected] : ("Input " + juce::String(selected + 1)))
                        + ". Watch LIVE MIC INPUT, then press MEASURE ROOM L + R.",
                        juce::dontSendNotification);
    }
}

void MainComponent::refreshLiveInputMeter()
{
    const bool available = liveInputAvailable_.load(std::memory_order_acquire);
    const float blockPeak = liveInputPeak_.exchange(0.0f, std::memory_order_acq_rel);
    const float rms = liveInputRms_.load(std::memory_order_acquire);
    const float postPeak = livePostInputPeak_.exchange(0.0f, std::memory_order_acq_rel);
    const float postRms = livePostInputRms_.load(std::memory_order_acquire);

    const float peakDb = blockPeak > 1.0e-6f ? juce::Decibels::gainToDecibels(blockPeak, -60.0f) : -60.0f;
    const float rmsDb = rms > 1.0e-6f ? juce::Decibels::gainToDecibels(rms, -60.0f) : -60.0f;
    const float postPeakDb = postPeak > 1.0e-6f ? juce::Decibels::gainToDecibels(postPeak, -60.0f) : -60.0f;
    const float postRmsDb = postRms > 1.0e-6f ? juce::Decibels::gainToDecibels(postRms, -60.0f) : -60.0f;

    // Fast attack, visible fall-back. The audio thread only publishes atomics.
    if (peakDb >= displayedInputDb_)
        displayedInputDb_ = peakDb;
    else
        displayedInputDb_ = std::max(-60.0f, displayedInputDb_ - 1.5f);

    inputLevelMeter_.setValue(displayedInputDb_, juce::dontSendNotification);

    auto* device = deviceManager_.getCurrentAudioDevice();
    const int selected = selectedMicInput_.load(std::memory_order_acquire);
    juce::String inputName = "Input " + juce::String(selected + 1);
    if (device != nullptr) {
        const auto names = device->getInputChannelNames();
        if (selected >= 0 && selected < names.size() && names[selected].isNotEmpty())
            inputName = names[selected];
    }

    const auto driverType = deviceManager_.getCurrentAudioDeviceType();
   #if JUCE_WINDOWS
    if (device != nullptr
        && device->getName().containsIgnoreCase("E-MU")
        && !driverType.containsIgnoreCase("ASIO")) {
        inputLevelValueLabel_.setText("WRONG DRIVER: " + driverType
                                      + " | select ASIO / E-MU ASIO in Audio Device",
                                      juce::dontSendNotification);
        return;
    }
   #endif

    if (!available) {
        inputLevelValueLabel_.setText(driverType + " | " + inputName
                                      + " | NOT ACTIVE - select/enable this input",
                                      juce::dontSendNotification);
        return;
    }

    if (blockPeak >= 0.999f) {
        inputLevelValueLabel_.setText(driverType + " | " + inputName + " | CLIP - lower mic/preamp gain", juce::dontSendNotification);
        return;
    }

    const auto peakText = blockPeak > 1.0e-6f ? juce::String(peakDb, 1) + " dBFS" : juce::String("-inf dBFS");
    const auto rmsText = rms > 1.0e-6f ? juce::String(rmsDb, 1) + " dBFS" : juce::String("-inf dBFS");
    const auto postPeakText = postPeak > 1.0e-6f ? juce::String(postPeakDb, 1) + " dBFS" : juce::String("-inf dBFS");
    const auto postRmsText = postRms > 1.0e-6f ? juce::String(postRmsDb, 1) + " dBFS" : juce::String("-inf dBFS");
    const auto sr = device != nullptr ? device->getCurrentSampleRate() : 0.0;
    inputLevelValueLabel_.setText(inputName + " | " + juce::String(sr / 1000.0, 1) + " kHz | PRE " + peakText + "/" + rmsText
                                  + " | POST " + postPeakText + "/" + postRmsText, juce::dontSendNotification);
}

void MainComponent::updateMeasurementConfigFromDevice()
{
    auto cfg = measurement_.config();
    if (auto* device = deviceManager_.getCurrentAudioDevice())
        cfg.sampleRate = device->getCurrentSampleRate();
    cfg.level = std::pow(10.0f, static_cast<float>(sweepLevelSlider_.getValue()) / 20.0f);
    measurement_.setConfig(cfg);
}

void MainComponent::publishCorrectionBanks()
{
    double sampleRate = measurement_.config().sampleRate;
    if (auto* device = deviceManager_.getCurrentAudioDevice())
        sampleRate = device->getCurrentSampleRate();

    const int active = activeBankIndex_.load(std::memory_order_acquire);
    const int pending = pendingBankIndex_.load(std::memory_order_acquire);
    int slot = 0;
    while (slot == active || slot == pending)
        ++slot;
    if (slot >= static_cast<int>(correctionBankSlots_.size())) {
        // This can only happen if active/pending changed while selecting. One
        // fresh read always leaves at least one slot free in the 3-slot bank.
        const int activeNow = activeBankIndex_.load(std::memory_order_acquire);
        const int pendingNow = pendingBankIndex_.load(std::memory_order_acquire);
        slot = 0;
        while (slot == activeNow || slot == pendingNow)
            ++slot;
    }

    auto& banks = correctionBankSlots_[static_cast<std::size_t>(slot)];
    banks.left.configure(correctionProfiles_[0], sampleRate);
    banks.right.configure(correctionProfiles_[1], sampleRate);
    pendingBankIndex_.store(slot, std::memory_order_release);
    refreshFilterInspector();
}

void MainComponent::clearCurrentMeasurementSession()
{
    // This is a runtime/session reset only. User-saved .rt60profile files are
    // never deleted here. Device, sample-rate, buffer, mic selection and input
    // trim stay exactly as the user configured them.
    autoCorrecting_ = false;
    autoIteration_ = 0;
    haveBestVerifiedPass_ = false;
    bestVerifiedPass_ = 0;
    currentProfileVerified_ = false;
    currentProfileUsedFallback_ = false;
    digitalTwinScore_ = 0.0f;
    baselineObjectiveMs_ = 0.0f;
    bestObjectiveMs_ = 0.0f;

    baselineMeasurements_ = {};
    latestMeasurements_ = {};
    bestVerifiedMeasurements_ = {};
    bestVerifiedReports_ = {};
    correctionProfiles_ = {};
    bestCorrectionProfiles_ = {};
    beforeWaterfalls_ = {};
    afterWaterfalls_ = {};
    bestAfterWaterfalls_ = {};
    displaySnapshot_ = {};
    loadedMetadata_ = {};
    currentProfileName_.clear();

    measurementIsAfter_.store(false, std::memory_order_release);
    measurementLogicalChannel_.store(0, std::memory_order_release);
    measurementFinished_.store(false, std::memory_order_release);
    measurementClipped_.store(false, std::memory_order_release);
    measurementPosition_.store(0, std::memory_order_release);

    // A BEFORE measurement must never pass through a correction left from a
    // previously loaded room profile. Publish empty banks and bypass them.
    correctionEnabled_.store(false, std::memory_order_release);
    correctionToggle_.setToggleState(false, juce::dontSendNotification);
    publishCorrectionBanks();

    graph_.setDisplaySnapshot(&displaySnapshot_);
    model_.clearMeasuredAfter();
    waterfallStateSelector_.setSelectedId(1, juce::dontSendNotification);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    graphChannelSelector_.setSelectedId(3, juce::dontSendNotification);
    refreshModel();
    refreshGraphView();
    refreshWaterfallView();
    refreshImprovementReadout();
    refreshMeasurementQuality();
    refreshFilterInspector();
    enableIdleControls();
}

void MainComponent::startNewMeasurementSession()
{
    if (measuring_.load(std::memory_order_acquire) || autoCorrecting_) {
        status_.setText("A measurement/verification pass is currently running. Wait for it to finish before starting a new session.",
                        juce::dontSendNotification);
        return;
    }

    clearCurrentMeasurementSession();
    status_.setText("NEW MEASUREMENT ready: previous runtime measurement/correction cleared. Audio device settings and saved profile files were kept. Check LIVE MIC INPUT, then press MEASURE ROOM L + R.",
                    juce::dontSendNotification);
}

void MainComponent::startMeasurement(bool afterCorrection)
{
    if (measuring_.load(std::memory_order_acquire))
        return;

    auto* device = deviceManager_.getCurrentAudioDevice();
    if (device == nullptr) {
        status_.setText("No active audio device.", juce::dontSendNotification);
        return;
    }

    const auto activeInputs = device->getActiveInputChannels();
    const int mic = selectedMicInput_.load(std::memory_order_acquire);
    if (mic < 0 || mic >= device->getInputChannelNames().size() || !activeInputs[mic]) {
        status_.setText("Selected microphone input is disabled. Enable that input in Audio Device Setup.",
                        juce::dontSendNotification);
        return;
    }

    const auto activeOutputs = device->getActiveOutputChannels();
    int activeOutputCount = 0;
    const int outputNameCount = device->getOutputChannelNames().size();
    for (int i = 0; i < outputNameCount; ++i)
        if (activeOutputs[i])
            ++activeOutputCount;
    if (activeOutputCount < 2) {
        status_.setText("Enable two monitor outputs. v16 measures LEFT and RIGHT separately.",
                        juce::dontSendNotification);
        return;
    }

    if (afterCorrection && (!hasAnyCorrection() || !correctionEnabled_.load(std::memory_order_acquire))) {
        status_.setText("No active stereo correction. Measure the room and run AUTO CORRECT first.",
                        juce::dontSendNotification);
        return;
    }

    updateMeasurementConfigFromDevice();
    if (!afterCorrection) {
        // MEASURE L + R always means a genuinely fresh, UNCORRECTED baseline.
        // Do not mix a new LEFT measurement with an old RIGHT measurement and
        // do not accidentally measure through a previously loaded correction.
        clearCurrentMeasurementSession();
        updateMeasurementConfigFromDevice();
    }
    measurementIsAfter_.store(afterCorrection, std::memory_order_release);
    measurementLogicalChannel_.store(0, std::memory_order_release);
    model_.clearMeasuredAfter();

    newMeasurementButton_.setEnabled(false);
    measureButton_.setEnabled(false);
    autoCorrectButton_.setEnabled(false);
    loadProfileButton_.setEnabled(false);
    correctionToggle_.setEnabled(false);
    saveProfileButton_.setEnabled(false);
    autoTargetToggle_.setEnabled(false);
    micInputSelector_.setEnabled(false);

    startMeasurementChannel(0);
}

void MainComponent::startMeasurementChannel(int logicalChannel)
{
    if (measuring_.load(std::memory_order_acquire))
        return;

    if (measurementIsAfter_.load(std::memory_order_acquire))
        publishCorrectionBanks(); // fresh zero-state filters for each speaker sweep

    const int oldSlot = activeMeasurementBuffer_.load(std::memory_order_acquire);
    const int newSlot = oldSlot == 0 ? 1 : 0;
    auto& buffers = measurementBuffers_[static_cast<std::size_t>(newSlot)];
    buffers.excitation = measurement_.makeExcitation();
    buffers.capture.assign(buffers.excitation.size(), 0.0f);

    measurementPosition_.store(0, std::memory_order_relaxed);
    measurementFinished_.store(false, std::memory_order_relaxed);
    measurementClipped_.store(false, std::memory_order_relaxed);
    measurementLogicalChannel_.store(logicalChannel, std::memory_order_release);
    activeMeasurementBuffer_.store(newSlot, std::memory_order_release);
    measuring_.store(true, std::memory_order_release);

    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    status_.setText(juce::String(after ? "Corrected " : "Uncorrected ") + speakerName(logicalChannel)
                    + " sweep in progress... keep the room quiet.", juce::dontSendNotification);
}

void MainComponent::startAutoCorrection()
{
    if (!baselinesValid() || measuring_.load(std::memory_order_acquire)) {
        status_.setText("Run a valid MEASURE ROOM L + R measurement first.", juce::dontSendNotification);
        return;
    }

    bestCorrectionProfiles_ = {};
    bestVerifiedMeasurements_ = {};
    bestVerifiedReports_ = {};
    bestAfterWaterfalls_ = {};
    haveBestVerifiedPass_ = false;
    bestVerifiedPass_ = 0;
    currentProfileVerified_ = false;
    currentProfileUsedFallback_ = false;

    std::array<rt60::DecayUniformityReport, 2> baselineReports{
        evaluateUniformity(0, baselineMeasurements_[0]),
        evaluateUniformity(1, baselineMeasurements_[1])
    };
    baselineObjectiveMs_ = combinedObjective(baselineReports);
    bestObjectiveMs_ = baselineObjectiveMs_;

    rt60::CorrectionDesignConfig cfg;
    cfg.targetMs = static_cast<float>(targetSlider_.getValue());
    cfg.autoTarget = false; // freeze one common stereo target for this correction pass
    cfg.strength = static_cast<float>(strengthSlider_.getValue()) / 100.0f;
    cfg.maxCorrectionHz = static_cast<float>(maxCutSlider_.getValue());
    cfg.minConfidence = 0.35f;
    cfg.maxT60ReductionPerPass = 0.55f;
    cfg.maxNewStages = 18;

    digitalTwinScore_ = 0.0f;
    int scoredChannels = 0;
    for (int channel = 0; channel < 2; ++channel) {
        correctionProfiles_[channel] = correctionEngine_.design(baselineMeasurements_[channel], cfg);

        if (correctionProfiles_[channel].empty()) {
            auto fallbackCfg = cfg;
            fallbackCfg.minConfidence = 0.20f;
            fallbackCfg.maxT60ReductionPerPass = 0.30f;
            fallbackCfg.maxNewStages = 8;
            fallbackCfg.allowConservativeBandFallback = true;
            correctionProfiles_[channel] = correctionEngine_.design(baselineMeasurements_[channel], fallbackCfg);
            if (!correctionProfiles_[channel].empty())
                currentProfileUsedFallback_ = true;
        }

        correctionProfiles_[channel].autoTarget = autoTargetToggle_.getToggleState();
        if (!correctionProfiles_[channel].empty()) {
            rt60::CorrectionOptimizationConfig optCfg;
            optCfg.rounds = 2;
            optCfg.zeroGridPoints = 7;
            optCfg.desiredGridPoints = 7;
            digitalTwinScore_ += rt60::CorrectionEngine::optimizeAgainstMeasurement(
                correctionProfiles_[channel], baselineMeasurements_[channel], measurement_, optCfg);
            ++scoredChannels;
        }
    }
    if (scoredChannels > 0)
        digitalTwinScore_ /= static_cast<float>(scoredChannels);

    if (!hasAnyCorrection()) {
        saveProfileButton_.setEnabled(false);
        status_.setText("No correction stages could be estimated from this measurement. The measurement is kept; raise sweep SNR or adjust target and try AUTO CORRECT again.",
                        juce::dontSendNotification);
        return;
    }

    publishCorrectionBanks();
    correctionEnabled_.store(true, std::memory_order_release);
    correctionToggle_.setToggleState(true, juce::dontSendNotification);
    correctionToggle_.setEnabled(true);
    saveProfileButton_.setEnabled(true);

    // v16 has one unambiguous correction workflow: AUTO CORRECT always
    // performs a real LEFT + RIGHT verification pass. There is no redundant
    // manual RE-MEASURE button and no hidden "verify" mode to remember.
    autoCorrecting_ = true;
    autoIteration_ = 1;
    status_.setText("AUTO CORRECT: correction designed. Now measuring LEFT + RIGHT again automatically to verify the real result...",
                    juce::dontSendNotification);
    startMeasurement(true);
}

rt60::DecayUniformityReport MainComponent::evaluateUniformity(
    int channel, const rt60::MeasurementResult& result) const
{
    rt60::DecayUniformityConfig cfg;
    cfg.maxHz = static_cast<float>(maxCutSlider_.getValue());
    cfg.minConfidence = 0.45f;
    cfg.toleranceFraction = 0.10f;
    cfg.requiredWithinFraction = 0.90f;
    return rt60::DecayUniformity::evaluate(baselineMeasurements_[static_cast<std::size_t>(channel)], result,
                                           static_cast<float>(targetSlider_.getValue()), cfg);
}

float MainComponent::combinedObjective(const std::array<rt60::DecayUniformityReport, 2>& reports) const
{
    float sum = 0.0f;
    int count = 0;
    for (const auto& report : reports) {
        if (report.correctableBands > 0) {
            sum += report.correctionObjectiveMs;
            ++count;
        }
    }
    return count > 0 ? sum / static_cast<float>(count) : 0.0f;
}

void MainComponent::applyRecommendedStereoTarget()
{
    if (!autoTargetToggle_.getToggleState() || !baselinesValid())
        return;

    rt60::DecayUniformityConfig cfg;
    cfg.maxHz = static_cast<float>(maxCutSlider_.getValue());
    cfg.minConfidence = 0.45f;
    const float left = rt60::DecayUniformity::chooseCommonTarget(baselineMeasurements_[0], cfg);
    const float right = rt60::DecayUniformity::chooseCommonTarget(baselineMeasurements_[1], cfg);
    // Use the less aggressive of the two recommended targets. This avoids
    // forcing one loudspeaker below the natural decay supported by the other.
    const float target = std::max(left, right);
    targetSlider_.setValue(target, juce::dontSendNotification);
    refreshModel();
}

void MainComponent::updateGraphFromStereo(bool afterCorrection)
{
    auto& values = afterCorrection ? displaySnapshot_.afterMs : displaySnapshot_.beforeMs;
    auto& valid = afterCorrection ? displaySnapshot_.afterValid : displaySnapshot_.beforeValid;

    for (int channel = 0; channel < 2; ++channel) {
        const auto& measurement = latestMeasurements_[static_cast<std::size_t>(channel)];
        for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
            const auto& band = measurement.bands[i];
            values[static_cast<std::size_t>(channel)][i] = band.rt60Ms;
            valid[static_cast<std::size_t>(channel)][i] = band.valid;
        }
    }

    graph_.setDisplaySnapshot(&displaySnapshot_);
    model_.clearMeasuredAfter();
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float worst = 0.0f;
        if (displaySnapshot_.valueBefore(rt60::DisplayChannelView::Worst, i, worst))
            model_.setMeasured(i, worst);
        if (displaySnapshot_.valueAfter(rt60::DisplayChannelView::Worst, i, worst))
            model_.setMeasuredAfter(i, worst);
    }
    refreshModel();
    refreshGraphView();
    refreshMeasurementQuality();
}

void MainComponent::refreshGraphView()
{
    const int id = graphChannelSelector_.getSelectedId();
    rt60::DisplayChannelView view = rt60::DisplayChannelView::Worst;
    if (id == 1) view = rt60::DisplayChannelView::Left;
    if (id == 2) view = rt60::DisplayChannelView::Right;
    graph_.setChannelView(view);
    graph_.setDisplaySnapshot(&displaySnapshot_);
    refreshImprovementReadout();
}

void MainComponent::refreshImprovementReadout()
{
    const auto view = static_cast<rt60::DisplayChannelView>(
        juce::jlimit(0, 2, graphChannelSelector_.getSelectedId() - 1));
    const char* viewName = view == rt60::DisplayChannelView::Left ? "LEFT"
                         : view == rt60::DisplayChannelView::Right ? "RIGHT" : "WORST L/R";

    float beforeSum = 0.0f;
    float afterSum = 0.0f;
    float targetSum = 0.0f;
    float worstBefore = 0.0f;
    float worstHz = 0.0f;
    int beforeCount = 0;
    int afterCount = 0;
    int targetCount = 0;

    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        const float hz = model_.bands()[i].frequencyHz;
        if (hz < 20.0f || hz > static_cast<float>(maxCutSlider_.getValue()))
            continue;

        float before = 0.0f;
        if (displaySnapshot_.valueBefore(view, i, before)) {
            beforeSum += before;
            ++beforeCount;
            if (before > worstBefore) {
                worstBefore = before;
                worstHz = hz;
            }
        }

        const float target = model_.bands()[i].targetMs;
        if (target > 1.0f) {
            targetSum += target;
            ++targetCount;
        }

        float after = 0.0f;
        if (displaySnapshot_.valueAfter(view, i, after)) {
            afterSum += after;
            ++afterCount;
        }
    }

    if (beforeCount == 0) {
        improvementLabel_.setText("RESULT: No room measurement yet  |  Next: press MEASURE ROOM L + R",
                                  juce::dontSendNotification);
        return;
    }

    const float beforeAvg = beforeSum / static_cast<float>(beforeCount);
    const float targetAvg = targetCount > 0 ? targetSum / static_cast<float>(targetCount)
                                            : static_cast<float>(targetSlider_.getValue());

    juce::String text = juce::String("RESULT [") + viewName + "]:  BEFORE "
                      + juce::String(beforeAvg, 0) + " ms  |  TARGET "
                      + juce::String(targetAvg, 0) + " ms";

    if (afterCount == 0) {
        text += "  |  WORST RING " + juce::String(worstHz, worstHz < 100.0f ? 1 : 0)
             + " Hz / " + juce::String(worstBefore, 0) + " ms"
             + "  |  Next: AUTO CORRECT + VERIFY";
        improvementLabel_.setText(text, juce::dontSendNotification);
        return;
    }

    const float afterAvg = afterSum / static_cast<float>(afterCount);
    const float improvement = beforeAvg > 1.0f
        ? 100.0f * (beforeAvg - afterAvg) / beforeAvg : 0.0f;
    const float targetError = targetAvg > 1.0f ? std::abs(afterAvg - targetAvg) / targetAvg : 1.0f;

    juce::String verdict;
    if (afterAvg >= beforeAvg * 1.02f)
        verdict = "NO IMPROVEMENT - CHECK MEASUREMENT";
    else if (targetError <= 0.15f)
        verdict = "VERY CLOSE TO TARGET";
    else if (targetError <= 0.30f)
        verdict = "GOOD IMPROVEMENT - SMALL DIFFERENCE REMAINS";
    else
        verdict = "IMPROVED - MORE CORRECTION MAY BE NEEDED";

    text += "  ->  AFTER " + juce::String(afterAvg, 0) + " ms"
         + "  |  IMPROVEMENT " + juce::String(improvement, 0) + "%"
         + "  |  " + verdict;
    improvementLabel_.setText(text, juce::dontSendNotification);
}

void MainComponent::refreshMeasurementQuality()
{
    struct QualityInfo {
        juce::String grade;
        float peak = -60.0f;
        float medianDr = 0.0f;
    };

    auto assess = [](const rt60::MeasurementResult& result) {
        QualityInfo q;
        if (!result.valid) {
            q.grade = "NO DATA";
            return q;
        }
        q.peak = result.peakDbFs;
        if (result.clipped) {
            q.grade = "CLIPPED";
            return q;
        }

        std::vector<float> dr;
        int trusted = 0;
        int valid = 0;
        for (const auto& band : result.bands) {
            if (!band.valid)
                continue;
            ++valid;
            dr.push_back(band.dynamicRangeDb);
            if (band.confidence >= 0.45f)
                ++trusted;
        }
        if (!dr.empty()) {
            std::sort(dr.begin(), dr.end());
            q.medianDr = dr[dr.size() / 2];
        }
        const float trustedRatio = valid > 0 ? static_cast<float>(trusted) / static_cast<float>(valid) : 0.0f;
        if (q.medianDr >= 25.0f && trustedRatio >= 0.50f)
            q.grade = "GOOD";
        else if (q.medianDr >= 15.0f && trustedRatio >= 0.30f)
            q.grade = "USABLE";
        else
            q.grade = "WEAK - RAISE SWEEP LEVEL";
        return q;
    };

    if (!displaySnapshot_.hasBefore() && !displaySnapshot_.hasAfter()) {
        qualityLabel_.setText("MEASUREMENT QUALITY: waiting for a real LEFT + RIGHT measurement",
                              juce::dontSendNotification);
        return;
    }

    const bool showAfter = displaySnapshot_.hasAfter();
    const auto& source = showAfter ? latestMeasurements_ : baselineMeasurements_;
    if (!source[0].valid && !source[1].valid) {
        qualityLabel_.setText("MEASUREMENT QUALITY: graph/profile loaded, but detailed microphone quality data are unavailable",
                              juce::dontSendNotification);
        return;
    }

    const auto l = assess(source[0]);
    const auto r = assess(source[1]);
    juce::String overall = (l.grade == "GOOD" && r.grade == "GOOD") ? "GOOD"
                          : (l.grade == "CLIPPED" || r.grade == "CLIPPED") ? "CLIPPED - REDUCE INPUT"
                          : (l.grade.startsWith("WEAK") || r.grade.startsWith("WEAK")) ? "WEAK"
                          : "USABLE";

    qualityLabel_.setText(juce::String("MEASUREMENT QUALITY [") + (showAfter ? "AFTER" : "BEFORE") + "]: "
                          + overall + "  |  L " + l.grade + " (peak " + juce::String(l.peak, 1)
                          + " dBFS, DR " + juce::String(l.medianDr, 0) + " dB)"
                          + "  |  R " + r.grade + " (peak " + juce::String(r.peak, 1)
                          + " dBFS, DR " + juce::String(r.medianDr, 0) + " dB)",
                          juce::dontSendNotification);
}

void MainComponent::refreshFilterInspector()
{
    double sampleRate = measurement_.config().sampleRate;
    if (auto* device = deviceManager_.getCurrentAudioDevice())
        sampleRate = device->getCurrentSampleRate();

    juce::String text;
    for (int channel = 0; channel < 2; ++channel) {
        text += juce::String(channel == 0 ? "LEFT" : "RIGHT") + " - "
              + juce::String(static_cast<int>(correctionProfiles_[static_cast<std::size_t>(channel)].stages.size()))
              + " stages\n";
        int index = 1;
        for (const auto& stage : correctionProfiles_[static_cast<std::size_t>(channel)].stages) {
            const float cut = rt60::CorrectionEngine::stageAttenuationDb(stage, sampleRate);
            text += juce::String(index++) + ". " + juce::String(stage.frequencyHz, 1) + " Hz | Q "
                  + juce::String(stage.estimatedQ, 2) + " | " + juce::String(cut, 2) + " dB | "
                  + juce::String(stage.measuredT60Ms, 0) + "->" + juce::String(stage.desiredT60Ms, 0)
                  + " ms | conf " + juce::String(stage.confidence, 2) + "\n";
        }
        if (correctionProfiles_[static_cast<std::size_t>(channel)].stages.empty())
            text += "(no correction stages)\n";
        text += "\n";
    }
    filterInspector_.setText(text, false);
}

void MainComponent::restoreBestVerifiedPass()
{
    if (!haveBestVerifiedPass_)
        return;

    correctionProfiles_ = bestCorrectionProfiles_;
    latestMeasurements_ = bestVerifiedMeasurements_;
    afterWaterfalls_ = bestAfterWaterfalls_;
    waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    refreshWaterfallView();
    publishCorrectionBanks();
    correctionEnabled_.store(true, std::memory_order_release);
    correctionToggle_.setToggleState(true, juce::dontSendNotification);
    correctionToggle_.setEnabled(true);
    updateGraphFromStereo(true);
}

void MainComponent::abortUnhelpfulAutoCorrection(const juce::String& reason)
{
    autoCorrecting_ = false;
    currentProfileVerified_ = false;
    correctionEnabled_.store(hasAnyCorrection(), std::memory_order_release);
    publishCorrectionBanks();
    correctionToggle_.setToggleState(hasAnyCorrection(), juce::dontSendNotification);
    correctionToggle_.setEnabled(hasAnyCorrection());
    saveProfileButton_.setEnabled(hasAnyCorrection());
    if (afterWaterfalls_[0].valid() || afterWaterfalls_[1].valid()) {
        waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
        waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
        refreshWaterfallView();
    }
    enableIdleControls();
    status_.setText("VERIFY WARNING: " + reason
                    + " | correction candidate was KEPT. You may SAVE PROFILE, adjust the correction settings and run AUTO CORRECT + VERIFY again, or bypass it.",
                    juce::dontSendNotification);
}

void MainComponent::finishAutoCorrection(bool hitIterationLimit, const juce::String& stopReason)
{
    std::array<rt60::DecayUniformityReport, 2> reports{
        evaluateUniformity(0, latestMeasurements_[0]),
        evaluateUniformity(1, latestMeasurements_[1])
    };
    autoCorrecting_ = false;
    currentProfileVerified_ = haveBestVerifiedPass_;
    correctionEnabled_.store(hasAnyCorrection(), std::memory_order_release);
    correctionToggle_.setEnabled(hasAnyCorrection());
    correctionToggle_.setToggleState(hasAnyCorrection(), juce::dontSendNotification);
    saveProfileButton_.setEnabled(hasAnyCorrection());
    waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    refreshWaterfallView();
    enableIdleControls();

    const float objective = combinedObjective(reports);
    juce::String msg = "AUTO stereo decay match complete | target "
                     + juce::String(static_cast<int>(targetSlider_.getValue())) + " ms | L "
                     + juce::String(reports[0].withinCorrectableBands) + "/"
                     + juce::String(reports[0].correctableBands) + " | R "
                     + juce::String(reports[1].withinCorrectableBands) + "/"
                     + juce::String(reports[1].correctableBands) + " | objective "
                     + juce::String(objective, 1) + " ms | model "
                     + juce::String(digitalTwinScore_, 0) + "% | "
                     + juce::String(totalStages(correctionProfiles_)) + " stages";
    if (bestVerifiedPass_ > 0)
        msg += " | best measured pass " + juce::String(bestVerifiedPass_);
    if (hitIterationLimit)
        msg += " | max verification passes reached";
    if (stopReason.isNotEmpty())
        msg += " | " + stopReason;
    msg += " | real AFTER graph is shown | press SAVE PROFILE AS... to choose name/location and update the VST3";
    status_.setText(msg, juce::dontSendNotification);
}

void MainComponent::audioDeviceIOCallbackWithContext(const float* const* inputChannelData,
                                                      int numInputChannels,
                                                      float* const* outputChannelData,
                                                      int numOutputChannels,
                                                      int numSamples,
                                                      const juce::AudioIODeviceCallbackContext&)
{
    for (int channel = 0; channel < numOutputChannels; ++channel)
        if (outputChannelData[channel] != nullptr)
            juce::FloatVectorOperations::clear(outputChannelData[channel], numSamples);

    const int liveMic = selectedMicCallbackIndex_.load(std::memory_order_acquire);
    const bool liveAvailable = liveMic >= 0 && liveMic < numInputChannels && inputChannelData[liveMic] != nullptr;
    liveInputAvailable_.store(liveAvailable, std::memory_order_release);
    if (liveAvailable) {
        const float* const liveData = inputChannelData[liveMic];
        float blockPeak = 0.0f;
        double sumSquares = 0.0;
        for (int i = 0; i < numSamples; ++i) {
            const float sample = liveData[i];
            blockPeak = std::max(blockPeak, std::abs(sample));
            sumSquares += static_cast<double>(sample) * static_cast<double>(sample);
        }
        float previousPeak = liveInputPeak_.load(std::memory_order_relaxed);
        while (blockPeak > previousPeak
               && !liveInputPeak_.compare_exchange_weak(previousPeak, blockPeak,
                                                        std::memory_order_release,
                                                        std::memory_order_relaxed)) {}
        const float blockRms = numSamples > 0
            ? static_cast<float>(std::sqrt(sumSquares / static_cast<double>(numSamples)))
            : 0.0f;
        liveInputRms_.store(blockRms, std::memory_order_release);

        const int physical = selectedMicInput_.load(std::memory_order_acquire);
        const float trimDb = (physical >= 0 && physical < static_cast<int>(inputTrimDb_.size()))
            ? inputTrimDb_[static_cast<std::size_t>(physical)].load(std::memory_order_acquire) : 0.0f;
        const float gain = juce::Decibels::decibelsToGain(trimDb);
        float postBlockPeak = 0.0f;
        double postSumSquares = 0.0;
        for (int i = 0; i < numSamples; ++i) {
            const float sample = liveData[i] * gain;
            postBlockPeak = std::max(postBlockPeak, std::abs(sample));
            postSumSquares += static_cast<double>(sample) * static_cast<double>(sample);
        }
        float previousPostPeak = livePostInputPeak_.load(std::memory_order_relaxed);
        while (postBlockPeak > previousPostPeak
               && !livePostInputPeak_.compare_exchange_weak(previousPostPeak, postBlockPeak,
                                                            std::memory_order_release,
                                                            std::memory_order_relaxed)) {}
        livePostInputRms_.store(numSamples > 0 ? static_cast<float>(std::sqrt(postSumSquares / static_cast<double>(numSamples))) : 0.0f,
                                std::memory_order_release);
    } else {
        liveInputRms_.store(0.0f, std::memory_order_release);
        livePostInputRms_.store(0.0f, std::memory_order_release);
    }

    if (const int pending = pendingBankIndex_.exchange(-1, std::memory_order_acq_rel); pending >= 0)
        activeBankIndex_.store(pending, std::memory_order_release);

    if (!measuring_.load(std::memory_order_acquire))
        return;

    int physicalOutputs[2] = {-1, -1};
    int foundOutputs = 0;
    for (int channel = 0; channel < numOutputChannels && foundOutputs < 2; ++channel) {
        if (outputChannelData[channel] != nullptr)
            physicalOutputs[foundOutputs++] = channel;
    }

    const int logicalChannel = measurementLogicalChannel_.load(std::memory_order_acquire);
    if (logicalChannel < 0 || logicalChannel > 1 || physicalOutputs[logicalChannel] < 0) {
        measuring_.store(false, std::memory_order_release);
        measurementFinished_.store(true, std::memory_order_release);
        return;
    }

    const int mic = selectedMicCallbackIndex_.load(std::memory_order_acquire);
    if (mic < 0 || mic >= numInputChannels || inputChannelData[mic] == nullptr) {
        measuring_.store(false, std::memory_order_release);
        measurementFinished_.store(true, std::memory_order_release);
        return;
    }

    const int bufferSlot = activeMeasurementBuffer_.load(std::memory_order_acquire);
    auto& buffers = measurementBuffers_[static_cast<std::size_t>(bufferSlot)];
    auto& banks = correctionBankSlots_[static_cast<std::size_t>(activeBankIndex_.load(std::memory_order_acquire))];
    std::size_t pos = measurementPosition_.load(std::memory_order_relaxed);
    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    const bool correction = correctionEnabled_.load(std::memory_order_acquire);
    float* const outData = outputChannelData[physicalOutputs[logicalChannel]];
    const float* const inData = inputChannelData[mic];
    const int physicalMic = selectedMicInput_.load(std::memory_order_acquire);
    const float inputTrimDb = (physicalMic >= 0 && physicalMic < static_cast<int>(inputTrimDb_.size()))
        ? inputTrimDb_[static_cast<std::size_t>(physicalMic)].load(std::memory_order_acquire) : 0.0f;
    const float inputGain = juce::Decibels::decibelsToGain(inputTrimDb);

    for (int i = 0; i < numSamples; ++i) {
        if (pos >= buffers.excitation.size())
            break;

        float out = buffers.excitation[pos];
        if (after && correction)
            out = (logicalChannel == 0 ? banks.left : banks.right).processSample(out);
        outData[i] = out;

        const float rawInput = inData[i];
        const float input = rawInput * inputGain;
        buffers.capture[pos] = input;
        ++pos;

        if (std::abs(rawInput) >= 0.999f || std::abs(input) >= 0.999f) {
            measurementClipped_.store(true, std::memory_order_release);
            measuring_.store(false, std::memory_order_release);
            measurementFinished_.store(true, std::memory_order_release);
            break;
        }
    }

    measurementPosition_.store(pos, std::memory_order_release);
    if (pos >= buffers.excitation.size() && measuring_.exchange(false, std::memory_order_acq_rel))
        measurementFinished_.store(true, std::memory_order_release);
}

void MainComponent::audioDeviceAboutToStart(juce::AudioIODevice* device)
{
    if (device == nullptr)
        return;
    auto cfg = measurement_.config();
    cfg.sampleRate = device->getCurrentSampleRate();
    measurement_.setConfig(cfg);
    liveInputPeak_.store(0.0f, std::memory_order_release);
    liveInputRms_.store(0.0f, std::memory_order_release);
    livePostInputPeak_.store(0.0f, std::memory_order_release);
    livePostInputRms_.store(0.0f, std::memory_order_release);
    liveInputAvailable_.store(false, std::memory_order_release);
    publishCorrectionBanks();
}

void MainComponent::audioDeviceStopped()
{
    measuring_.store(false, std::memory_order_release);
    liveInputAvailable_.store(false, std::memory_order_release);
    liveInputPeak_.store(0.0f, std::memory_order_release);
    liveInputRms_.store(0.0f, std::memory_order_release);
    livePostInputPeak_.store(0.0f, std::memory_order_release);
    livePostInputRms_.store(0.0f, std::memory_order_release);
}

void MainComponent::timerCallback()
{
    refreshMicInputSelector();
    refreshLiveInputMeter();
    if (measuring_.load(std::memory_order_acquire)) {
        const int slot = activeMeasurementBuffer_.load(std::memory_order_acquire);
        const auto total = std::max<std::size_t>(1, measurementBuffers_[static_cast<std::size_t>(slot)].excitation.size());
        const auto current = measurementPosition_.load(std::memory_order_acquire);
        const int percent = static_cast<int>(100.0 * static_cast<double>(current) / static_cast<double>(total));
        const int channel = measurementLogicalChannel_.load(std::memory_order_acquire);
        status_.setText(juce::String(measurementIsAfter_.load(std::memory_order_acquire)
                            ? "Corrected " : "Room ")
                        + speakerName(channel) + " measurement: " + juce::String(percent) + "%",
                        juce::dontSendNotification);
    }
    if (measurementFinished_.exchange(false, std::memory_order_acq_rel))
        finishMeasurementOnMessageThread();
}

void MainComponent::finishMeasurementOnMessageThread()
{
    const int channel = measurementLogicalChannel_.load(std::memory_order_acquire);
    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    const int slot = activeMeasurementBuffer_.load(std::memory_order_acquire);
    auto& buffers = measurementBuffers_[static_cast<std::size_t>(slot)];

    if (measurementClipped_.load(std::memory_order_acquire)) {
        if (after && autoCorrecting_)
            abortUnhelpfulAutoCorrection(juce::String(speakerName(channel))
                + " microphone input clipped; lower mic/preamp gain and measure again");
        else {
            enableIdleControls();
            status_.setText("MEASUREMENT CLIPPED on " + juce::String(speakerName(channel))
                            + " - sweep stopped. Lower mic/preamp gain and repeat; no profile was built.",
                            juce::dontSendNotification);
        }
        return;
    }

    status_.setText("Analysing " + juce::String(speakerName(channel)) + " impulse response and RT60...",
                    juce::dontSendNotification);
    const auto result = measurement_.analyseCapture(buffers.capture);
    if (result.clipped) {
        if (after && autoCorrecting_)
            abortUnhelpfulAutoCorrection(juce::String(speakerName(channel))
                + " analysis detected clipping; rejected the verification pass");
        else {
            enableIdleControls();
            status_.setText("MEASUREMENT CLIPPED - result rejected. Lower gain and repeat.",
                            juce::dontSendNotification);
        }
        return;
    }

    latestMeasurements_[static_cast<std::size_t>(channel)] = result;
    if (!after)
        baselineMeasurements_[static_cast<std::size_t>(channel)] = result;
    updateWaterfallForMeasurement(channel, after, result);
    updateGraphFromStereo(after);

    // Always measure the speakers independently: never excite L+R together.
    if (channel == 0) {
        startMeasurementChannel(1);
        return;
    }

    finishStereoMeasurementPass();
}

void MainComponent::finishStereoMeasurementPass()
{
    const bool after = measurementIsAfter_.load(std::memory_order_acquire);
    updateGraphFromStereo(after);

    if (!after) {
        model_.clearMeasuredAfter();
        if (baselinesValid())
            applyRecommendedStereoTarget();
        waterfallStateSelector_.setSelectedId(1, juce::dontSendNotification);
        waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
        refreshWaterfallView();
        enableIdleControls();

        const int leftBands = validBandCount(baselineMeasurements_[0]);
        const int rightBands = validBandCount(baselineMeasurements_[1]);
        if (!baselinesValid()) {
            status_.setText("Stereo measurement incomplete | L " + juce::String(leftBands)
                            + " bands | R " + juce::String(rightBands)
                            + " bands. Improve mic SNR and repeat.", juce::dontSendNotification);
        } else {
            status_.setText("Independent stereo measurement complete | L " + juce::String(leftBands)
                            + " bands @ " + juce::String(baselineMeasurements_[0].peakDbFs, 1)
                            + " dBFS | R " + juce::String(rightBands) + " bands @ "
                            + juce::String(baselineMeasurements_[1].peakDbFs, 1)
                            + " dBFS | common target " + juce::String(static_cast<int>(targetSlider_.getValue()))
                            + " ms | ready for AUTO.", juce::dontSendNotification);
        }
        return;
    }

    if (autoCorrecting_) {
        std::array<rt60::DecayUniformityReport, 2> reports{
            evaluateUniformity(0, latestMeasurements_[0]),
            evaluateUniformity(1, latestMeasurements_[1])
        };
        const float referenceObjective = haveBestVerifiedPass_ ? bestObjectiveMs_ : baselineObjectiveMs_;
        const float currentObjective = combinedObjective(reports);
        const float meaningfulDelta = std::max(6.0f, referenceObjective * 0.03f);
        const float regressionDelta = std::max(10.0f, referenceObjective * 0.06f);
        const float improvement = referenceObjective - currentObjective;
        bool verificationReliable = true;
        bool converged = true;
        int overshot = 0;
        int bestOvershot = 0;
        for (int channel = 0; channel < 2; ++channel) {
            verificationReliable = verificationReliable
                && (reports[channel].correctableBands == 0 || reports[channel].unreliableCorrectableBands == 0);
            converged = converged && reports[channel].converged;
            overshot += reports[channel].overshotCorrectableBands;
            bestOvershot += bestVerifiedReports_[channel].overshotCorrectableBands;
        }
        const bool materiallyBetter = verificationReliable && improvement >= meaningfulDelta;
        const bool regressed = currentObjective > referenceObjective + regressionDelta
            || (haveBestVerifiedPass_ && overshot > bestOvershot);

        if (!haveBestVerifiedPass_) {
            if (!verificationReliable) {
                abortUnhelpfulAutoCorrection("stereo verification lost trusted decay bands; improve measurement SNR");
                return;
            }
            if (!converged && !materiallyBetter) {
                abortUnhelpfulAutoCorrection("first corrected L/R pass did not produce meaningful measured improvement");
                return;
            }
            bestCorrectionProfiles_ = correctionProfiles_;
            bestVerifiedMeasurements_ = latestMeasurements_;
            bestVerifiedReports_ = reports;
            bestAfterWaterfalls_ = afterWaterfalls_;
            bestObjectiveMs_ = currentObjective;
            bestVerifiedPass_ = autoIteration_;
            haveBestVerifiedPass_ = true;
            currentProfileVerified_ = true;
        } else if (regressed) {
            restoreBestVerifiedPass();
            finishAutoCorrection(false, "rollback: latest stereo pass regressed; restored best verified pair");
            return;
        } else if (materiallyBetter || converged) {
            bestCorrectionProfiles_ = correctionProfiles_;
            bestVerifiedMeasurements_ = latestMeasurements_;
            bestVerifiedReports_ = reports;
            bestAfterWaterfalls_ = afterWaterfalls_;
            bestObjectiveMs_ = currentObjective;
            bestVerifiedPass_ = autoIteration_;
            currentProfileVerified_ = true;
        } else {
            restoreBestVerifiedPass();
            finishAutoCorrection(false, "stopped: further stereo pass gave no meaningful measured improvement");
            return;
        }

        if (converged) {
            finishAutoCorrection(false, "target tolerance reached on LEFT and RIGHT");
            return;
        }
        if (autoIteration_ >= kMaxAutoIterations) {
            restoreBestVerifiedPass();
            finishAutoCorrection(true, "kept best verified stereo result");
            return;
        }

        bool changedAny = false;
        for (int channel = 0; channel < 2; ++channel) {
            bool changed = rt60::CorrectionEngine::refineProfile(
                correctionProfiles_[channel], latestMeasurements_[channel], 0.28f, 0.08f);

            rt60::CorrectionDesignConfig cfg;
            cfg.targetMs = static_cast<float>(targetSlider_.getValue());
            cfg.autoTarget = false;
            cfg.strength = std::min(0.65f, static_cast<float>(strengthSlider_.getValue()) / 100.0f);
            cfg.maxCorrectionHz = static_cast<float>(maxCutSlider_.getValue());
            cfg.minConfidence = 0.50f;
            cfg.maxT60ReductionPerPass = 0.30f;
            cfg.maxNewStages = 6;
            auto incremental = correctionEngine_.design(latestMeasurements_[channel], cfg);
            const auto before = correctionProfiles_[channel].stages.size();
            rt60::CorrectionEngine::appendIncremental(correctionProfiles_[channel], incremental, 36, 1);
            changed = changed || correctionProfiles_[channel].stages.size() != before;
            changedAny = changedAny || changed;
        }

        if (!changedAny) {
            restoreBestVerifiedPass();
            finishAutoCorrection(false, "stopped: no safe high-confidence stereo correction change remained");
            return;
        }

        publishCorrectionBanks();
        ++autoIteration_;
        status_.setText("Stereo feedback pass " + juce::String(autoIteration_)
                        + ": retuning only measured modal decay below "
                        + juce::String(static_cast<int>(maxCutSlider_.getValue())) + " Hz...",
                        juce::dontSendNotification);
        startMeasurement(true);
        return;
    }

    waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    refreshWaterfallView();
    enableIdleControls();
    status_.setText("Corrected LEFT + RIGHT Measured After updated independently | L peak "
                    + juce::String(latestMeasurements_[0].peakDbFs, 1) + " dBFS | R peak "
                    + juce::String(latestMeasurements_[1].peakDbFs, 1) + " dBFS.",
                    juce::dontSendNotification);
}

void MainComponent::enableIdleControls()
{
    newMeasurementButton_.setEnabled(true);
    measureButton_.setEnabled(true);
    loadProfileButton_.setEnabled(!autoCorrecting_);
    autoCorrectButton_.setEnabled(baselinesValid() && !autoCorrecting_);
    correctionToggle_.setEnabled(hasAnyCorrection() && !autoCorrecting_);
    saveProfileButton_.setEnabled(hasAnyCorrection() && !autoCorrecting_);
    autoTargetToggle_.setEnabled(!autoCorrecting_);
    micInputSelector_.setEnabled(!autoCorrecting_);
}

void MainComponent::paint(juce::Graphics& graphics)
{
    graphics.fillAll(juce::Colour::fromRGB(14, 16, 20));
}

void MainComponent::resized()
{
    auto r = getLocalBounds().reduced(18);
    title_.setBounds(r.removeFromTop(38));

    auto top = r.removeFromTop(390);
    auto visualArea = top.removeFromLeft(static_cast<int>(top.getWidth() * 0.76f));
    auto rtArea = visualArea.removeFromTop(182);
    graph_.setBounds(rtArea);
    visualArea.removeFromTop(6);
    waterfallGraph_.setBounds(visualArea);
    top.removeFromLeft(10);
    deviceSelector_.setBounds(top);

    // One glance should answer: what was measured, what is the target, and
    // what did the correction actually achieve.
    r.removeFromTop(5);
    improvementLabel_.setBounds(r.removeFromTop(42));
    qualityLabel_.setBounds(r.removeFromTop(26));
    r.removeFromTop(4);

    // Compact two-column control area so the whole application fits on a
    // normal 900/1080-line display instead of hiding the result/status below
    // the bottom edge of the screen.
    auto controls = r.removeFromTop(132);
    auto left = controls.removeFromLeft((controls.getWidth() - 12) / 2);
    controls.removeFromLeft(12);
    auto right = controls;

    auto sliderRow = [](juce::Rectangle<int> row, juce::Label& label, juce::Slider& slider) {
        label.setBounds(row.removeFromLeft(175));
        slider.setBounds(row);
    };
    sliderRow(left.removeFromTop(32), targetLabel_, targetSlider_);
    sliderRow(left.removeFromTop(32), strengthLabel_, strengthSlider_);
    sliderRow(left.removeFromTop(32), maxCutLabel_, maxCutSlider_);
    sliderRow(left.removeFromTop(32), sweepLevelLabel_, sweepLevelSlider_);

    auto trimRow = right.removeFromTop(32);
    inputTrimLabel_.setBounds(trimRow.removeFromLeft(175));
    inputTrimSlider_.setBounds(trimRow);

    auto micRow = right.removeFromTop(32);
    micInputLabel_.setBounds(micRow.removeFromLeft(175));
    micInputSelector_.setBounds(micRow);

    auto meterRow = right.removeFromTop(32);
    inputLevelLabel_.setBounds(meterRow.removeFromLeft(175));
    inputLevelMeter_.setBounds(meterRow.removeFromLeft(210));
    meterRow.removeFromLeft(8);
    inputLevelValueLabel_.setBounds(meterRow);

    auto viewRow = right.removeFromTop(32);
    graphViewLabel_.setBounds(viewRow.removeFromLeft(120));
    graphChannelSelector_.setBounds(viewRow.removeFromLeft(120));
    viewRow.removeFromLeft(10);
    waterfallLabel_.setBounds(viewRow.removeFromLeft(150));
    waterfallChannelSelector_.setBounds(viewRow.removeFromLeft(105));
    viewRow.removeFromLeft(6);
    waterfallStateSelector_.setBounds(viewRow);

    r.removeFromTop(4);
    auto buttons = r.removeFromTop(42);
    newMeasurementButton_.setBounds(buttons.removeFromLeft(172));
    buttons.removeFromLeft(8);
    measureButton_.setBounds(buttons.removeFromLeft(185));
    buttons.removeFromLeft(8);
    autoCorrectButton_.setBounds(buttons.removeFromLeft(190));
    buttons.removeFromLeft(8);
    saveProfileButton_.setBounds(buttons.removeFromLeft(165));
    buttons.removeFromLeft(8);
    loadProfileButton_.setBounds(buttons.removeFromLeft(155));

    auto toggles = r.removeFromTop(30);
    autoTargetToggle_.setBounds(toggles.removeFromLeft(160));
    toggles.removeFromLeft(8);
    correctionToggle_.setBounds(toggles.removeFromLeft(190));

    filterInspectorLabel_.setBounds(r.removeFromTop(20));
    filterInspector_.setBounds(r.removeFromTop(62));
    status_.setBounds(r.removeFromTop(std::max(0, std::min(48, r.getHeight()))));
}
