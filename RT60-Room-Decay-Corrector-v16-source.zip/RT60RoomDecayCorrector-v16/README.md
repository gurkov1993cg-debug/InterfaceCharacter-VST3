# RT60 Room Decay Corrector v16 — Clear Results

## Primary workflow (all buttons are functional)
1. **NEW MEASUREMENT** — clears only the current measurement/correction session. Audio device, sample rate, buffer, mic input and saved profile files are kept.
2. **MEASURE ROOM L + R** — performs a fresh uncorrected LEFT sweep and RIGHT sweep and stores the real BEFORE measurement.
3. **AUTO CORRECT + VERIFY** — designs the correction from the real BEFORE measurement, enables it, then automatically performs a real corrected LEFT+RIGHT verification measurement.
4. **SAVE PROFILE AS...** — writes a `.rt60profile` bundle containing correction, BEFORE/AFTER summaries, waterfalls, display state and metadata, and updates the active mirror used by the VST3.
5. **LOAD PROFILE...** — loads a saved `.rt60profile`, replaces the current room state, restores the correction/display data and updates the active VST3 mirror.

The VST3 also has a real **LOAD PROFILE...** action and can reload the active shared profile written by the standalone application.

## Clear result display

The large result line directly below the graphs shows, for LEFT, RIGHT or WORST OF L/R:

- average decay BEFORE correction in the selected correction range;
- target decay;
- measured AFTER decay after automatic verification;
- percentage improvement;
- a plain-language verdict;
- before correction, the worst ringing frequency and decay time.

Measurement quality is reduced to useful grades: **GOOD**, **USABLE**, **WEAK**, or **CLIPPED** while retaining peak and dynamic-range values. The filter-stage inspector remains available as optional advanced information.

## Audio behavior

- Windows: JUCE ASIO enabled; actual driver sample rate and buffer are used.
- macOS Intel: CoreAudio, x86_64, deployment target 10.13.
- Selectable measurement microphone input with live PRE/POST metering and per-input digital trim.
- LEFT and RIGHT sweeps are measured separately.
- Correction DSP is bypassed for every new baseline measurement.
- Correction verification is real measurement, not only a model estimate.

## Profile state

v14+ profile bundles preserve BEFORE/AFTER measurement summaries, graph state, waterfall state and correction profiles so loading different profiles replaces the displayed room state instead of leaving stale measurement data. Older bundles remain loadable where possible.

## Build validation

The core test suite contains decay-model, measurement, correction, uniformity, waterfall, display-snapshot, profile-bundle and regression tests.
