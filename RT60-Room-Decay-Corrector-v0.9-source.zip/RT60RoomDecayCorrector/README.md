# RT60 Room Decay Corrector v0.9

v0.9 is a deliberately small, compatibility-focused update to the working v0.8 build.
The measurement, correction DSP, AUTO VERIFY, Save As bundle format, Before/After graph,
and waterfall analysis are unchanged.

## What v0.9 adds

The VST3 now has a real **LOAD PROFILE...** button inside Cubase.

1. Create and save profiles in the standalone app with **SAVE PROFILE AS...**.
2. Insert the VST3 in Cubase.
3. Press **LOAD PROFILE...** directly in the plug-in.
4. Choose any `.rt60profile` file.
5. The selected stereo correction, real Before/After RT60 display, and Before/After waterfall are loaded immediately.
6. The status line shows the selected profile name.

The previous **RELOAD SHARED PROFILE** button remains available for the old workflow where the standalone app updates the shared active profile.

## Protection against breaking a working profile

- The selected `.rt60profile` is fully parsed and validated before the live correction is replaced.
- A corrupt or truncated file is rejected transactionally: the currently working profile remains active.
- Loading happens on the GUI/message thread; the audio callback still performs no file I/O or allocation.
- The existing triple-bank atomic handoff remains unchanged for real-time-safe correction updates.
- No changes were made to the correction design, measurement engine, AUTO VERIFY logic, or filter DSP.

## Tests

v0.9 adds a profile-bundle codec test covering round-trip loading plus corrupt/truncated-file rejection, in addition to the existing core, measurement, correction, uniformity, waterfall, and display-snapshot tests.
