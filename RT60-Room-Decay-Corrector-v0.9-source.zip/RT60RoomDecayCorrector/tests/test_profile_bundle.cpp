#include "core/ProfileBundle.hpp"

#include <cassert>
#include <cmath>
#include <iostream>

int main()
{
    rt60::ProfileBundle source;
    source.profiles[0].targetMs = 220.0f;
    source.profiles[0].strength = 0.82f;
    source.profiles[0].autoTarget = true;
    source.profiles[0].measuredBandMs[3] = 610.0f;
    source.profiles[0].targetBandMs[3] = 220.0f;
    rt60::CorrectionStageSpec stage;
    stage.frequencyHz = 50.0f;
    stage.measuredT60Ms = 610.0f;
    stage.desiredT60Ms = 220.0f;
    stage.estimatedQ = 7.0f;
    stage.confidence = 0.9f;
    stage.sourceBand = 3;
    source.profiles[0].stages.push_back(stage);
    source.profiles[1] = source.profiles[0];
    source.display.beforeMs[3] = 610.0f;
    source.display.beforeValid[3] = true;
    source.display.afterMs[3] = 330.0f;
    source.display.afterValid[3] = true;

    const auto encoded = rt60::ProfileBundleCodec::serialize(source);
    rt60::ProfileBundle decoded;
    assert(rt60::ProfileBundleCodec::deserialize(encoded, decoded));
    assert(decoded.hasCorrection());
    assert(decoded.profiles[0].stages.size() == 1);
    assert(std::abs(decoded.profiles[0].stages[0].frequencyHz - 50.0f) < 0.01f);
    assert(decoded.display.beforeValid[3]);
    assert(decoded.display.afterValid[3]);
    assert(std::abs(decoded.display.afterMs[3] - 330.0f) < 0.01f);

    rt60::ProfileBundle sentinel = decoded;
    sentinel.profiles[0].targetMs = 777.0f;
    const auto truncated = encoded.substr(0, encoded.size() / 2);
    assert(!rt60::ProfileBundleCodec::deserialize(truncated, sentinel));
    assert(std::abs(sentinel.profiles[0].targetMs - 777.0f) < 0.01f);

    auto corrupt = encoded;
    const auto marker = corrupt.find("LEFT_PROFILE");
    assert(marker != std::string::npos);
    corrupt.replace(marker, 4, "BAD_");
    assert(!rt60::ProfileBundleCodec::deserialize(corrupt, sentinel));
    assert(std::abs(sentinel.profiles[0].targetMs - 777.0f) < 0.01f);

    std::cout << "Profile bundle tests passed\n";
    return 0;
}
