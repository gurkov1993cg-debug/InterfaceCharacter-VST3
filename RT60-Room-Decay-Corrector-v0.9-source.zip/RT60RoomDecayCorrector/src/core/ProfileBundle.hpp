#pragma once

#include "core/CorrectionEngine.hpp"
#include "core/DisplaySnapshot.hpp"
#include "core/WaterfallData.hpp"

#include <array>
#include <string>

namespace rt60 {

struct ProfileBundle {
    std::array<CorrectionProfile, 2> profiles{};
    std::array<WaterfallData, 2> beforeWaterfalls{};
    std::array<WaterfallData, 2> afterWaterfalls{};
    DisplaySnapshot display{};

    bool hasCorrection() const noexcept
    {
        return !profiles[0].empty() || !profiles[1].empty();
    }
};

class ProfileBundleCodec {
public:
    static std::string serialize(const ProfileBundle& bundle);
    static bool deserialize(const std::string& text, ProfileBundle& bundle);
};

} // namespace rt60
