#include "core/ProfileBundle.hpp"

#include <array>
#include <cstddef>

namespace rt60 {
namespace {

void appendSection(std::string& out, const char* name, const std::string& payload)
{
    out += name;
    out += ' ';
    out += std::to_string(payload.size());
    out += '\n';
    out += payload;
    out += '\n';
}

bool readSection(const std::string& text,
                 std::size_t& pos,
                 const char* expected,
                 std::string& payload)
{
    const auto eol = text.find('\n', pos);
    if (eol == std::string::npos)
        return false;

    const std::string line = text.substr(pos, eol - pos);
    const std::string prefix = std::string(expected) + " ";
    if (line.rfind(prefix, 0) != 0)
        return false;

    std::size_t length = 0;
    try {
        const auto digits = line.substr(prefix.size());
        std::size_t consumed = 0;
        const auto value = std::stoull(digits, &consumed);
        if (consumed != digits.size())
            return false;
        length = static_cast<std::size_t>(value);
    } catch (...) {
        return false;
    }

    pos = eol + 1;
    if (length > text.size() - pos)
        return false;

    payload.assign(text.data() + pos, length);
    pos += length;
    if (pos >= text.size() || text[pos] != '\n')
        return false;
    ++pos;
    return true;
}

} // namespace

std::string ProfileBundleCodec::serialize(const ProfileBundle& bundle)
{
    std::string out = "RT60_PROFILE_BUNDLE 1\n";
    appendSection(out, "LEFT_PROFILE", CorrectionEngine::serialize(bundle.profiles[0]));
    appendSection(out, "RIGHT_PROFILE", CorrectionEngine::serialize(bundle.profiles[1]));
    appendSection(out, "WF_BEFORE_LEFT", bundle.beforeWaterfalls[0].valid()
        ? WaterfallAnalyzer::serialize(bundle.beforeWaterfalls[0]) : std::string{});
    appendSection(out, "WF_BEFORE_RIGHT", bundle.beforeWaterfalls[1].valid()
        ? WaterfallAnalyzer::serialize(bundle.beforeWaterfalls[1]) : std::string{});
    appendSection(out, "WF_AFTER_LEFT", bundle.afterWaterfalls[0].valid()
        ? WaterfallAnalyzer::serialize(bundle.afterWaterfalls[0]) : std::string{});
    appendSection(out, "WF_AFTER_RIGHT", bundle.afterWaterfalls[1].valid()
        ? WaterfallAnalyzer::serialize(bundle.afterWaterfalls[1]) : std::string{});
    appendSection(out, "DISPLAY", DisplaySnapshotCodec::serialize(bundle.display));
    out += "END\n";
    return out;
}

bool ProfileBundleCodec::deserialize(const std::string& text, ProfileBundle& bundle)
{
    constexpr const char* header = "RT60_PROFILE_BUNDLE 1\n";
    if (text.rfind(header, 0) != 0)
        return false;

    std::size_t pos = std::char_traits<char>::length(header);
    std::array<std::string, 7> payloads;
    const std::array<const char*, 7> names{{
        "LEFT_PROFILE", "RIGHT_PROFILE",
        "WF_BEFORE_LEFT", "WF_BEFORE_RIGHT",
        "WF_AFTER_LEFT", "WF_AFTER_RIGHT", "DISPLAY"
    }};

    for (std::size_t i = 0; i < names.size(); ++i)
        if (!readSection(text, pos, names[i], payloads[i]))
            return false;

    if (text.substr(pos) != "END\n")
        return false;

    ProfileBundle parsed;
    if (!CorrectionEngine::deserialize(payloads[0], parsed.profiles[0])
        || !CorrectionEngine::deserialize(payloads[1], parsed.profiles[1]))
        return false;

    for (int channel = 0; channel < 2; ++channel) {
        if (!payloads[2 + channel].empty()
            && !WaterfallAnalyzer::deserialize(payloads[2 + channel], parsed.beforeWaterfalls[channel]))
            return false;
        if (!payloads[4 + channel].empty()
            && !WaterfallAnalyzer::deserialize(payloads[4 + channel], parsed.afterWaterfalls[channel]))
            return false;
    }

    if (!DisplaySnapshotCodec::deserialize(payloads[6], parsed.display))
        return false;

    if (!parsed.hasCorrection())
        return false;

    // Transactional commit: the caller keeps its current active bundle when
    // the selected file is truncated, corrupt, or otherwise invalid.
    bundle = std::move(parsed);
    return true;
}

} // namespace rt60
