#include "plugin/PluginEditor.hpp"

RT60Editor::RT60Editor(RT60Processor& p) : AudioProcessorEditor(&p), processor_(p)
{
    setSize(1000, 820);
    graph_.setModel(&processor_.model());
    addAndMakeVisible(graph_);
    addAndMakeVisible(waterfallGraph_);

    title_.setText("RT60 ROOM DECAY CORRECTOR v0.9 - DIRECT PROFILE LOAD + REAL BEFORE/AFTER", juce::dontSendNotification);
    title_.setFont(juce::FontOptions(22.0f, juce::Font::bold));
    addAndMakeVisible(title_);

    waterfallLabel_.setText("Waterfall", juce::dontSendNotification);
    addAndMakeVisible(waterfallLabel_);
    waterfallChannelSelector_.addItem("LEFT", 1);
    waterfallChannelSelector_.addItem("RIGHT", 2);
    waterfallChannelSelector_.setSelectedId(1, juce::dontSendNotification);
    waterfallStateSelector_.addItem("BEFORE", 1);
    waterfallStateSelector_.addItem("AFTER", 2);
    waterfallStateSelector_.setSelectedId(1, juce::dontSendNotification);
    addAndMakeVisible(waterfallChannelSelector_);
    addAndMakeVisible(waterfallStateSelector_);
    waterfallChannelSelector_.onChange = [this] { refreshWaterfall(); };
    waterfallStateSelector_.onChange = [this] { refreshWaterfall(); };

    addAndMakeVisible(status_);
    addAndMakeVisible(loadProfileButton_);
    addAndMakeVisible(reloadButton_);
    addAndMakeVisible(bypassButton_);
    bypassA_ = std::make_unique<ButtonAttachment>(processor_.apvts, "bypass", bypassButton_);

    loadProfileButton_.onClick = [this] { beginLoadProfile(); };

    reloadButton_.onClick = [this] {
        processor_.reloadActiveProfile();
        updateStatus();
        graph_.repaint();
        if (processor_.waterfall(0, true) != nullptr)
            waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
        refreshWaterfall();
    };
    updateStatus();
    if (processor_.waterfall(0, true) != nullptr)
        waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
    refreshWaterfall();
    startTimerHz(10);
}

void RT60Editor::beginLoadProfile()
{
    const auto folder = juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
    loadProfileChooser_ = std::make_unique<juce::FileChooser>(
        "Load RT60 correction profile...", folder, "*.rt60profile", true, false, this);
    loadProfileChooser_->launchAsync(
        juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& chooser) {
            const auto file = chooser.getResult();
            if (file == juce::File{})
                return;

            if (!processor_.loadProfileBundleFromFile(file)) {
                status_.setText("LOAD FAILED: invalid/corrupt .rt60profile. The current working profile was left unchanged.",
                                juce::dontSendNotification);
                return;
            }

            graph_.repaint();
            if (processor_.waterfall(0, true) != nullptr || processor_.waterfall(1, true) != nullptr)
                waterfallStateSelector_.setSelectedId(2, juce::dontSendNotification);
            refreshWaterfall();
            updateStatus();
        });
}

void RT60Editor::refreshWaterfall()
{
    const int channel = juce::jlimit(0, 1, waterfallChannelSelector_.getSelectedId() - 1);
    const bool after = waterfallStateSelector_.getSelectedId() == 2;
    waterfallGraph_.setData(processor_.waterfall(channel, after));
    waterfallGraph_.setCaption("MEASURED WATERFALL - " + juce::String(channel == 0 ? "LEFT" : "RIGHT")
                               + (after ? " AFTER" : " BEFORE") + " - 20 to 300 Hz");
}

void RT60Editor::updateStatus()
{
    if (processor_.hasActiveProfile()) {
        const auto name = processor_.activeProfileName();
        const auto prefix = name.isNotEmpty()
            ? (juce::String("ACTIVE PROFILE '") + name + "'")
            : juce::String("ACTIVE SHARED PROFILE");
        status_.setText(prefix + " | " + juce::String(processor_.activeStageCount())
                        + " correction stages | real Before/After + waterfall loaded when available",
                        juce::dontSendNotification);
    } else {
        status_.setText("No active profile. Press LOAD PROFILE... here in Cubase, or create/save one in the standalone app.",
                        juce::dontSendNotification);
    }
}

void RT60Editor::timerCallback()
{
    graph_.repaint();
    waterfallGraph_.repaint();
}

void RT60Editor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(14, 16, 20));
}

void RT60Editor::resized()
{
    auto r = getLocalBounds().reduced(18);
    title_.setBounds(r.removeFromTop(38));
    status_.setBounds(r.removeFromTop(28));
    graph_.setBounds(r.removeFromTop(300));
    r.removeFromTop(8);
    waterfallGraph_.setBounds(r.removeFromTop(330));
    r.removeFromTop(6);
    auto selectors = r.removeFromTop(30);
    waterfallLabel_.setBounds(selectors.removeFromLeft(75));
    waterfallChannelSelector_.setBounds(selectors.removeFromLeft(130));
    selectors.removeFromLeft(8);
    waterfallStateSelector_.setBounds(selectors.removeFromLeft(130));
    r.removeFromTop(6);
    auto row = r.removeFromTop(38);
    loadProfileButton_.setBounds(row.removeFromLeft(190));
    row.removeFromLeft(12);
    reloadButton_.setBounds(row.removeFromLeft(230));
    row.removeFromLeft(12);
    bypassButton_.setBounds(row.removeFromLeft(120));
}
