#include "plugin/PluginProcessor.hpp"
#include "plugin/PluginEditor.hpp"

#include <algorithm>

juce::AudioProcessorValueTreeState::ParameterLayout RT60Processor::createParameters()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> parameters;
    parameters.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));
    return {parameters.begin(), parameters.end()};
}

RT60Processor::RT60Processor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", createParameters())
{
    model_.setDemoRoom();
}

bool RT60Processor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainInputChannelSet() == layouts.getMainOutputChannelSet()
        && (layouts.getMainOutputChannelSet() == juce::AudioChannelSet::mono()
            || layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo());
}

juce::File RT60Processor::profileDirectory()
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("Room Decay Lab")
        .getChildFile("RT60 Room Decay Corrector");
}

juce::File RT60Processor::activeProfileFile(int channel)
{
    return profileDirectory().getChildFile(channel == 0
        ? "active_profile_left.rt60" : "active_profile_right.rt60");
}

juce::File RT60Processor::legacyProfileFile()
{
    return profileDirectory().getChildFile("active_profile.rt60");
}

juce::File RT60Processor::waterfallFile(int channel, bool afterCorrection)
{
    const juce::String side = channel == 0 ? "left" : "right";
    const juce::String phase = afterCorrection ? "after" : "before";
    return profileDirectory().getChildFile("waterfall_" + phase + "_" + side + ".rt60wf");
}

juce::File RT60Processor::displaySnapshotFile()
{
    return profileDirectory().getChildFile("active_display.rt60g");
}

void RT60Processor::applyDisplaySnapshot(const rt60::DisplaySnapshot& snapshot)
{
    model_.clearMeasuredAfter();
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        if (snapshot.beforeValid[i])
            model_.setMeasured(i, snapshot.beforeMs[i]);
        if (snapshot.afterValid[i])
            model_.setMeasuredAfter(i, snapshot.afterMs[i]);
    }
}

void RT60Processor::loadDisplaySnapshot()
{
    const auto file = displaySnapshotFile();
    if (!file.existsAsFile())
        return;
    rt60::DisplaySnapshot snapshot;
    if (!rt60::DisplaySnapshotCodec::deserialize(file.loadFileAsString().toStdString(), snapshot))
        return;
    applyDisplaySnapshot(snapshot);
}

void RT60Processor::loadWaterfallSnapshots()
{
    beforeWaterfalls_ = {};
    afterWaterfalls_ = {};
    for (int channel = 0; channel < 2; ++channel) {
        for (int phase = 0; phase < 2; ++phase) {
            const bool after = phase == 1;
            const auto file = waterfallFile(channel, after);
            if (!file.existsAsFile())
                continue;
            rt60::WaterfallData parsed;
            if (rt60::WaterfallAnalyzer::deserialize(file.loadFileAsString().toStdString(), parsed)) {
                if (after) afterWaterfalls_[static_cast<std::size_t>(channel)] = std::move(parsed);
                else beforeWaterfalls_[static_cast<std::size_t>(channel)] = std::move(parsed);
            }
        }
    }
}

const rt60::WaterfallData* RT60Processor::waterfall(int channel, bool afterCorrection) const noexcept
{
    if (channel < 0 || channel > 1)
        return nullptr;
    const auto& data = afterCorrection ? afterWaterfalls_[static_cast<std::size_t>(channel)]
                                       : beforeWaterfalls_[static_cast<std::size_t>(channel)];
    return data.valid() ? &data : nullptr;
}

bool RT60Processor::writeActiveMirror(const rt60::ProfileBundle& bundle)
{
    bool ok = profileDirectory().createDirectory().wasOk() || profileDirectory().isDirectory();

    for (int channel = 0; channel < 2; ++channel) {
        const auto encoded = rt60::CorrectionEngine::serialize(bundle.profiles[static_cast<std::size_t>(channel)]);
        ok = activeProfileFile(channel).replaceWithText(juce::String::fromUTF8(encoded.c_str())) && ok;

        const auto& before = bundle.beforeWaterfalls[static_cast<std::size_t>(channel)];
        const auto& after = bundle.afterWaterfalls[static_cast<std::size_t>(channel)];
        if (before.valid()) {
            const auto text = rt60::WaterfallAnalyzer::serialize(before);
            ok = waterfallFile(channel, false).replaceWithText(juce::String::fromUTF8(text.c_str())) && ok;
        } else {
            waterfallFile(channel, false).deleteFile();
        }
        if (after.valid()) {
            const auto text = rt60::WaterfallAnalyzer::serialize(after);
            ok = waterfallFile(channel, true).replaceWithText(juce::String::fromUTF8(text.c_str())) && ok;
        } else {
            waterfallFile(channel, true).deleteFile();
        }
    }

    const auto displayText = rt60::DisplaySnapshotCodec::serialize(bundle.display);
    ok = displaySnapshotFile().replaceWithText(juce::String::fromUTF8(displayText.c_str())) && ok;
    return ok;
}

bool RT60Processor::loadProfileBundleFromFile(const juce::File& file)
{
    if (!file.existsAsFile())
        return false;

    rt60::ProfileBundle parsed;
    if (!rt60::ProfileBundleCodec::deserialize(file.loadFileAsString().toStdString(), parsed))
        return false;

    // The codec validates the complete bundle before this point. Only now do
    // we replace the live profile, keeping a corrupt selection from touching
    // the currently working correction.
    profiles_ = parsed.profiles;
    beforeWaterfalls_ = parsed.beforeWaterfalls;
    afterWaterfalls_ = parsed.afterWaterfalls;
    hasProfile_.store(parsed.hasCorrection(), std::memory_order_release);
    applyProfileToModel();
    applyDisplaySnapshot(parsed.display);
    publishBanks();
    currentProfileName_ = file.getFileNameWithoutExtension();

    // Keep the same active mirror that the standalone and future plug-in
    // instances use. A mirror-write problem does not disable the profile that
    // was already validated and loaded into this instance.
    writeActiveMirror(parsed);
    return parsed.hasCorrection();
}

void RT60Processor::applyProfileToModel()
{
    const auto& reference = !profiles_[0].empty() ? profiles_[0] : profiles_[1];
    if (reference.empty())
        return;

    model_.setStrength(reference.strength);
    model_.setMaxCutDb(18.0f);
    for (std::size_t i = 0; i < rt60::kBandCount; ++i) {
        float measured = 0.0f;
        float target = 0.0f;
        for (int channel = 0; channel < 2; ++channel) {
            measured = std::max(measured, profiles_[channel].measuredBandMs[i]);
            target = std::max(target, profiles_[channel].targetBandMs[i]);
        }
        if (measured > 0.0f)
            model_.setMeasured(i, measured);
        if (target > 0.0f)
            model_.setTarget(i, target);
    }
}

void RT60Processor::publishBanks()
{
    const int active = activeBankIndex_.load(std::memory_order_acquire);
    const int pending = pendingBankIndex_.load(std::memory_order_acquire);
    int slot = 0;
    while (slot == active || slot == pending)
        ++slot;
    if (slot >= static_cast<int>(bankSlots_.size()))
        return;

    auto& banks = bankSlots_[static_cast<std::size_t>(slot)];
    banks.left.configure(profiles_[0], sampleRate_);
    banks.right.configure(profiles_[1], sampleRate_);
    pendingBankIndex_.store(slot, std::memory_order_release);
}

bool RT60Processor::reloadActiveProfile()
{
    currentProfileName_.clear();
    loadWaterfallSnapshots();
    std::array<rt60::CorrectionProfile, 2> loaded{};
    bool gotStereo = false;
    bool valid = true;

    for (int channel = 0; channel < 2; ++channel) {
        const auto file = activeProfileFile(channel);
        if (!file.existsAsFile())
            continue;
        gotStereo = true;
        if (!rt60::CorrectionEngine::deserialize(file.loadFileAsString().toStdString(), loaded[channel]))
            valid = false;
    }

    if (!gotStereo) {
        const auto legacy = legacyProfileFile();
        if (legacy.existsAsFile()) {
            rt60::CorrectionProfile mono;
            if (rt60::CorrectionEngine::deserialize(legacy.loadFileAsString().toStdString(), mono)) {
                loaded[0] = mono;
                loaded[1] = mono;
            } else {
                valid = false;
            }
        }
    }

    if (!valid) {
        profiles_ = {};
        hasProfile_.store(false, std::memory_order_release);
        publishBanks();
        return false;
    }

    profiles_ = std::move(loaded);
    const bool active = !profiles_[0].empty() || !profiles_[1].empty();
    hasProfile_.store(active, std::memory_order_release);
    applyProfileToModel();
    loadDisplaySnapshot();
    publishBanks();
    return active;
}

int RT60Processor::activeStageCount() const noexcept
{
    return static_cast<int>(profiles_[0].stages.size() + profiles_[1].stages.size());
}

void RT60Processor::prepareToPlay(double sampleRate, int)
{
    sampleRate_ = sampleRate;
    reloadActiveProfile();
}

void RT60Processor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    if (const int pending = pendingBankIndex_.exchange(-1, std::memory_order_acq_rel); pending >= 0)
        activeBankIndex_.store(pending, std::memory_order_release);

    if (apvts.getRawParameterValue("bypass")->load() > 0.5f
        || !hasProfile_.load(std::memory_order_acquire))
        return;

    auto& banks = bankSlots_[static_cast<std::size_t>(activeBankIndex_.load(std::memory_order_acquire))];
    for (int channel = 0; channel < buffer.getNumChannels(); ++channel) {
        auto* data = buffer.getWritePointer(channel);
        if (channel == 0)
            banks.left.process(data, buffer.getNumSamples());
        else
            banks.right.process(data, buffer.getNumSamples());
    }
}

juce::AudioProcessorEditor* RT60Processor::createEditor()
{
    return new RT60Editor(*this);
}

void RT60Processor::getStateInformation(juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary(*xml, dest);
}

void RT60Processor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        apvts.replaceState(juce::ValueTree::fromXml(*xml));
    reloadActiveProfile();
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RT60Processor();
}
